"""Paired sensitivity of the archived gait to ball–paddle sliding friction."""
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
from unittest.mock import patch
import csv
import hashlib
import itertools
import json
import numpy as np
import contact_pairs as cp

HERE = Path(__file__).resolve().parent
TEACHER_FILE = cp.ROOT / 'replay/fixed-paced-seal.json'
TEACHER = json.loads(TEACHER_FILE.read_text())
SEEDS = range(16530000, 16530096)
TRACKS = ('fixed', 'combined', 'incline', 'flat')
ARMS = ('wide', 'nominal', 'historic', 'historic_anchored')


def save(name, data):
    (HERE / name).write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n')


def episode(args):
    seed, track, mode = args
    with cp.surface(mode, halfwidth=.01) as info:
        run = cp.transfer.run(track, seed, TEACHER['scale'], actions=TEACHER['actions'])
    row = {k: run[k] for k in ('seed', 'track', 'seconds', 'reason', 'last_both_m', 'flat_1m',
                                'slope_1m', 'finish_2p5', 'torque_nm')}
    row['mode'] = mode
    for name, label in zip(cp.NAMES, ('A', 'B')):
        if name in info:
            row['old_'+label], row['mu_'+label] = info[name][:2]
    return row


def main():
    save('protocol.json', dict(seeds=[SEEDS.start, SEEDS.stop-1],tracks=TRACKS,arms=ARMS,
        halfwidth=.01,seed_origin=12600381,old_center=cp.HISTORIC,nominal_center=cp.NOMINAL,
        teacher_sha=hashlib.sha256(TEACHER_FILE.read_bytes()).hexdigest(),
        rules='Same seeds and frozen archived actions in every arm. Original scored releases and stopping rules. '
              'Survival is seconds > 2. Last_both_m is the last simultaneous contacts before a veto. '
              'The anchored arm maps the historic contact value exactly to itself.'))
    seed=12600381
    historic=[episode((seed,'fixed',mode)) for mode in ('native',*ARMS,'historic_fixed','nominal_fixed')]
    for row in historic:
        if row['mode'] in ('native','wide','historic_fixed','historic_anchored'):
            assert row['last_both_m']==1.4344716654053211
    center=cp.HISTORIC
    perturb=[]
    for delta in (-.005,-.002,-.001,-.0001,0.,.0001,.001,.002,.005):
        with patch.object(cp,'HISTORIC',center+delta):
            r=episode((seed,'fixed','historic_fixed'))
        perturb.append(dict(delta=delta,mu=center+delta,**r))
    save('record-replay.json',dict(arms=historic,around_record=perturb))
    jobs=itertools.product(SEEDS,TRACKS,ARMS)
    with ProcessPoolExecutor(8) as pool:
        rows=list(pool.map(episode,jobs,chunksize=4))
    assert len(rows)==len(SEEDS)*len(TRACKS)*len(ARMS)
    with (HERE/'paired.csv').open('w') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    result={}
    rng=np.random.default_rng(285901)
    for track in TRACKS:
        result[track]={}
        groups={mode:sorted((r for r in rows if r['mode']==mode and r['track']==track),key=lambda r:r['seed']) for mode in ARMS}
        base=np.array([r['last_both_m'] for r in groups['wide']])
        for arm,rr in groups.items():
            assert [r['seed'] for r in rr]==list(SEEDS)
            delta=np.array([r['last_both_m'] for r in rr])-base
            boot=delta[rng.integers(0,len(rr),(4000,len(rr)))].mean(axis=1)
            result[track][arm]=dict(n=len(rr),survived_2s=sum(r['seconds']>2 for r in rr),
                flat=sum(r['flat_1m'] for r in rr),slope=sum(r['slope_1m'] for r in rr),
                finish=sum(r['finish_2p5'] for r in rr),mean_m=float(base.mean()+delta.mean()),
                max_m=max(r['last_both_m'] for r in rr),mean_delta_vs_wide_mm=1000*delta.mean(),
                paired_boot95_mm=(1000*np.quantile(boot,[.025,.975])).tolist())
    save('paired-summary.json',result)
    print(json.dumps(result,ensure_ascii=False),flush=True)


if __name__=='__main__':main()
