"""Describe release dynamics in the archived medium-speed holdout; check actual MuJoCo resets.

Run from this folder with ../pingpong-turn-pit-20261128/run-local release_groups.py .
"""
import csv
import hashlib
import json
from pathlib import Path
import sys
from unittest.mock import patch

import numpy as np

HERE = Path(__file__).resolve().parent
SHORT = HERE.parent / "pingpong-dual16-short-20261128"
TRAINING = SHORT / "training"
sys.path[:0] = [str(TRAINING / "enrichment"), str(TRAINING), str(SHORT)]
from mine import load_channel
from study import BASE
from actors import ball, configured, controller
import short_track


def release(seed):
    second_seed = int(np.random.SeedSequence([seed, 20002]).generate_state(1)[0])
    a = load_channel(seed)
    b = load_channel(second_seed, a[0])
    # The fifth material draw follows two gain and two damping draws per ball.
    draws = []
    for channel_seed in (seed, second_seed):
        rng = np.random.default_rng(channel_seed)
        rng.random(4)
        draws.append(.32 * (1 + rng.uniform(-.30, .30)))
    return np.stack([a[0], b[0]]), np.stack([a[1], b[1]]), np.array(draws)


def features(positions, velocities, slide):
    gap = positions[1] - positions[0]
    dv = velocities[1] - velocities[0]
    dot = float(gap @ dv)
    speed2 = float(dv @ dv)
    discriminant = dot ** 2 + speed2 * (.110 ** 2 - gap @ gap)
    time_to_diameter = ((-dot + np.sqrt(discriminant)) / speed2
                        if speed2 > 0 else float("inf"))
    return {
        "separation_rate_mm_s": 1000 * dot / np.linalg.norm(gap),
        "constant_velocity_time_to_diameter_s": time_to_diameter,
        "relative_speed_mm_s": 1000 * np.linalg.norm(dv),
        "initial_separation_mm": 1000 * np.linalg.norm(gap),
        "ball_A_face_slide": slide[0],
        "ball_B_face_slide": max(slide),
    }


def group_report(rows, indices, feature):
    values = [rows[i]["features"][feature] for i in indices]
    progress = [rows[i]["last_both_m"] for i in indices]
    times = [rows[i]["seconds"] for i in indices]
    return {
        "n": len(values), "min": float(min(values)), "max": float(max(values)),
        "survived_strictly_beyond_s": {str(t): sum(v > t for v in times) for t in (1, 2, 3, 5)},
        "mean_last_both_m": float(np.mean(progress)),
        "last_both_at_least_m": {str(m): sum(v >= m for v in progress) for m in (.10, .25, .50, 1.)},
    }


def audit_release(row, recipe):
    seed = row["seed"]
    predicted_p, predicted_v, predicted_mu = release(seed)
    observed = {}
    with controller(recipe, BASE["settings"]):
        original = ball.BallController.reset

        def record(bc, *args, **kwargs):
            result = original(bc, *args, **kwargs)
            m, d = bc.m, bc.d
            face = m.geom("paddle_face").id
            positions, velocities, geom_slide = [], [], []
            for channel in bc.channels:
                rotation = d.site_xmat[channel.site].reshape(3, 3)
                loc = rotation.T @ (d.qpos[channel.adr:channel.adr+3] - d.site_xpos[channel.site])
                velocity = rotation.T @ d.qvel[channel.dof:channel.dof+3]
                positions.append(loc[:2])
                velocities.append(velocity[:2])
                geom_slide.append(m.geom_friction[channel.ball_geom, 0])
                assert m.geom_priority[channel.ball_geom] == m.geom_priority[face]
            assert m.geom_friction[face, 0] == geom_slide[0]
            observed.update(position=positions, velocity=velocities, slide=geom_slide)
            return result

        with patch.object(ball.BallController, "reset", record):
            out = short_track.run("combined", seed, configured(BASE["params"], recipe), timeout=45.)
    errors = {
        "max_abs_position_m": float(np.max(np.abs(predicted_p - observed["position"]))),
        "max_abs_velocity_m_s": float(np.max(np.abs(predicted_v - observed["velocity"]))),
        "max_abs_geom_slide": float(np.max(np.abs(predicted_mu - observed["slide"]))),
        "last_both_m": abs(row["last_both_m"] - out["last_both_m"]),
        "termination_s": abs(row["seconds"] - out["seconds"]),
    }
    assert max(errors.values()) < 1e-10 and out["reason"] == row["reason"], (seed, errors)
    return {
        "seed": seed, "actual_paddle_xy_m": np.asarray(observed["position"]).tolist(),
        "actual_world_linear_velocity_in_paddle_axes_m_s": np.asarray(observed["velocity"]).tolist(),
        "actual_geom_slide_A_B": observed["slide"], "actual_end_s": out["seconds"],
        "actual_end_reason": out["reason"], "errors": errors,
    }


def main():
    source = TRAINING / "fresh.csv"
    frozen = json.loads((TRAINING / "frozen.json").read_text())
    rows = []
    with source.open() as stream:
        for row in csv.DictReader(stream):
            if row["track"] == "combined" and row["name"] == "medium":
                seed = int(row["seed"])
                rows.append({"seed": seed, "seconds": float(row["seconds"]),
                             "last_both_m": float(row["last_both_m"]), "reason": row["reason"],
                             "features": features(*release(seed))})
    ids = [r["seed"] for r in rows]
    assert len(ids) == len(set(ids)) == frozen["seeds"]["n"] == 768
    assert min(ids) == frozen["seeds"]["seed"] and max(ids) == min(ids) + len(ids) - 1
    bins = {}
    for key in rows[0]["features"]:
        order = sorted(range(len(rows)), key=lambda i: (rows[i]["features"][key], ids[i]))
        bins[key] = np.array_split(order, 4)

    # First and last order statistic in each separation-rate quartile, chosen before replay.
    probes = [int(i) for bucket in bins["separation_rate_mm_s"] for i in (bucket[0], bucket[-1])]
    audits = [audit_release(rows[i], frozen["recipes"]["medium"]) for i in probes]
    report = {
        "source_csv": str(source.relative_to(HERE.parent)), "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
        "track": "combined", "recipe": frozen["recipes"]["medium"], "n": len(ids),
        "seed_range_inclusive": [min(ids), max(ids)],
        "method": {
            "grouping": "Rank all 768 releases by one feature at a time, increasing; break ties by seed. Four groups of 192. Same 768 episodes in each analysis.",
            "time": "Scored simulation elapsed from ball release to termination. Survived strictly beyond t means archived termination time > t, not a requirement for uninterrupted contact in every video frame.",
            "distance": "Archived signed horizontal progress at last valid simultaneous face contact, measured from release. Only the official task gate certifies successful crossing.",
            "release": "Reconstruct both initial positions and velocities using historical load_channel. B's RNG seed derives from (episode seed,20002); B must avoid A on release. Time zero of the real simulator check is immediately after BallController.reset, before the first scored physics step.",
            "radial": "d||q-p||/dt=(q-p) dot (vB-vA)/||q-p||. Coordinates are in instantaneous paddle axes. Velocity is world linear velocity projected into those axes. Shared rigid translation cancels, and frame rotation contributes zero radial component.",
            "time_to_diameter": "Solve ||gap+t*dv||=0.110 m for t>=0 using constant release velocities. This is a ranking proxy, not a measured fall time. In the real trial gravity, surface and ball contacts, motion of the duck and external disturbances alter velocities.",
            "friction": "Reconstruct the two independent material draws at release. The first sets paddle and A geom slide; the second sets B geom slide. For equal priority, A-face uses the first value and B-face uses their maximum.",
        },
        "limitations": [
            "Retrospective association in one frozen medium-speed policy/terrain and the original randomized material distribution. This analysis is not a randomized friction intervention.",
            "The same seeds are regrouped for different features. End-point, cut points, and features were observed on old records; these counts do not form a blind estimate for a new controller or a different friction range.",
            "The released physics state is observed only for diagnosis. A deployable controller has delayed noisy ball observations and cannot use the seed or perfect initial velocity.",
            "Changes to the friction band can change subsequent motion. Conditional release quartiles must not replace uniform independent starts for task acceptance.",
        ],
        "groups": {k: [group_report(rows, idx, k) for idx in parts] for k, parts in bins.items()},
        "real_reset_and_full_rollout_checks": audits,
    }
    out = HERE / "release_groups.json"
    out.write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + "\n")
    print(f"{len(rows)} historical starts, {len(audits)} verified complete replays -> {out.name}")


if __name__ == "__main__":
    main()
