"""Isolate sliding friction of the two ball–paddle contacts in the short-course simulator.

with surface('nominal', halfwidth=.01) as contacts:
    row = transfer.run('fixed', ...)
    # contacts[name] holds (original effective sliding mu, requested mu, twist, roll).
"""
from contextlib import contextmanager
from functools import lru_cache
from pathlib import Path
from unittest.mock import patch
import sys
import xml.etree.ElementTree as ET

import numpy as np

ROOT=Path(__file__).resolve().parents[1] / 'pingpong-dual16-short-20261128'
sys.path.insert(0,str(ROOT/'replay'))
import transfer
import fixed_ground
st=transfer.short_track
ball=st.course.ball
HISTORIC=.36446746630925014
NOMINAL=.32
ORIGINAL_HW=.096
NAMES=('ball_geom','ball_geom_b')

_build=st.course.template.__wrapped__
_add=ball.add_payload
_randomize=ball.BallChannel.randomize
_paired_short=lru_cache(maxsize=8)(st._template.__wrapped__)
_paired_fixed=lru_cache(maxsize=4)(fixed_ground.template.__wrapped__)

def _payload(root,*args,**kwargs):
    result=_add(root,*args,**kwargs)
    group=root.find('contact')
    if group is None:group=ET.SubElement(root,'contact')
    for name in NAMES:
        ET.SubElement(group,'pair',name='patch_'+name,geom1='paddle_face',geom2=name,
                      condim='6',solref='.006 .68',solimp='.94 .99 .001 .5 2',
                      friction='.32 .32 .003 .00002 .00002')
    return result

@lru_cache(maxsize=6)
def _paired_course(*args,**kwargs):
    with patch.object(ball,'add_payload',_payload):
        return _build(*args,**kwargs)

def transform(mu,mode,halfwidth=.01):
    if mode in ('native','wide'):return mu
    if mode=='nominal_fixed':return NOMINAL
    if mode=='historic_fixed':return HISTORIC
    if mode in ('nominal','historic'):
        centre=NOMINAL if mode=='nominal' else HISTORIC
        return centre+halfwidth*(mu-NOMINAL)/ORIGINAL_HW
    if mode=='historic_anchored':
        width=(NOMINAL+ORIGINAL_HW-HISTORIC) if mu>HISTORIC else HISTORIC-(NOMINAL-ORIGINAL_HW)
        return HISTORIC+halfwidth*((mu-HISTORIC)/width)
    raise ValueError(mode)

@contextmanager
def surface(mode,halfwidth=.01):
    if halfwidth<0:raise ValueError(halfwidth)
    transform(NOMINAL,mode,halfwidth)
    info={}
    if mode=='native':
        yield info
        return
    def randomize(channel,*args,**kwargs):
        result=_randomize(channel,*args,**kwargs)
        m=channel.m;face=m.geom('paddle_face').id
        for n in NAMES:
            g=m.geom(n).id
            fr=np.maximum(m.geom_friction[face],m.geom_friction[g])
            slide=transform(float(fr[0]),mode,halfwidth)
            pi=m.pair('patch_'+n).id
            m.pair_friction[pi]=[slide,slide,fr[1],fr[2],fr[2]]
            info[n]=(float(fr[0]),slide,float(fr[1]),float(fr[2]))
        return result
    with patch.object(st.course,'template',_paired_course),patch.object(st,'_template',_paired_short),patch.object(fixed_ground,'template',_paired_fixed),patch.object(ball.BallChannel,'randomize',randomize):
        yield info

if __name__=='__main__':
    import json
    params=json.loads((ROOT/'replay/fixed-paced-seal.json').read_text())
    cases=['native','wide','historic_fixed','nominal_fixed','historic_anchored','nominal','historic','native']
    for mode in cases:
        with surface(mode) as info:
            r=transfer.run('fixed',12600381,params['scale'],actions=params['actions'])
        if mode in ('native','wide','historic_fixed','historic_anchored'):assert r['last_both_m']==1.4344716654053211,mode
        print(mode,r['last_both_m'],r['seconds'],info,flush=True)
