"""Align delayed camera measurements and optionally reject cyclic paddle translation."""
from collections import deque
import numpy as np


def cross(a,b):
    return np.array([a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]])

class _PredictChannel:
    def __init__(self,d,b,params):
        self.d=d;self.b=b;self.p=dict(params)
        delay=self.p.pop('delay_gains',None)
        if (delay and 20*(b.act_lag+b.obs_lag)>=delay['min_total_ms'] and
                20*b.act_lag>=delay.get('min_command_ms',0)):
            self.p.update(delay['gains'])
        profile=self.p.pop('rolling_frame',None)
        self.rolling=None
        if (profile is not None and b.obs_lag*20>=profile.get('min_obs_ms',20)
                and b.act_lag*20>=profile.get('min_act_ms',0)):
            from camera_belief import CameraBelief
            self.rolling=CameraBelief()
            self.rolling_profile=profile
        first=self.frame()
        self.frames=deque([first]*(1+b.obs_lag),maxlen=1+b.obs_lag)
        self.last_center=first[0].copy()
        self.low_velocity=first[2][3:].copy()
        self.cycle_displacement=np.zeros(3)

    def frame(self):
        b=self.b;d=self.d
        return d.site_xpos[b.site].copy(),d.site_xmat[b.site].reshape(3,3).copy(),b.spatial.copy()

    def update(self):
        b=self.b;p=self.p;now=self.frame();self.frames.append(now)
        c,r,v=now
        z=b.measurements[0]
        if self.rolling is not None:
            self.rolling.observe(self.d,b)
            estimate=self.rolling.estimate(b)
            rp=self.rolling_profile
            z=np.r_[z[:2]+rp.get('position_mix',1.)*(estimate[:2]-z[:2]),
                    z[2:]+rp.get('velocity_mix',1.)*(estimate[2:]-z[2:])]
        elif b.obs_lag:
            c0,r0,v0=self.frames[0]
            arm0=r0[:,:2]@z[:2]+r0[:,2]*b.radius_m
            velocity=v0[3:]+cross(v0[:3],arm0)+r0[:,:2]@z[2:]
            gravity_tangent=5.886*(r0[:2,2]*r0[2,2])
            tau=.02*b.obs_lag
            arm=c0+arm0+tau*velocity-c
            arm[:2]+=.5*tau*tau*gravity_tangent
            velocity[:2]+=tau*gravity_tangent
            pred_p=r[:,:2].T@arm
            pred_v=r[:,:2].T@(velocity-v[3:]-cross(v[:3],arm))
            z=np.r_[z[:2]+p['position_mix']*(pred_p-z[:2]),z[2:]+p['velocity_mix']*(pred_v-z[2:])]
        if 'stride_velocity' in p:
            # Encoder and odometry motion estimates only. A moving average defines
            # the velocity of a smooth target point attached to the walking robot.
            alpha=.02/(p.get('stride_time_constant',.12)+.02)
            self.low_velocity+=alpha*(v[3:]-self.low_velocity)
            high=v[3:]-self.low_velocity
            self.cycle_displacement=(1-alpha)*(self.cycle_displacement+c-self.last_center-.02*self.low_velocity)
            self.last_center[:]=c
            z=z.copy()
            z[:2]+=p.get('stride_position',0.)*(r[:,:2].T@self.cycle_displacement)
            z[2:]+=p['stride_velocity']*(r[:,:2].T@high)
        b.measurements[0]=z


class PredictBall:
    def __init__(self,d,b,params):
        self.observers=[_PredictChannel(d,c,params) for c in b.channels]

    def update(self):
        for observer in self.observers:
            observer.update()
