"""Free rolling ping pong ball, rigid beak-mounted paddle and measured head controller."""
from collections import deque
import xml.etree.ElementTree as ET

import mujoco
import numpy as np

# Keep surface mass density and thin-shell inertia consistent with the 40 mm, 2.7 g ball.
RADIUS = 0.016
MASS = 0.0027 * (RADIUS / 0.020) ** 2
FACE_RADIUS = 0.055
DT = 0.02
HEAD = ("head_pitch", "head_roll")
DEFAULTS = dict(kp=4.2, kd=.85, level=1., gyro=.012, accel=0.,
                actuator_gain=3.2, actuator_damping=.075,
                velocity_limit=2.5, angle_limit=.62, slope_limit=.30,
                prediction=.025, gravity=1.)


def numbers(values):
    return " ".join(f"{v:.12g}" for v in values)


_BALL_COUNT = 1


def set_count(n):
    global _BALL_COUNT
    if n not in (1, 2):
        raise ValueError("Choose one 32 mm ball or two 20 mm balls")
    _BALL_COUNT = int(n)


def add_payload(root, neutral_model, neutral_data, mass_g=40., ball_count=None, diameter_mm=None):
    """Modify an assembled robot XML. Place a horizontal face in the given neutral posture."""
    jaw = neutral_data.body("jaw_soft")
    tip = neutral_data.site("mouth_tip")
    rot = jaw.xmat.reshape(3, 3)
    anchor = rot.T @ (tip.xpos + [0.066, 0., 0.008] - jaw.xpos)
    q = np.empty(4)
    mujoco.mju_mat2Quat(q, np.ascontiguousarray(rot.T).ravel())
    parent = root.find(".//body[@name='jaw_soft']")
    if parent is None:
        raise ValueError("Assemble robot XML includes before adding payload")
    body = ET.SubElement(parent, "body", name="paddle", pos=numbers(anchor), quat=numbers(q))
    if not 0 < mass_g < 1000: raise ValueError("Invalid paddle mass in grams")
    inertia=np.array([.000012,.000018,.000029])*(mass_g/18.)
    ET.SubElement(body,"inertial",pos="-.008 0 0",mass=str(mass_g*.001),diaginertia=numbers(inertia))
    contact = dict(condim="6", friction=".32 .003 .00002", solref=".006 .68",solimp=".94 .99 .001")
    ET.SubElement(body, "geom",name="paddle_face",type="cylinder",size=".055 .002",rgba=".12 .54 .62 1",
                  contype="16",conaffinity="8",**contact)
    ET.SubElement(body,"geom",name="paddle_handle",type="box",size=".025 .008 .0035",pos="-.055 0 -.005",
                  rgba=".75 .53 .22 1",contype="0",conaffinity="0")
    ET.SubElement(body,"site",name="paddle_center",type="sphere",size=".0015",pos="0 0 .002",rgba=".9 .92 .86 .9")
    n = _BALL_COUNT if ball_count is None else int(ball_count)
    if n not in (1, 2):
        raise ValueError("Unsupported number of balls")
    diameter = (32. if n == 1 else 20.) if diameter_mm is None else float(diameter_mm)
    if not np.isfinite(diameter) or not 0 < diameter <= 40:
        raise ValueError("Ball diameter must be positive and at most 40 mm")
    radius = diameter / 2000.
    mass = .0027 * (radius / .020) ** 2
    for i in range(n):
        tag = "" if i == 0 else "_b"
        center = tip.xpos + [.066, (i-.5)*.032 if n == 2 else 0., .010+radius]
        ball=ET.SubElement(root.find("worldbody"),"body",name="ball"+tag,pos=numbers(center))
        ET.SubElement(ball,"freejoint",name="ball_free"+tag)
        ET.SubElement(ball,"inertial",pos="0 0 0",mass=str(mass),diaginertia=numbers([2*mass*radius**2/3]*3))
        color = "1 .43 .045 1" if i == 0 else ".48 .88 .18 1"
        ET.SubElement(ball,"geom",name="ball_geom"+tag,type="sphere",size=str(radius),rgba=color,
                      contype="8",conaffinity="25" if n == 2 else "17",**contact)
        for key in root.findall("./keyframe/key"):
            if key.get("qpos"):
                key.set("qpos",key.get("qpos")+" "+numbers(center)+" 1 0 0 0")
            if key.get("qvel"):
                key.set("qvel",key.get("qvel")+" 0 0 0 0 0 0")


class BallChannel:
    def __init__(self, model, data, params=None, tag=""):
        self.m,self.d=model,data
        self.p=DEFAULTS.copy()
        params=dict(params or {})
        self.delay_gains=params.pop('delay_gains',None)
        self.kd_by_lag=params.pop('kd_by_lag',{})
        if params:
            unknown=set(params)-set(self.p)
            if unknown: raise ValueError(f"Unrecognized parameters {unknown}")
            self.p.update(params)
        self.nominal_params=self.p.copy()
        self.site=model.site("paddle_center").id
        self.face=model.geom("paddle_face").id
        self.ball_geom=model.geom("ball_geom"+tag).id
        self.adr=int(model.joint("ball_free"+tag).qposadr[0])
        self.dof=int(model.joint("ball_free"+tag).dofadr[0])
        self.radius_m=float(model.geom_size[self.ball_geom,0])
        self.mass_kg=float(model.body_mass[model.geom_bodyid[self.ball_geom]])
        self.actor = (tag == "")
        self.peer_geom = -1
        self.jids=np.array([model.joint(k).id for k in HEAD])
        self.acts=np.array([model.actuator(k).id for k in HEAD])
        self.qids=model.jnt_qposadr[self.jids]
        self.vids=model.jnt_dofadr[self.jids]
        self.bounds=model.jnt_range[self.jids]
        self.spatial=np.zeros(6)
        self.floor_geom_ids={g for g in range(model.ngeom) if model.geom_bodyid[g]==0}
        self.rootbody=model.body("trunk_base").id
        self.rootv=np.zeros(6)

    def state(self):
        d=self.d
        R=d.site_xmat[self.site].reshape(3,3)
        arm=d.qpos[self.adr:self.adr+3]-d.site_xpos[self.site]
        mujoco.mj_objectVelocity(self.m,d,mujoco.mjtObj.mjOBJ_SITE,self.site,self.spatial,0)
        w=self.spatial[:3]
        spin=np.array([w[1]*arm[2]-w[2]*arm[1],w[2]*arm[0]-w[0]*arm[2],w[0]*arm[1]-w[1]*arm[0]])
        rel=d.qvel[self.dof:self.dof+3]-self.spatial[3:]-spin
        return R.T@arm,R.T@rel

    def measurement(self,pos,vel):
        return np.r_[pos[:2],vel[:2]]+self.rng.standard_normal(4)*self.noise

    def new_pushes(self):
        self.push_ticks=(int(self.rng.integers(80,180)),int(self.rng.integers(255,400)))
        angles=self.rng.uniform(-np.pi,np.pi,2)
        self.push_local=(.018+.09*self.difficulty)*np.stack((np.cos(angles),np.sin(angles)),axis=1)

    def randomize(self,seed,difficulty):
        self.difficulty=float(difficulty)
        self.rng=np.random.default_rng(int(seed))
        p=self.p;m=self.m;d=self.d
        gain=p['actuator_gain']*(1+self.rng.uniform(-.18,.18,2)*difficulty)
        damping=p['actuator_damping']*(1+self.rng.uniform(-.18,.18,2)*difficulty)
        if self.actor:
            m.actuator_gainprm[self.acts,0]=gain
            m.actuator_biasprm[self.acts,1]=-gain
            m.actuator_biasprm[self.acts,2]=-damping
        self.gain=gain
        friction=(1+self.rng.uniform(-.30,.30)*difficulty)*np.array([.32,.003,.00002])
        if self.actor:
            m.geom_friction[self.face]=friction
        m.geom_friction[self.ball_geom]=friction
    def prepare(self,seed,difficulty=1.):
        """Start the empty-paddle settling interval using the actual head servos."""
        self.p=self.nominal_params.copy()
        self.randomize(seed,difficulty)
        self.home=self.d.qpos[self.qids].copy()
        self.command=self.home.copy()
        self.prepared=True
        self.empty_commands=deque([self.command.copy()]*3,maxlen=3)

    def level_empty(self):
        R=self.d.site_xmat[self.site].reshape(3,3)
        local=self.d.xaxis[self.jids]@R
        a,b=local[:,1];c,e=-local[:,0]
        det=a*e-b*c
        if abs(det)<.12:det=np.copysign(.12,det or 1.)
        x,y=R[2,:2]
        offset=np.array([(e*x-b*y)/det,(a*y-c*x)/det])
        goal=self.d.qpos[self.qids]+offset+self.d.qfrc_bias[self.vids]/self.gain
        goal=np.clip(goal,np.maximum(self.bounds[:,0],self.home-self.p['angle_limit']),np.minimum(self.bounds[:,1],self.home+self.p['angle_limit']))
        self.empty_commands.append(goal)
        self.command+=np.clip(self.empty_commands[0]-self.command,-self.p['velocity_limit']*DT,self.p['velocity_limit']*DT)
        self.d.ctrl[self.acts]=self.command

    def reset(self,seed,difficulty=1.,occupied=None,command_lag=None):
        self.p=self.nominal_params.copy()
        self.randomize(seed,difficulty)
        d=self.d
        m=self.m
        for _ in range(10000):
            ang=self.rng.uniform(-np.pi,np.pi)
            offset=self.rng.uniform(.006,.014+.018*difficulty)*np.array([np.cos(ang),np.sin(ang)])
            if occupied is None or np.linalg.norm(offset-occupied)>=max(.020,2*self.radius_m)+.0004:
                break
        else:
            raise ValueError("No nonoverlapping initial position meets the release distribution")

        vel=self.rng.uniform(-.015-.044*difficulty,.015+.044*difficulty,2)
        R=d.site_xmat[self.site].reshape(3,3)
        d.qpos[self.adr:self.adr+3]=d.site_xpos[self.site]+R@np.r_[offset,self.radius_m+.0002]
        d.qpos[self.adr+3:self.adr+7]=[1,0,0,0]
        d.qvel[self.dof:self.dof+3]=R@np.r_[vel,0.]
        d.qvel[self.dof+3:self.dof+6]=R@np.array([-vel[1],vel[0],0.])/self.radius_m
        mujoco.mj_forward(m,d)
        if not getattr(self,"prepared",False):
            self.home=d.qpos[self.qids].copy()
            self.command=self.home.copy()
        self.noise=np.array([.0005,.0005,.004,.004])*difficulty
        self.obs_lag=int(self.rng.integers(0,round(2*difficulty)+1))
        self.act_lag=int(self.rng.integers(0,round(2*difficulty)+1))
        if command_lag is not None: self.act_lag=command_lag
        if self.delay_gains is not None:
            branch=self.delay_gains
            if (20*(self.act_lag+self.obs_lag)>=branch['min_total_ms'] and
                    20*self.act_lag>=branch.get('min_command_ms',0)):
                gains=branch['gains']
                allowed={'kp','kd','level','gyro','accel','prediction','velocity_limit','slope_limit','actuator_damping'}
                if set(gains)-allowed:raise ValueError('Unsupported delay-scheduled feedback gain')
                if 'actuator_damping' in gains and self.actor:
                    self.m.actuator_biasprm[self.acts,2]*=gains['actuator_damping']/self.p['actuator_damping']
                self.p.update(gains)
        self.p['kd']*=self.kd_by_lag.get(f'{20*self.obs_lag}/{20*self.act_lag}',1.)
        self.measurements=deque([self.measurement(*self.state())]*(1+self.obs_lag),maxlen=1+self.obs_lag)
        self.commands=deque([self.command.copy()]*(1+self.act_lag),maxlen=1+self.act_lag)
        self.air=0;self.tick=0;self.push_count=0;self.radii=[];self.max_air=0
        mujoco.mj_objectVelocity(m,d,mujoco.mjtObj.mjOBJ_BODY,self.rootbody,self.rootv,0)
        self.prev_body_v=self.rootv[3:].copy();self.body_a=np.zeros(3)
        self.new_pushes()

    def control(self, estimate=None):
        p=self.p;d=self.d;m=self.m
        z=self.measurements[0] if estimate is None else estimate
        R=d.site_xmat[self.site].reshape(3,3)
        target=-p['kp']*(z[:2]+p['prediction']*z[2:])-p['kd']*z[2:]
        mujoco.mj_objectVelocity(m,d,mujoco.mjtObj.mjOBJ_BODY,self.rootbody,self.rootv,0)
        v=self.rootv[3:]
        self.body_a=.75*self.body_a+.25*(v-self.prev_body_v)/DT
        self.prev_body_v[:]=v
        target+=p['accel']*(R.T@self.body_a)[:2]/9.81
        if hasattr(self,'plate_bias'):target+=self.plate_bias
        target=np.clip(target,-p['slope_limit'],p['slope_limit'])
        # Compute the two-axis tilt Jacobian directly from the joint axes, expressed in the paddle frame.
        local_axis=d.xaxis[self.jids]@R
        a,b=local_axis[:,1];c,e=-local_axis[:,0];det=a*e-b*c
        x,y=target+p['level']*R[2,:2]
        w=R.T@self.spatial[:3]
        x-=p['gyro']*w[1];y+=p['gyro']*w[0]
        if abs(det)<.12:det=np.copysign(.12,det or 1.)
        correction=np.array([(e*x-b*y)/det,(a*y-c*x)/det])
        proposed=d.qpos[self.qids]+correction+p['gravity']*d.qfrc_bias[self.vids]/self.gain
        low=np.maximum(self.bounds[:,0],self.home-p['angle_limit'])
        high=np.minimum(self.bounds[:,1],self.home+p['angle_limit'])
        self.commands.append(np.clip(proposed,low,high))
        self.command+=np.clip(self.commands[0]-self.command,-p['velocity_limit']*DT,p['velocity_limit']*DT)
        d.ctrl[self.acts]=self.command
        self.apply_push()

    def apply_push(self):
        d=self.d; R=d.site_xmat[self.site].reshape(3,3)
        if self.tick and self.tick%500==0:self.new_pushes()
        k=self.tick%500
        if k in self.push_ticks:
            impulse=self.push_local[self.push_ticks.index(k)]
            d.qvel[self.dof:self.dof+3]+=R[:,:2]@impulse
            self.push_count+=1

    def observe(self):
        state=self.state();pos,vel=state
        self.measurements.append(self.measurement(pos,vel))
        on=False;other=False
        for ct in self.d.contact:
            if ct.dist > 0.: continue
            a,b=ct.geom1,ct.geom2
            if a==self.ball_geom: other_id=b
            elif b==self.ball_geom:other_id=a
            else:continue
            if other_id==self.face:on=True
            elif other_id!=self.peer_geom:other=True
        self.air=0 if on else self.air+1
        self.max_air=max(self.max_air,self.air);self.tick+=1
        radius=float(np.linalg.norm(pos[:2]))
        self.radii.append(radius)
        failure=''
        if other:failure='ball_other_contact'
        elif radius>FACE_RADIUS+.002:failure='ball_edge'
        elif pos[2]<self.radius_m-.006:failure='ball_below'
        elif self.air>9:failure='ball_air'
        elif not np.isfinite(pos).all():failure='ball_nonfinite'
        return failure,radius,on


class BallController:
    """Two observed objects share one pitch/roll actuator command."""
    def __init__(self, model, data, params=None):
        params=dict(params or {})
        self.dual_feedback=params.pop('dual_feedback', {})
        self.channels=[BallChannel(model,data,params)]
        if mujoco.mj_name2id(model,mujoco.mjtObj.mjOBJ_GEOM,'ball_geom_b') >= 0:
            self.channels.append(BallChannel(model,data,params,tag='_b'))
            self.channels[0].peer_geom=self.channels[1].ball_geom
            self.channels[1].peer_geom=self.channels[0].ball_geom
        self.n_balls=len(self.channels)
        self.ball_geoms=tuple(c.ball_geom for c in self.channels)
        self.last_radii=[0.]*self.n_balls
        self.last_contacts=[False]*self.n_balls
        self.radius_m=self.channels[0].radius_m
        self.mass_kg=self.channels[0].mass_kg
        self.radii=[]

    def __getattr__(self, attr):
        return getattr(self.channels[0],attr)

    @property
    def push_count(self):
        return sum(c.push_count for c in self.channels)

    @property
    def max_air(self):
        return max(c.max_air for c in self.channels)

    def park(self):
        for i,c in enumerate(self.channels):
            c.d.qpos[c.adr:c.adr+3]=[-.65,.42+.09*i,c.radius_m+.001]
            c.d.qvel[c.dof:c.dof+6]=0.

    def reset(self,seed,difficulty=1.):
        a=self.channels[0]
        a.reset(seed,difficulty)
        if self.n_balls==2:
            b=self.channels[1]
            second_seed=int(np.random.SeedSequence([int(seed),20002]).generate_state(1)[0])
            b.reset(second_seed,difficulty,occupied=a.state()[0][:2],command_lag=a.act_lag)
        self.radii=[]
        self.last_radii=[float(np.linalg.norm(c.state()[0][:2])) for c in self.channels]
        self.last_contacts=[False]*self.n_balls

    def stop_ready(self, radius, velocity):
        return all(np.linalg.norm(c.measurements[0][:2])<radius and
                   np.linalg.norm(c.measurements[0][2:])<velocity for c in self.channels)

    def control(self):
        a=self.channels[0]
        if self.n_balls==1:
            a.control()
            return
        b=self.channels[1]
        # Weight the two measured positions by their predicted radial risk. One
        # common pair of actuator angles acts on both independent free bodies.
        p=self.dual_feedback
        z0,z1=a.measurements[0],b.measurements[0]
        horizon=p.get('lookahead_s',.11)
        r0=np.linalg.norm(z0[:2]+horizon*z0[2:])
        r1=np.linalg.norm(z1[:2]+horizon*z1[2:])
        w=.5+.5*p.get('edge_mix',.65)*np.tanh((r0-r1)/p.get('edge_width_m',.018))
        target=w*z0+(1.-w)*z1
        a.control(target)
        b.apply_push()

    def observe(self):
        observations=[c.observe() for c in self.channels]
        self.last_radii=[v[1] for v in observations]
        self.last_contacts=[v[2] for v in observations]
        radius=max(self.last_radii)
        self.radii.append(radius)
        for i,(reason,_,_) in enumerate(observations):
            if reason:
                return reason if i==0 else reason+'_b',radius,all(self.last_contacts)
        return '',radius,all(self.last_contacts)
