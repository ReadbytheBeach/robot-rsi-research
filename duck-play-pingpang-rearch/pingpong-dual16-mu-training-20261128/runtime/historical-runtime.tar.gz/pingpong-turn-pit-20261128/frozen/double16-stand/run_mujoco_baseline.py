"""Model locations and joint-order contract for the archived local simulator."""
import os
from pathlib import Path
import numpy as np

DEFAULT_SCENE = Path(os.environ["MICRODUCK_SCENE"]).resolve()
DEFAULT_POLICY = Path(os.environ["MICRODUCK_POLICY"]).resolve()

POLICY_JOINTS = (
    "left_hip_yaw",
    "left_hip_roll",
    "left_hip_pitch",
    "left_knee",
    "left_ankle",
    "neck_pitch",
    "head_pitch",
    "head_yaw",
    "head_roll",
    "right_hip_yaw",
    "right_hip_roll",
    "right_hip_pitch",
    "right_knee",
    "right_ankle",
)

HOME_POSE = np.asarray(
    [
        0.0,
        -0.0873,
        -0.4579,
        -0.0049,
        0.4530,
        0.3491,
        0.3491,
        0.0,
        0.0,
        0.0,
        0.0873,
        0.4579,
        0.0049,
        -0.4530,
    ],
    dtype=np.float32,
)
