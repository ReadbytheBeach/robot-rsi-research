"""Metric centerline, route projection and physical surface heights for option B."""
import math

import numpy as np

LENGTH = 10.0
LAT_SHIFT = 2.0
BEND_DX = 5.5
OMEGA = math.pi / BEND_DX
# Equal straight sections bracket the half-cosine bend. The cumulative chord
# length converges to the analytic arc length without a runtime integrator.
BEND_GRID = 8192
u = np.linspace(0.0, BEND_DX, BEND_GRID + 1)
v = 0.5 * LAT_SHIFT * (1 - np.cos(OMEGA * u))
arc = np.r_[0.0, np.cumsum(np.hypot(np.diff(u), np.diff(v)))]
BEND_LENGTH = float(arc[-1])
BEND_X0 = (LENGTH - BEND_LENGTH) / 2
BEND_X1 = BEND_X0 + BEND_DX
BEND_S1 = BEND_X0 + BEND_LENGTH
END_X = BEND_X1 + BEND_X0
X_STEP = BEND_DX / BEND_GRID


def _arc_at_u(a):
    i = min(BEND_GRID - 1, int(a / X_STEP))
    part = (a - i * X_STEP) / X_STEP
    return arc[i] + part * (arc[i+1] - arc[i])


def center(s):
    """Centerline xy at progress s; straight tangents extend beyond endpoints."""
    if s <= BEND_X0:
        return float(s), 0.
    if s >= BEND_S1:
        return float(BEND_X1 + s - BEND_S1), LAT_SHIFT
    a = float(np.interp(s - BEND_X0, arc, u))
    return BEND_X0 + a, 0.5 * LAT_SHIFT * (1. - math.cos(OMEGA * a))


def tangent(s):
    if s <= BEND_X0 or s >= BEND_S1:
        return 0.
    a = float(np.interp(s - BEND_X0, arc, u))
    return math.atan(0.5 * LAT_SHIFT * OMEGA * math.sin(OMEGA * a))


def project(x, y):
    """Orthogonal centerline progress and signed cross-track error in metres."""
    if x <= BEND_X0:
        return float(x), float(y)
    if x >= BEND_X1:
        return float(BEND_S1 + x - BEND_X1), float(y - LAT_SHIFT)
    a = float(x - BEND_X0)
    for _ in range(3):
        c = math.cos(OMEGA * a)
        slope = .5 * LAT_SHIFT * OMEGA * math.sin(OMEGA * a)
        q = .5 * LAT_SHIFT * (1 - c) - y
        f = a - (x - BEND_X0) + q * slope
        der = 1 + slope * slope + q * .5 * LAT_SHIFT * OMEGA**2 * c
        a = min(BEND_DX, max(0., a - f / der))
        if abs(f) < 1.e-9:
            break
    side = math.atan(.5 * LAT_SHIFT * OMEGA * math.sin(OMEGA * a))
    cross = (y - .5 * LAT_SHIFT * (1 - math.cos(OMEGA * a))) * math.cos(side)
    cross -= (x - (BEND_X0 + a)) * math.sin(side)
    return float(BEND_X0 + _arc_at_u(a)), float(cross)


CRESTS = ((1.60, .53, .008), (6.80, .54, .030))
PIT_X = 7.90
PIT_WIDTH = .24
PIT_DEPTH = .012
PIT_S = project(PIT_X, LAT_SHIFT)[0]
# The surface profile is extruded across the whole width of the physical floor.
# Positive and negative elevations are encoded relative to a single datum.
XZ = np.linspace(-1., 11., 601)
HZ = np.zeros_like(XZ)
for x, halfwidth, height in CRESTS:
    q = (XZ - x) / halfwidth
    HZ += np.where(np.abs(q) <= 1., .5 * height * (1. + np.cos(np.pi * q)), 0.)
# A reproducible V depression with both lips 0.24 m apart.
HZ -= PIT_DEPTH * np.maximum(0., 1. - np.abs(XZ - PIT_X) / (.5 * PIT_WIDTH))


def ground_height(x, y=None):
    return np.interp(x, XZ, HZ, left=0., right=0.)


def verify_geometry():
    """Compare ideal geometry to physical vertical rays and reconstruct normal offsets."""
    import mujoco
    import locomotion
    from scipy.integrate import quad
    from scipy.optimize import brentq

    model = locomotion.build_model(terrain=True, payload=False)
    data = mujoco.MjData(model)
    mujoco.mj_forward(model, data)
    floor = model.geom("floor").id
    vertical_down = np.asarray([0., 0., -1.])

    def ray(x, y):
        start = np.asarray([x, y, .4])
        distance = mujoco.mj_rayHfield(model, data, floor, start, vertical_down)
        assert distance > 0., (x,y)
        return float(.4-distance)

    arc_integral = quad(lambda a: math.hypot(1, math.pi/BEND_DX*math.sin(OMEGA*a)), 0, BEND_DX)[0]
    route_length = 2*BEND_X0 + arc_integral
    assert abs(route_length - LENGTH) < 1e-7 and np.allclose(center(10), [END_X, 2])
    # The isolated normal-coordinate test covers the entire accepted +/-0.55 m corridor.
    max_err = 0.
    for s in np.linspace(-.2, 10.3, 251):
        x, y = center(s)
        angle = tangent(s)
        for side in np.linspace(-.55,.55,7):
            result = project(x-side*math.sin(angle), y+side*math.cos(angle))
            max_err = max(max_err, abs(result[0]-s), abs(result[1]-side))
    assert max_err < 1.e-6, max_err
    specs = [('gentle_crest',CRESTS[0][0]),('steep_crest',CRESTS[1][0]),
             ('pit_near_lip',PIT_X-.5*PIT_WIDTH),('pit_bottom',PIT_X),
             ('pit_far_lip',PIT_X+.5*PIT_WIDTH),('flat',END_X)]
    probes = {}
    for name, x in specs:
        station = brentq(lambda s:center(s)[0]-x,-.5,10.5)
        _, y = center(station)
        readings = [ray(x,y+off) for off in (-.55,0.,.55)]
        assert all(abs(val-ground_height(x)) < 2e-8 for val in readings)
        probes[name] = dict(x_m=x, station_m=station, y_m=y, heights_m=readings)
    assert abs(probes['pit_bottom']['heights_m'][1]+.012) < 2e-8
    angles = []
    for xp, half, _ in CRESTS:
        grid = XZ[(XZ>=xp-half)&(XZ<=xp+half)]
        # Stay inside each contact triangle. Rays exactly shared by grid faces
        # can land on the hfield base in MuJoCo's ray/triangle routine.
        slopes = []
        for left, right in zip(grid[:-1], grid[1:]):
            a = left + .25*(right-left)
            b = right - .25*(right-left)
            slopes.append(abs(ray(b,.993)-ray(a,.993))/(b-a))
        angles.append(float(np.rad2deg(np.arctan(max(slopes)))))
    assert 4.8 < angles[1] < 5.1 and angles[0] < 2.
    return dict(arc_length_m=route_length, end_xy_m=center(10.), max_curve_angle_deg=math.degrees(tangent(5.)),
                maximum_projection_error_m=max_err, crest_max_ray_slope_deg=angles, physical_ray_probes=probes)


if __name__ == '__main__':
    import json
    print(json.dumps(verify_geometry(),indent=2))
