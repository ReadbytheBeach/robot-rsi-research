/* Read-only diagnostics for the solver at 500 Hz. */
#include <math.h>
#include <mujoco/mujoco.h>

static void motor_sample(const mjModel *m, const mjData *d, double *stats) {
    for (int j=0; j<m->nu; ++j) {
        double torque=fabs(d->actuator_force[j]);
        int joint=m->actuator_trnid[2*j];
        double speed=fabs(d->qvel[m->jnt_dofadr[joint]]);
        double cap=m->actuator_forcerange[2*j+1];
        double *v=stats+7*j;
        v[0]+=torque*torque;
        if(torque>v[1])v[1]=torque;
        if(speed>v[2])v[2]=speed;
        if(torque>=.9*cap) {v[3]++;v[4]++;if(v[4]>v[5])v[5]=v[4];} else {v[4]=0.;}
        v[6]+=torque*speed*m->opt.timestep;
    }
}


/* ids are floor, left foot, right foot, face, handle, first ball, second ball.
   contacts are global floor/clearance statistics followed by independent
   records for each ball. All samples follow actual 2 ms solver steps. */
static void contact_sample(const mjModel *m, const mjData *d, const int *ids, int count,
                           double floor_upper, double *summary, double *records) {
    int floor=ids[0], face=ids[3], handle=ids[4], nonfoot=0, pair=0;
    int on_face[2]={0,0}, other[2]={0,0};
    for(int k=0; k<d->ncon; ++k) {
        const mjContact *ct=d->contact+k;
        if(ct->dist>0.) continue;
        int a=ct->geom[0], b=ct->geom[1];
        if(a==floor || b==floor) {
            int g=(a==floor)?b:a;
            if(g!=ids[1] && g!=ids[2] && g!=ids[5] && (count<2 || g!=ids[6])) nonfoot=1;
        }
        for(int i=0; i<count; ++i) {
            int ball=ids[5+i];
            if(a!=ball && b!=ball) continue;
            int g=(a==ball)?b:a;
            if(g==face) on_face[i]=1;
            else if(count==2 && g==ids[6-i]) pair=1;
            else other[i]=1;
        }
    }
    summary[0]+=nonfoot; summary[1]+=pair;
    const double *r=d->geom_xmat+9*face, *size=m->geom_size+3*face;
    double face_low=d->geom_xpos[3*face+2]-size[0]*hypot(r[6],r[7])-size[1]*fabs(r[8])-floor_upper;
    const double *h=d->geom_xmat+9*handle, *half=m->geom_size+3*handle;
    double handle_low=d->geom_xpos[3*handle+2]-half[0]*fabs(h[6])-half[1]*fabs(h[7])-half[2]*fabs(h[8])-floor_upper;
    if(face_low<summary[2])summary[2]=face_low;
    if(handle_low<summary[3])summary[3]=handle_low;
    summary[4]+=(on_face[0] && (count==1 || on_face[1]));
    summary[5]+=(other[0] || (count==2 && other[1]));
    for(int i=0;i<count;++i) {
        double *c=records+8*i;
        c[0]+=other[i];c[1]+=on_face[i];
        c[2]=on_face[i]?0.:c[2]+1.;
        if(c[2]>c[3])c[3]=c[2];
        int ball=ids[5+i];
        const double *pos=d->geom_xpos+3*ball, *origin=d->geom_xpos+3*face;
        double dx=pos[0]-origin[0],dy=pos[1]-origin[1],dz=pos[2]-origin[2];
        double x=r[0]*dx+r[3]*dy+r[6]*dz, y=r[1]*dx+r[4]*dy+r[7]*dz;
        double z=r[2]*dx+r[5]*dy+r[8]*dz-size[1];
        double radius=hypot(x,y);
        if(radius>c[4])c[4]=radius;
        if(radius>size[0]+.002)c[5]++;
        if(z<m->geom_size[3*ball]-.006)c[6]++;
        c[7]=on_face[i];
    }
}

void audited_payload_steps(const mjModel *m, mjData *d, int n, double *stats,
                           const int *ids, int count, double upper,
                           double *summary, double *records) {
    for(int s=0;s<n;++s) {
        mj_step(m,d);
        motor_sample(m,d,stats);
        contact_sample(m,d,ids,count,upper,summary,records);
    }
}
