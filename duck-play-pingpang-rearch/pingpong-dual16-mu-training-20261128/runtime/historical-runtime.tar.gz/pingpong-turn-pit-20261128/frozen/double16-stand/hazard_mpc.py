"""Nominal MuJoCo receding-horizon fall recovery for a surveyed crest and ditch."""
from collections import deque
import math
import time

import mujoco
import numpy as np

import ball
import locomotion as loc
from path_geom import ground_height
from terrain_stance import correct,joint_impedance,velocity_catch

# Symmetric hip/knee/ankle trim, neck trim, swing-knee and swing-ankle trim (rad).
DEFAULT_ACTIONS=[
    [0.,0.,0.,0.,0.,0.],
    [.18,-.18,.22,.12,-.10,.08],
    [-.22,.14,.17,.18,-.16,-.10],
    [-.18,-.23,-.15,.10,.12,-.08],
    [.10,.16,-.20,-.12,-.12,.12],
    [-.36,.02,.34,.30,0.,0.],
    [.26,-.32,.13,.22,-.24,.05],
    [.08,-.12,-.20,-.12,.26,-.12],
]


class HazardMPC:
    """Candidate selection using independent nominal physics and current robot observations."""
    def __init__(self,params):
        self.params=params
        self.cfg=params['hazard_mpc']
        self.actions=np.asarray(self.cfg.get('actions',DEFAULT_ACTIONS),float)*self.cfg.get('action_scale',1.)
        if self.actions.ndim!=2 or self.actions.shape[1]!=6 or np.any(self.actions[0]):
            raise ValueError('A six-column action bank with neutral first proposal is required')
        self.active=0; self.trigger_time=-1.; self.records=[]; self.forecast=None
        self.camera_history=None

    def observe_camera(self,d,seen):
        if self.camera_history is None:
            from camera_belief import CameraBelief
            self.camera_history=CameraBelief()
        self.camera_history.observe(d,seen.channels[0])

    def apply_action(self,d,w,idx):
        if idx==0:return
        hip,knee,ankle,neck,swing_knee,swing_ankle=self.actions[idx]
        # Foot height supplies a smooth side-specific phase estimate from forward kinematics.
        lh=d.geom_xpos[w.feet[0],2];rh=d.geom_xpos[w.feet[1],2]
        ls=.5+.5*np.tanh((lh-rh)/.008)
        for sign,offset,weight in ((1.,0,ls),(-1.,9,1.-ls)):
            d.ctrl[w.acts[offset+2]]+=sign*hip
            d.ctrl[w.acts[offset+3]]+=sign*(knee+weight*swing_knee)
            d.ctrl[w.acts[offset+4]]+=sign*(ankle+weight*swing_ankle)
        d.ctrl[w.acts[5]]+=neck
        d.ctrl[w.acts]=np.clip(d.ctrl[w.acts],w.model.jnt_range[w.model.actuator_trnid[w.acts,0],0],
                                 w.model.jnt_range[w.model.actuator_trnid[w.acts,0],1])

    def apply(self,d,w):
        self.apply_action(d,w,self.active)

    def create_forecast(self,n):
        m=loc.build_model(terrain=self.cfg.get('terrain',True),payload=True,mass_g=self.params['mass_g'],balls=n,diameter_mm=self.params.get('ball_diameter_mm'))
        d=mujoco.MjData(m)
        w=loc.Locomotion(m);w.route_params.update(self.params.get('route_params',{}))
        w.reset(d,0)
        # Use nominal foot friction and actuator parameters. Sensors/commands supply
        # the initial condition every time; no held-out friction, gains or RNG copied.
        m.geom_friction[np.r_[w.floor,w.feet],0]=self.cfg.get('nominal_friction',.98)
        m.actuator_gainprm[w.acts,0]=w.kp
        m.actuator_biasprm[w.acts,1]=w.bias
        m.actuator_forcelimited[:]=1
        m.actuator_forcerange[:,0]=np.maximum(m.actuator_forcerange[:,0],-self.params['motor_cap_nm'])
        m.actuator_forcerange[:,1]=np.minimum(m.actuator_forcerange[:,1],self.params['motor_cap_nm'])
        bc=ball.BallController(m,d,self.params.get('ball',{}))
        bc.prepare(0,0.);bc.reset(0,0.)
        self.forecast=m,d,w,bc
        self.pose_ids=np.array([0,1,2,3,4,9,10,11,12,13])
        self.target_range=m.jnt_range[m.actuator_trnid[w.acts,0],:].copy()

    def initialize(self,actual_walk,measured,seen):
        m,d,w,bc=self.forecast
        # Free-base pose/velocity are the same IMU/odometry interface used by walking.
        # Copy only robot coordinates and previously issued targets, excluding both
        # simulated ball states, solver warm-start, injected pushes, gains and noise.
        mujoco.mj_resetData(m,d)
        robot_q=bc.channels[0].adr; robot_v=bc.channels[0].dof
        d.qpos[:robot_q]=measured.qpos[:robot_q]
        d.qvel[:robot_v]=measured.qvel[:robot_v]
        d.ctrl[:]=measured.ctrl
        w.last[:]=actual_walk.last
        w.smoothed=actual_walk.smoothed.copy()
        w.y0=actual_walk.y0
        mujoco.mj_forward(m,d)
        for ch,obs in zip(bc.channels,seen.channels):
            exposure=obs.measurements[0]
            z=(self.camera_history.estimate(obs) if self.camera_history is not None else exposure)
            r=d.site_xmat[ch.site].reshape(3,3)
            local=np.r_[z[:2],ch.radius_m]
            arm=r@local
            d.qpos[ch.adr:ch.adr+3]=d.site_xpos[ch.site]+arm
            d.qpos[ch.adr+3:ch.adr+7]=[1.,0.,0.,0.]
            mujoco.mj_objectVelocity(m,d,mujoco.mjtObj.mjOBJ_SITE,ch.site,ch.spatial,0)
            world_v=ch.spatial[3:]+np.cross(ch.spatial[:3],arm)+r[:,:2]@z[2:]
            d.qvel[ch.dof:ch.dof+3]=world_v
            d.qvel[ch.dof+3:ch.dof+6]=r@np.array([-z[3],z[2],0.])/ch.radius_m
            ch.p=obs.p.copy()  # deployed controller gains, not simulated plant gains
            if ch.actor:
                m.actuator_gainprm[ch.acts,0]=ch.p['actuator_gain']
                m.actuator_biasprm[ch.acts,1]=-ch.p['actuator_gain']
                m.actuator_biasprm[ch.acts,2]=-ch.p['actuator_damping']
                ch.gain=np.full(2,ch.p['actuator_gain'])
            ch.home=obs.home.copy();ch.command=obs.command.copy()
            ch.obs_lag=obs.obs_lag;ch.act_lag=obs.act_lag
            # Fill unseen exposures using only the last delivered detection and
            # historical encoder frames. The live camera's pending FIFO is private.
            samples=([self.camera_history.estimate(obs,steps=j) for j in range(1+obs.obs_lag)]
                     if self.camera_history is not None else [exposure.copy() for _ in range(1+obs.obs_lag)])
            ch.measurements=deque(samples,maxlen=1+obs.obs_lag)
            ch.commands=deque([np.array(v,copy=True) for v in obs.commands],maxlen=obs.commands.maxlen)
            ch.tick=0;ch.push_ticks=();ch.radii=[];ch.air=0;ch.max_air=0
            ch.noise=np.zeros(4);ch.prev_body_v=measured.qvel[:3].copy();ch.body_a=np.zeros(3)
        bc.radii=[]
        mujoco.mj_forward(m,d)

    def drive_forecast(self,speed):
        p=self.params
        m,d,w,bc=self.forecast
        w.control(d,speed)
        ids=w.acts; neck=ids[[5,7]];h=loc.HOME_POSE[[5,7]]
        d.ctrl[neck]=h+p['neck_mix']*(d.ctrl[neck]-h)
        d.ctrl[ids[2]]+=p.get('hip_trim',0.);d.ctrl[ids[11]]-=p.get('hip_trim',0.)
        d.ctrl[ids[4]]+=p.get('ankle_trim',0.);d.ctrl[ids[13]]-=p.get('ankle_trim',0.)
        d.ctrl[ids[5]]+=p.get('neck_trim',0.)
        if 'leg_scale' in p:
            legs=ids[self.pose_ids];h=loc.HOME_POSE[self.pose_ids]
            d.ctrl[legs]=h+p['leg_scale']*(d.ctrl[legs]-h)
            d.ctrl[ids[3]]+=p['knee_trim'];d.ctrl[ids[12]]-=p['knee_trim']
            pitch=-d.xmat[w.trunk,6];rate=d.sensordata[w.gyro+1]
            corr=p.get('pitch_feedback',0.)*pitch+p.get('pitch_rate',0.)*rate
            d.ctrl[ids[2]]+=corr;d.ctrl[ids[11]]-=corr
            corr=p.get('roll_feedback',0.)*d.xmat[w.trunk,7]+p.get('roll_rate',0.)*d.sensordata[w.gyro]
            d.ctrl[ids[1]]+=corr;d.ctrl[ids[10]]+=corr
        correct(d,w,p);joint_impedance(d,w,p);velocity_catch(d,w,p)

    def future_cost(self,w_actual,d_actual,observed,speed,idx):
        self.initialize(w_actual,d_actual,observed)
        m,d,w,bc=self.forecast
        x0=d.qpos[w.root];worst=0.;total=0.;last=0.
        steps=round(self.cfg.get('horizon_s',.74)/.02)
        for k in range(steps):
            self.drive_forecast(speed);self.apply_action(d,w,idx);bc.control()
            mujoco.mj_step(m,d,nstep=10);mujoco.mj_forward(m,d)
            failure,radius,_=bc.observe()
            x,y,z=d.qpos[w.root:w.root+3]
            floor=ground_height(x);pitch=-float(d.xmat[w.trunk,6]);roll=float(d.xmat[w.trunk,7])
            orient=math.hypot(pitch,roll)
            height=z-floor
            # Penalize peak lean and low trunk before the fall limit. Penalize a
            # forecast ball crossing the rim and protect both directions of tilt.
            rad_penalty=max(0.,(radius-.034)/.023)
            if self.cfg.get('body_only',False):rad_penalty=min(.6,rad_penalty)
            last=1.8*max(0.,orient-.13)+2.4*max(0.,pitch-.13)+5.*max(0.,.114-height)+.52*rad_penalty
            worst=max(worst,last);total+=last
            if d.xmat[w.trunk,8]<.67 or height<.072 or (failure and not self.cfg.get('body_only',False)):
                return 5.5+2.*(1-(k+1)/steps)+min(1.5,last)
        progress=(x-x0)/(steps*.02)
        return worst+(.45*total/steps)+.45*last+self.cfg.get('progress_weight',.25)*max(0.,.068-progress)

    def update(self,w,d,seen,speed):
        if self.cfg.get('camera_belief'):self.observe_camera(d,seen)
        x=float(d.qpos[w.root]); cfg=self.cfg
        if not any(lo<=x<=hi for lo,hi in cfg.get('intervals',[[6.92,7.32],[7.74,8.10]])):
            self.active=0
            return
        if d.time<self.trigger_time:return
        self.trigger_time=d.time+cfg.get('period_s',.24)-.00001
        t0=time.monotonic()
        if self.forecast is None:self.create_forecast(seen.n_balls)
        neutral=self.future_cost(w,d,seen,speed,0)
        if neutral<=cfg.get('safe_neutral',.31):
            costs=[neutral];best=0
        else:
            costs=[neutral]+[self.future_cost(w,d,seen,speed,i) for i in range(1,len(self.actions))]
            best=int(np.argmin(costs))
            if costs[self.active]-costs[best]<cfg.get('hysteresis',.06):best=self.active
        self.active=best
        self.records.append([round(float(d.time),4),round(x,5),best,np.round(costs,4).tolist(),time.monotonic()-t0])

    def report(self):
        return {'columns':['t','x','chosen','nominal_costs','compute_s'],'decisions':self.records}
