"""Estimate plant friction and servo gains from past command/encoder transitions."""
from collections import deque
import time

import mujoco
import numpy as np

import locomotion as loc


class ObserverID:
    """Finite-difference identification in a separate nominal contact model.

    Inputs are commanded motor targets, robot encoders/odometry, and delayed
    ball detections. No episode seed, true friction or actuator properties enter.
    Parameters are in the order friction, leg scale, pitch/roll head gain scales,
    pitch/roll damping scales. Head scales multiply the programmed controller gains.
    """
    bounds=np.array([[.83,1.12],[.96,1.04],[.82,1.18],[.82,1.18],[.82,1.18],[.82,1.18]])
    center=bounds.mean(axis=1)
    width=(bounds[:,1]-bounds[:,0])*.5

    def __init__(self,params):
        self.params=params;self.cfg=params.get('plant_id',{})
        if not isinstance(self.cfg,dict):self.cfg={}
        self.samples=[];self.pending=None;self.start_clock=None;self.last_capture=-1.e10
        self.solve_n=0;self.u=np.zeros(6);self.cost_s=0.;self.error=None;self.information=None
        self.model=None;self.nmax=int(self.cfg.get('max_samples',26))

    def build(self,count):
        self.model=loc.build_model(terrain=True,payload=True,mass_g=self.params.get('mass_g',40.),balls=count,diameter_mm=self.params.get('ball_diameter_mm'))
        m=self.model;self.sim=mujoco.MjData(m)
        self.walk=loc.Locomotion(m);w=self.walk
        self.hacts=np.array([m.actuator(n).id for n in ('head_pitch','head_roll')])
        self.robot_nq=int(m.joint('ball_free').qposadr[0])
        self.robot_nv=int(m.joint('ball_free').dofadr[0])
        self.friction_geoms=np.r_[w.floor,w.feet]
        self.cap=self.params.get('motor_cap_nm',.2)
        m.actuator_forcelimited[:]=1
        m.actuator_forcerange[:,0]=np.maximum(m.actuator_forcerange[:,0],-self.cap)
        m.actuator_forcerange[:,1]=np.minimum(m.actuator_forcerange[:,1],self.cap)
        self.ball_config=[(int(m.joint(n).qposadr[0]),int(m.joint(n).dofadr[0]),
                           float(m.geom_size[m.geom(g).id,0])) for n,g in
                          ([('ball_free','ball_geom')] if count==1 else [('ball_free','ball_geom'),('ball_free_b','ball_geom_b')])]
        self.weights=1/np.r_[.025,.025,.020,.24,.22,.22,np.full(self.robot_nv-6,.22)]
        self.weights[w.v[[5,6,7,8]]]=[3.5,1.7,3.3,1.7]
        self.site=m.site('paddle_center').id

    def sample(self,w,d,bc):
        """Construct forecast initial state from the actuator bus and observed geometry."""
        if self.model is None:self.build(bc.n_balls)
        q=np.zeros(self.model.nq);v=np.zeros(self.model.nv)
        q[:self.robot_nq]=d.qpos[:self.robot_nq]
        v[:self.robot_nv]=d.qvel[:self.robot_nv]
        for adr,_,_ in self.ball_config:q[adr+3]=1.
        sim=self.sim;m=self.model
        sim.qpos[:]=q;sim.qvel[:]=v
        mujoco.mj_forward(m,sim)
        R=sim.site_xmat[self.site].reshape(3,3);center=sim.site_xpos[self.site];spatial=np.zeros(6)
        mujoco.mj_objectVelocity(m,sim,mujoco.mjtObj.mjOBJ_SITE,self.site,spatial,0)
        for ch,(adr,dof,radius) in zip(bc.channels,self.ball_config):
            z=ch.measurements[0]
            arm=R@np.r_[z[:2],radius]
            q[adr:adr+3]=center+arm
            v[dof:dof+3]=spatial[3:]+np.cross(spatial[:3],arm)+R[:,:2]@z[2:]
            v[dof+3:dof+6]=R@np.array([-z[3],z[2],0.])/radius
        return dict(q=q,v=v,ctrl=d.ctrl.copy(),gain=float(bc.p['actuator_gain']),
                    damping=float(bc.p['actuator_damping']),t=float(d.time))

    def observe_before(self,w,d,bc):
        if self.start_clock is None:self.start_clock=d.time
        if self.pending is not None:
            prior=self.pending; self.pending=None
            if abs(d.time-prior['t']-.02)<1.e-5:
                prior['next']=d.qvel[:self.robot_nv].copy()
                self.samples.append(prior)
        if len(self.samples)>=self.nmax:return
        x=float(d.qpos[w.root])
        if .10<=x<=4. or (self.cfg.get('standing') and d.time-self.start_clock>.1):
            period=self.cfg.get('sample_period_s',.185)
            if d.time-self.last_capture>=period-1.e-6:
                self.pending=self.sample(w,d,bc);self.last_capture=d.time

    def forecast(self,sample,u):
        m=self.model;d=self.sim;w=self.walk
        friction,legs,kp,kr,bp,br=self.center+self.width*u
        m.geom_friction[self.friction_geoms,0]=friction
        m.actuator_gainprm[w.acts,0]=w.kp*legs
        m.actuator_biasprm[w.acts,1]=w.bias*legs
        head_gain=sample['gain']*np.array([kp,kr])
        m.actuator_gainprm[self.hacts,0]=head_gain
        m.actuator_biasprm[self.hacts,1]=-head_gain
        m.actuator_biasprm[self.hacts,2]=-sample['damping']*np.array([bp,br])
        mujoco.mj_resetData(m,d)
        d.qpos[:]=sample['q'];d.qvel[:]=sample['v'];d.ctrl[:]=sample['ctrl']
        mujoco.mj_forward(m,d)
        mujoco.mj_step(m,d,nstep=10)
        return d.qvel[:self.robot_nv].copy()

    def fit(self):
        if not self.samples or self.model is None:return
        start=time.monotonic()
        u=self.u.copy()
        # Re-linearize with shorter steps once the first fit moves away from the prior.
        for width in self.cfg.get('linear_steps',[.32,.15]):
            residual=[];jacobian=[]
            for sample in self.samples:
                prediction=self.forecast(sample,u)
                residual.append((sample['next']-prediction)*self.weights)
                jac=[]
                for j in range(6):
                    a=u.copy();b=u.copy()
                    a[j]=min(1.,a[j]+width);b[j]=max(-1.,b[j]-width)
                    jac.append((self.forecast(sample,a)-self.forecast(sample,b))*self.weights/(a[j]-b[j]))
                jacobian.append(np.array(jac).T)
            err=np.concatenate(residual);J=np.vstack(jacobian)
            # High innovation at an unobserved ball impact or foot transition should
            # have limited influence on friction/gain estimates from many frames.
            robust=np.minimum(1.,.45/np.maximum(np.abs(err),1.e-8))
            A=J*np.sqrt(robust[:,None]);b=err*np.sqrt(robust)
            prior=self.cfg.get('ridge',.015)
            lhs=A.T@A + prior*np.eye(6)
            delta=np.linalg.solve(lhs,A.T@b-prior*u)
            u=np.clip(u+delta,-1.,1.)
            self.information=np.sqrt(np.maximum(np.diag(A.T@A),0.)).tolist()
            self.error=float(np.sqrt(np.mean(err**2)))
        self.u=u;self.solve_n=len(self.samples);self.cost_s+=time.monotonic()-start

    def get_estimates(self):
        n=len(self.samples)
        if n>=4 and (not self.solve_n or n-self.solve_n>=max(4,self.nmax//3) or (n==self.nmax and self.solve_n<n)):
            self.fit()
        v=self.center+self.u*self.width
        return {'friction':float(v[0]),'leg_gain_scale':float(v[1]),'head_gain_scale':v[2:4].tolist(),
                'head_damping_scale':v[4:6].tolist(),'samples':self.solve_n,
                'weighted_innovation_rms':self.error,'sensitivity':self.information,'fit_compute_s':self.cost_s}
