"""Local leg-pose compensation from the surveyed slope and measured trunk pitch."""
import math

from path_geom import ground_height

def correct(d,walk,params):
    p=params.get('terrain_stance')
    if not p:return
    x=float(d.qpos[walk.root])
    end=p.get('end_x',8.44)
    if x<6.03 or x>end:return
    envelope=min(1.,(x-6.03)/.22,(end-x)/.28)
    ahead=p.get('ahead',.052);span=p.get('halfspan',.08)
    grade=float((ground_height(x+ahead+span)-ground_height(x+ahead-span))/(2*span))
    pitch=-float(d.xmat[walk.trunk,6]);rate=float(d.sensordata[walk.gyro+1])
    risk=max(0.,min(1.,(pitch+p.get('lead',.035)*rate-p.get('pitch_threshold',.09))/.15))
    down=max(0.,-grade);up=max(0.,grade)
    for j,(left,right) in enumerate(((2,11),(3,12),(4,13),(5,None))):
        offset=envelope*(p['base'][j]+p['down'][j]*down+p['up'][j]*up+p['catch'][j]*risk)
        d.ctrl[walk.acts[left]]+=offset
        if right is not None:d.ctrl[walk.acts[right]]-=offset

def joint_impedance(d,walk,params):
    """Change the commanded joint error near the obstacles under the same torque limits."""
    p=params.get('obstacle_servo')
    if not p:return
    x=float(d.qpos[walk.root]);a=p.get('start_x',6.1);b=p.get('end_x',8.42)
    if x<=a or x>=b:return
    mix=min(1.,(x-a)/.22,(b-x)/.24)
    for offset,sign in ((0,1.),(9,-1.)):
        for j in (0,1,2,3,4):
            axis=offset+j;act=walk.acts[axis];q=d.qpos[walk.q[axis]];v=d.qvel[walk.v[axis]]
            gain=p['gain'][j];delta=(gain-1.)*(d.ctrl[act]-q)-p['damp'][j]*v
            if j>=2:delta+=sign*p['trim'][j-2]
            lower,upper=walk.model.jnt_range[walk.model.actuator_trnid[act,0]]
            d.ctrl[act]=min(upper,max(lower,d.ctrl[act]+mix*delta))

def velocity_catch(d,walk,params):
    x=float(d.qpos[walk.root]);cfg=params.get('crest_catch') if x<7.42 and params.get('crest_catch') else params.get('velocity_catch')
    if x>8.29 and params.get('exit_catch'):cfg=params['exit_catch']
    if not cfg:return
    a,b=cfg['interval']
    if not a<x<b:return
    blend=min(1.,(x-a)/.10,(b-x)/.14)
    vx=float(d.qvel[0]); pitch=-float(d.xmat[walk.trunk,6]);gyro=float(d.sensordata[walk.gyro+1])
    hazard=min(1.,max(0.,(vx-cfg['threshold'])/.14+cfg['tilt_gain']*(pitch-cfg.get('tilt0',.08))+cfg.get('gyro_gain',.10)*gyro))
    grade=(ground_height(x+.09)-ground_height(x-.03))/.12
    anticipation=min(1.,max(0.,-grade*10))
    strength=blend*min(1.,hazard+cfg['grade_ff']*anticipation)
    for j,(left,right) in enumerate(((2,11),(3,12),(4,13),(5,None))):
        delta=strength*cfg['pose'][j]
        d.ctrl[walk.acts[left]]+=delta
        if right is not None:d.ctrl[walk.acts[right]]-=delta
