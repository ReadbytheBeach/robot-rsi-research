"""Blend the verified standing servo postures into a separate loaded gait, at 50 Hz."""
import numpy as np
from locomotion import HOME_POSE

class StanceTransition:
    def __init__(self, walking):
        self.stand = walking['stand_pose']
        self.low = walking.get('switch_speed', .10)
        self.duration = walking.get('switch_duration', .90)
        self.alpha = 0.

    def apply(self, d, walk, speed, raw):
        s = self.stand
        static = raw.copy()
        static[[5,7]] = HOME_POSE[[5,7]] + s['neck_mix'] * (static[[5,7]] - HOME_POSE[[5,7]])
        static[2] += s['hip_trim']
        static[11] -= s['hip_trim']
        static[4] += s['ankle_trim']
        static[13] -= s['ankle_trim']
        static[5] += s['neck_trim']
        target = 1. if speed >= self.low else 0.
        self.alpha += np.clip(target-self.alpha, -.02/self.duration, .02/self.duration)
        d.ctrl[walk.acts] = static + self.alpha*(d.ctrl[walk.acts] - static)

class PitchCatch:
    """Reactive hip, knee and ankle targets when predicted forward lean crosses a threshold."""
    def __init__(self, params):
        self.params=params
        self.level=0.

    def apply(self, d, walk, weight=1.):
        p=self.params
        pitch=-float(d.xmat[walk.trunk,6])
        rate=float(d.sensordata[walk.gyro+1])
        predicted=pitch+p['lead']*rate
        risk=np.clip((predicted-p['threshold'])/.15,0.,1.)
        self.level+=np.clip(risk-self.level,-.22,.52)
        for left,right,k in ((2,11,'hip'),(3,12,'knee'),(4,13,'ankle')):
            correction=weight*self.level*p[k]
            d.ctrl[walk.acts[left]]+=correction
            d.ctrl[walk.acts[right]]-=correction
        d.ctrl[walk.acts[5]]+=weight*self.level*p['neck']

class LaunchGait:
    """Apply a separately trained start, then blend back to the long-route gait before 1 m."""
    fields = ('speed','wait_s','ramp_s','neck_mix','leg_scale','hip_trim','ankle_trim','knee_trim','neck_trim',
              'pitch_feedback','pitch_rate','roll_feedback','roll_rate','switch_speed','switch_duration')
    def __init__(self, nominal):
        self.nominal=nominal
        self.start={**nominal,**nominal['launch_gait']}
        self.starts=nominal.get('launch_end_m',.38)
        self.span=nominal.get('launch_blend_m',.48)
        self.weight=1.
        self.profile=self.start
    def update(self,x):
        self.weight=float(np.clip((self.starts+self.span-x)/self.span,0.,1.))
        if self.weight==1.: self.profile=self.start
        elif self.weight==0.:self.profile=self.nominal
        else:
            p=self.profile={**self.nominal}
            for k in self.fields:
                a=self.start[k];b=self.nominal[k]
                p[k]=b+self.weight*(a-b)
            p['stand_pose']=self.nominal['stand_pose']
        return self.profile
