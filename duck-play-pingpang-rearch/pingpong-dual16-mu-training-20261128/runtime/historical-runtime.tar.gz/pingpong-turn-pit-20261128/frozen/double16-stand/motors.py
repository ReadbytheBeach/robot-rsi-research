"""Audit simulated 14-axis torque, velocity and sustained loading at 500 Hz."""
from ctypes import CDLL,c_void_p,c_int,c_double
from pathlib import Path
import subprocess
import os
import mujoco
import numpy as np

D=Path(__file__).resolve().parent
def build():
    folder=Path(mujoco.__file__).parent
    so=next(folder.glob('libmujoco.so.*'))
    target=D/'training'/('motor-audit-'+mujoco.__version__+'.so')
    target.parent.mkdir(parents=True,exist_ok=True)
    if target.exists() and target.stat().st_mtime>=(D/'motor_audit.c').stat().st_mtime:return target
    temp=target.with_suffix('.'+str(os.getpid())+'.stage')
    subprocess.run(['cc','-O2','-shared','-fPIC','-I'+str(folder/'include'),str(D/'motor_audit.c'),str(so),'-Wl,-rpath,'+str(folder),'-o',str(temp)],check=True)
    temp.replace(target)
    return target
func=CDLL(str(build())).audited_payload_steps
func.restype=None
func.argtypes=[c_void_p,c_void_p,c_int,c_void_p,c_void_p,c_int,c_double,c_void_p,c_void_p]
class MotorAudit:
    def __init__(self,m,d):
        self.m=m;self.d=d;self.stats=np.zeros((m.nu,7),dtype=np.float64);self.samples=0
        names=['floor','left_foot_collision','right_foot_collision','paddle_face','paddle_handle','ball_geom']
        if mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_GEOM,'ball_geom_b')>=0:
            names.append('ball_geom_b')
        self.ball_count=len(names)-5
        self.geom_ids=np.array([m.geom(name).id for name in names],dtype=np.int32)
        floor=self.geom_ids[0]
        self.floor_upper=float(d.geom_xpos[floor,2])
        if m.geom_type[floor]==mujoco.mjtGeom.mjGEOM_HFIELD:
            self.floor_upper+=float(m.hfield_size[m.geom_dataid[floor],2])
        self.contact_stats=np.array([0.,0.,np.inf,np.inf,0.,0.])
        self.ball_stats=np.zeros((self.ball_count,8),dtype=np.float64)
    def step(self,n=10):
        func(self.m._address,self.d._address,n,self.stats.ctypes.data,self.geom_ids.ctypes.data,
             self.ball_count,self.floor_upper,self.contact_stats.ctypes.data,self.ball_stats.ctypes.data)
        self.samples+=n

    def contact_report(self):
        c=self.contact_stats
        per_ball=[dict(ball=i+1,other_contact_steps=int(row[0]),face_contact_steps=int(row[1]),
                       longest_no_face_contact_s=float(row[3]*self.m.opt.timestep),
                       max_radius_m=float(row[4]),edge_violation_steps=int(row[5]),below_violation_steps=int(row[6]),
                       last_solver_face_contact=bool(row[7])) for i,row in enumerate(self.ball_stats)]
        return dict(physics_samples=self.samples,nonfoot_ground_contact_steps=int(c[0]),
                    ball_pair_contact_steps=int(c[1]),per_ball=per_ball,
                    ball_other_contact_steps=int(c[5]),ball_face_contact_steps=int(c[4]),
                    longest_no_face_contact_s=max(r['longest_no_face_contact_s'] for r in per_ball),
                    ball_edge_steps=sum(r['edge_violation_steps'] for r in per_ball),
                    ball_below_steps=sum(r['below_violation_steps'] for r in per_ball),
                    face_ground_clearance_lower_bound_m=float(c[2]),handle_ground_clearance_lower_bound_m=float(c[3]),
                    ground_height_upper_bound_m=self.floor_upper)
    def report(self):
        names=[self.m.actuator(i).name for i in range(self.m.nu)]
        rms=np.sqrt(self.stats[:,0]/self.samples)
        return dict(joints=names,physics_samples=self.samples,rms_nm=rms.tolist(),peak_nm=self.stats[:,1].tolist(),
               speed_peak_rad_s=self.stats[:,2].tolist(),fraction_above_90pct=(self.stats[:,3]/self.samples).tolist(),
               longest_above_90pct_s=(self.stats[:,5]*self.m.opt.timestep).tolist(),absolute_mechanical_work_j=self.stats[:,6].tolist())
