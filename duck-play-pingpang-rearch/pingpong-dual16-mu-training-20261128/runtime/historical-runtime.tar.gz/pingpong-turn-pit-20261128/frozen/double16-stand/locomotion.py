"""Free-base MicroDuck on an explicit, metered 10 m MuJoCo course."""
from functools import lru_cache
import math
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

import mujoco
import numpy as np
import onnxruntime as ort


from run_mujoco_baseline import DEFAULT_POLICY, DEFAULT_SCENE, HOME_POSE, POLICY_JOINTS

CONTROL_DT = .02
PHYSICS_DT = .002
from path_geom import CRESTS, XZ, HZ, center, tangent, project, ground_height


@lru_cache(maxsize=1)
def neutral_model():
    m = mujoco.MjModel.from_xml_path(str(DEFAULT_SCENE))
    d = mujoco.MjData(m)
    mujoco.mj_resetDataKeyframe(m, d, m.key("STAND").id)
    mujoco.mj_forward(m, d)
    return m, d


def robot_xml(terrain=True):
    scene = ET.parse(DEFAULT_SCENE).getroot()
    robot = ET.parse(DEFAULT_SCENE.parent / scene.find("include").get("file")).getroot()
    robot.find("compiler").set("meshdir", str(DEFAULT_SCENE.parent / "assets"))
    option = robot.find("option")
    if option is None:
        option = ET.SubElement(robot, "option")
    option.set("timestep", str(PHYSICS_DT))
    # Preserve exactly the normal robot collision meshes, joint limits and actuator gains.
    robot.append(scene.find("visual"))
    robot.find("asset").extend(scene.find("asset"))
    world = robot.find("worldbody")
    floor = scene.find("worldbody/geom")
    if terrain:
        zlow = float(HZ.min())
        height = float(HZ.max() - zlow)
        # Replicate along y. The base below zlow makes the pit empty above its
        # sloped contact surface; the original plane is the recycled hfield geom.
        elevation = np.tile((HZ - zlow) / height, (21, 1))
        ET.SubElement(robot.find("asset"), "hfield", name="course_profile", nrow="21", ncol=str(len(XZ)),
                      size=f"6 2.5 {height:.10f} .07", elevation=" ".join(f"{v:.9f}" for v in elevation.ravel()))
        floor.attrib.pop("size")
        floor.set("type", "hfield")
        floor.set("hfield", "course_profile")
        floor.set("pos", f"5 1 {zlow:.10f}")
    world.append(floor)
    world.append(scene.find("worldbody/light"))
    for mark in range(11):
        x0, y0 = center(mark)
        yaw = tangent(mark)
        for side in (-1., 1.):
            x = x0 - side * .56 * math.sin(yaw)
            y = y0 + side * .56 * math.cos(yaw)
            ET.SubElement(world, "geom", name=f"marker_{mark}_{'l' if side>0 else 'r'}", type="box",
                          pos=f"{x} {y} {float(ground_height(x)) + .001 if terrain else .001}",
                          quat=f"{math.cos(yaw/2)} 0 0 {math.sin(yaw/2)}",
                          size=".024 .064 .001", rgba=".92 .69 .12 1", contype="0", conaffinity="0", group="1")
    return robot


def build_model(terrain=True, payload=True, mass_g=40., balls=None, diameter_mm=None):
    root = robot_xml(terrain)
    if payload:
        import ball
        if balls is not None:
            ball.set_count(balls)
        ball.add_payload(root, *neutral_model(), mass_g=mass_g, ball_count=balls, diameter_mm=diameter_mm)
    return mujoco.MjModel.from_xml_string(ET.tostring(root, encoding="unicode"))


@lru_cache(maxsize=2)
def policy(path=DEFAULT_POLICY):
    opt=ort.SessionOptions()
    opt.intra_op_num_threads=opt.inter_op_num_threads=1
    return ort.InferenceSession(str(path),opt,providers=['CPUExecutionProvider'])


def yaw_from_quat(q):
    w,x,y,z = q
    return math.atan2(2*(w*z+x*y), 1-2*(y*y+z*z))


class Locomotion:
    def __init__(self, model):
        self.model=model
        self.route_params={}
        jointids=np.asarray([model.joint(k).id for k in POLICY_JOINTS])
        self.q=model.jnt_qposadr[jointids].copy()
        self.v=model.jnt_dofadr[jointids].copy()
        self.acts=np.asarray([model.actuator(k).id for k in POLICY_JOINTS])
        self.trunk=model.body("trunk_base").id
        self.root=model.jnt_qposadr[model.joint("trunk_base_freejoint").id]
        self.gyro=model.sensor_adr[model.sensor("imu_ang_vel").id]
        self.feet=np.asarray([model.geom(n+"_foot_collision").id for n in ("left","right")])
        self.floor=model.geom('floor').id
        self.session=policy()
        self.walk_input=self.session.get_inputs()[0].name
        self.walk_output=self.session.get_outputs()[0].name
        self.obs=np.zeros((1,61),'f')
        self.last=np.zeros(14,'f')
        self.smoothed=HOME_POSE.copy()
        self.kp=model.actuator_gainprm[self.acts,0].copy()
        self.bias=model.actuator_biasprm[self.acts,1].copy()

    def reset(self,data,seed=0):
        m=self.model
        rng=np.random.default_rng(seed)
        self.friction=float(rng.uniform(.83,1.12))
        self.gain_scale=float(rng.uniform(.96,1.04))
        self.yaw0=float(rng.uniform(-.035,.035))
        self.y0=float(rng.uniform(-.016,.016))
        m.geom_friction[np.r_[self.floor,self.feet],0]=self.friction
        m.actuator_gainprm[self.acts,0]=self.kp*self.gain_scale
        m.actuator_biasprm[self.acts,1]=self.bias*self.gain_scale
        mujoco.mj_resetData(m,data)
        data.qpos[self.root:self.root+3]=[0.,self.y0,.12]
        data.qpos[self.root+3:self.root+7]=[math.cos(self.yaw0/2),0.,0.,math.sin(self.yaw0/2)]
        data.qpos[self.q]=HOME_POSE
        data.ctrl[self.acts]=HOME_POSE
        self.last.fill(0);self.obs.fill(0);self.smoothed=HOME_POSE.copy()
        mujoco.mj_forward(m,data)

    def control(self,d,speed=.24):
        """Write 14 motor position targets. The payload then overrides its two head axes."""
        self.obs[0,:3]=d.sensordata[self.gyro:self.gyro+3]
        self.obs[0,3:6]=-d.xmat[self.trunk,6:9]
        self.obs[0,6:20]=d.qpos[self.q]-HOME_POSE
        self.obs[0,20:34]=d.qvel[self.v]
        self.obs[0,34:48]=self.last
        yaw=yaw_from_quat(d.qpos[self.root+3:self.root+7])
        x, y = d.qpos[self.root:self.root+2]
        r = self.route_params
        if x < r.get("window_start_x",-math.inf):
            r = {}
        if speed > 0:
            s, cross = project(x, y-self.y0)
            # Estimate the walking surface underneath the footprint. The
            # transformation presents the learned network an inclination relative
            # to the intended supporting plane while preserving the real IMU.
            incline_drive = r.get("incline_drive")
            if incline_drive and x > 5.81:
                span = incline_drive.get("span", .07)
                ahead = x + incline_drive.get("ahead", .04)
                g = (ground_height(ahead+span)-ground_height(ahead-span))/(2*span)
                gain = incline_drive.get("up",1.) if g >= 0 else incline_drive.get("down",1.)
                speed = max(.12,min(.75,speed+gain*g))
            virtual = r.get("virtual_ground")
            if virtual and x>5.81:
                span = virtual.get("span", .06)
                ahead = x + virtual.get("lookahead", 0.)
                gradient = (ground_height(ahead+span)-ground_height(ahead-span))/(2*span)
                gain = virtual.get("gain_up",0.) if gradient>0 else virtual.get("gain_down",0.)
                tx = math.atan(gradient) * gain * math.cos(yaw)
                gx, gz = self.obs[0,3], self.obs[0,5]
                self.obs[0,3], self.obs[0,5] = math.cos(tx)*gx+math.sin(tx)*gz, -math.sin(tx)*gx+math.cos(tx)*gz
            # An optional fast-only increase on the flat approach to an ascent.
            # The measured 1.60 m zone still contains its rising section.
            for s0, half, fade, extra in r.get("fast_approach", ()):
                gap = abs(s-s0)-half
                mix = max(0.,min(1.,(speed-.44)/.045))
                if gap < fade and mix:
                    window = 1. if gap<=0 else .5*(1.+math.cos(math.pi*gap/fade))
                    speed += mix*window*extra
            # Multiply the walk-network forward input on each physical feature.
            # Both shoulders are raised cosine ramps, preserving zero at a stop.
            for x0, half, fade, cap in r.get("feature_cap", ()):
                shoulder = abs(x-x0)-half
                if shoulder < fade and speed>cap:
                    w_cap = 1. if shoulder <= 0 else .5*(1.+math.cos(math.pi*shoulder/fade))
                    speed += w_cap*(cap-speed)
            for x0, half, fade, factor in r.get("feature_speed", ()):
                offset = abs(x-x0)-half
                if offset < fade:
                    weight = 1. if offset <= 0 else .5*(1+math.cos(math.pi*offset/fade))
                    speed *= 1.+weight*(factor-1.)
            cruise = r.get("measured_cruise")
            if cruise and cruise["start"]-.30 < x < cruise["end"]:
                dt = d.time-getattr(self,"cruise_last_t",-10.)
                fresh = abs(dt-CONTROL_DT)>.001
                raw = float(d.qvel[0])
                alpha = CONTROL_DT/(cruise.get("filter_s",.2)+CONTROL_DT)
                self.cruise_v = raw if fresh else self.cruise_v+alpha*(raw-self.cruise_v)
                self.cruise_last_t=d.time
                if x>cruise["start"]:
                    target_v = cruise["target"]
                    if "late_target" in cruise:
                        f = max(0.,min(1.,(x-cruise["change_x"])/cruise["change_span"]))
                        target_v += f*(cruise["late_target"]-target_v)
                    error = target_v-self.cruise_v
                    feed = speed if cruise.get("relative",False) else cruise["nominal"]
                    command = feed+cruise["kp"]*error
                    command = min(cruise.get("max",.55),max(cruise.get("min",.40),command))
                    blend = min(1.,(x-cruise["start"])/cruise.get("fade",.10),(cruise["end"]-x)/cruise.get("fade",.10))
                    speed += blend*(command-speed)
            goal = 0. if r.get("straight",False) else tangent(s+r.get("lookahead_m",.10))
            if r.get("straight",False):
                cross = y-self.y0
            goal += r.get("yaw_bias",0.)
            cross -= r.get("cross_target",0.)
            detour = r.get("oblique")
            if detour and detour.get("start",6.35) < s < detour.get("end",9.40):
                # The scoring centerline is unchanged. A diagonal foot approach
                # staggers the left/right encounters with the lip of the trench.
                lo=detour.get("start",6.35);hi=detour.get("end",9.40);fade=detour.get("fade",.50)
                margin = min(s-lo,hi-s)
                blend = min(1.,margin/fade)
                theta = math.pi*blend
                envelope = .5*(1.-math.cos(theta))
                eprime = (.5*math.pi*math.sin(theta)/fade if blend < 1 else 0.) * (1. if s<(lo+hi)/2 else -1.)
                k = math.pi/detour.get("half_period",.87)
                phase = k*(s-detour.get("cross_at",7.48))
                amp = detour["amplitude"]
                cross -= envelope*amp*math.sin(phase)
                ref_slope = amp*(envelope*k*math.cos(phase)+eprime*math.sin(phase))
                goal += math.atan(ref_slope)
                speed *= 1.+detour.get("pace_comp",.65)*(math.hypot(1.,ref_slope)-1.)
            heading = math.atan2(math.sin(goal-yaw), math.cos(goal-yaw))
            vy = -r.get("lateral_gain",1.45) * cross
            wz = r.get("yaw_gain",2.25)*heading-r.get("cross_yaw_gain",.60)*cross
            vymax = r.get("lateral_clip",.12)
            wzmax = r.get("yaw_clip",.60)
            self.obs[0,48:51] = [speed, max(-vymax,min(vymax,vy)), max(-wzmax,min(wzmax,wz))]
        else:
            self.obs[0,48:51] = 0.
        spin = r.get("body_spin")
        if spin is not None and d.time + 1e-9 >= spin["start_s"]:
            # Omnidirectional locomotion commands go to the existing walking policy.
            # The free root still turns exclusively through foot-ground contact.
            w = min(1., max(0., (d.time-spin["start_s"])/spin.get("ramp_s",.65)))
            next_w = w*spin["cmd"]
            measured_w = float(d.sensordata[self.gyro+2])
            yaw_cmd = next_w+spin.get("rate_gain",0.)*(next_w-measured_w)
            s_spin, e_spin = project(x,y-self.y0)
            reference = tangent(s_spin)
            dx = speed*math.cos(reference)+e_spin*math.sin(reference)
            dy = speed*math.sin(reference)-e_spin*math.cos(reference)
            lateral = -math.sin(yaw)*dx+math.cos(yaw)*dy
            # Counter the lateral velocity from the beak offset in the body frame.
            lateral -= spin.get("offset",0.)*measured_w
            bound = spin.get("lateral_limit",.42)
            self.obs[0,48:51] = (math.cos(yaw)*dx+math.sin(yaw)*dy,
                                 max(-bound,min(bound,lateral)),
                                 max(-6.,min(6.,yaw_cmd)))
        a=self.session.run([self.walk_output],{self.walk_input:self.obs})[0][0]
        self.last[:]=a
        raw=HOME_POSE+1.044*a
        target=.2*raw+.8*self.smoothed
        self.smoothed=raw
        # Optional trained alternate stance only around the measured hazards.
        # Joint deltas are (symmetric hips, knees, ankles, neck pitch).
        for x0, half, fade, dq in r.get("feature_pose", ()):
            gap = abs(x-x0)-half
            if gap < fade:
                weight = 1. if gap <= 0 else .5*(1+math.cos(math.pi*gap/fade))
                hip, knee, ankle, neck = (weight*v for v in dq)
                target[[2,3,4,5,11,12,13]] += [hip,knee,ankle,neck,-hip,-knee,-ankle]
        if 5.88 < x < 8.55 and r.get("foot_ik"):
            self.terrain_foot_targets(d,target,r["foot_ik"],x,yaw)
        d.ctrl[self.acts]=target
        return target

    def terrain_foot_targets(self,d,target,cfg,x,yaw):
        """Map terrain-relative foot height and pitch to each leg using site Jacobians."""
        if not hasattr(self, "foot_jacp"):
            self.foot_jacp = np.zeros((3,self.model.nv))
            self.foot_jacr = np.zeros_like(self.foot_jacp)
        look = cfg.get("look",0.)
        span = cfg.get("span",.045)
        bodyspan = cfg.get("bodyspan",.14)
        ref = .5*(ground_height(x-bodyspan)+ground_height(x+bodyspan))
        c, sn = math.cos(yaw), math.sin(yaw)
        weight=.045
        # Capture-point style forward foot placement: pitch/gyro and excess
        # base speed move the commanded footprint forward of the falling trunk.
        pitch = -float(d.xmat[self.trunk,6])
        w = float(d.sensordata[self.gyro+1])
        rootv = d.qvel[self.model.jnt_dofadr[self.model.joint("trunk_base_freejoint").id]:][:3]
        vx = c*rootv[0]+sn*rootv[1]
        dx = cfg.get("pitch_x",0.)*(pitch-cfg.get("pitch_ref",.045))
        dx += cfg.get("rate_x",0.)*w + cfg.get("vel_x",0.)*(vx-cfg.get("speed_ref",.10))
        dx = max(-.028,min(.028,dx))
        weight_at = min(1., max(0., (x-5.90)/.28), max(0., (8.55-x)/.30))
        dx *= weight_at
        for geom, ids in zip(self.feet, ((2,3,4),(11,12,13))):
            fx=float(d.geom_xpos[geom,0])+look
            h=ground_height(fx)
            slope=(ground_height(fx+span)-ground_height(fx-span))/(2.*span)
            if abs(h-ref)+abs(slope)+abs(dx) < 1.e-7:
                continue
            mujoco.mj_jacGeom(self.model,d,self.foot_jacp,self.foot_jacr,int(geom))
            columns=self.v[list(ids)]
            jp=self.foot_jacp[:,columns];jr=self.foot_jacr[:,columns]
            J=np.vstack((c*jp[0]+sn*jp[1],jp[2],weight*(-sn*jr[0]+c*jr[1])))
            rhs=np.asarray([dx,cfg["height_gain"]*(h-ref),-cfg["pitch_gain"]*c*math.atan(slope)*weight])
            dq=np.linalg.solve(J.T@J+.000025*np.eye(3), J.T@rhs)
            target[list(ids)] += np.clip(dq,-.28,.28)

    def failure(self,d,terrain=True):
        p=d.qpos[self.root:self.root+3]
        if not np.all(np.isfinite(d.qpos)):return 'nonfinite'
        if p[2]-(ground_height(p[0]) if terrain else 0)<.075:return 'height'
        if d.xmat[self.trunk,8]<math.cos(math.radians(55)):return 'tilt'
        return ''
