"""Free-base, physically carried ball trials. Progress is the measured trunk projection onto the ten-metre route."""
from functools import lru_cache
from pathlib import Path
import argparse, json,math
import mujoco
import numpy as np
import path_geom as path
import ball
from terrain_stance import correct, joint_impedance, velocity_catch
from pacing import Pace, DEADLINE
from motors import MotorAudit
import locomotion as loc

D=Path(__file__).resolve().parent
BASE=dict(mass_g=40.,motor_cap_nm=.20,speed=.32,ramp_s=1.5,wait_s=.4,neck_mix=.5,brake_m=.32,finish_buffer=.15,
          ball={})
DT=.02
def save(p,v):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    tmp=p.with_suffix(p.suffix+'.partial')
    tmp.write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False,default=lambda x:x.tolist())+'\n')
    tmp.replace(p)

@lru_cache(maxsize=6)
def template(terrain,mass_g,count,diameter_mm=None):
    ball.set_count(count)
    return loc.build_model(terrain=terrain,payload=True,mass_g=mass_g,balls=count,diameter_mm=diameter_mm)

def run(mode,seed,params=None,length=None,trace=None,timeout=None,guard=True,branch=None):
    import copy
    params={**BASE,**(params or {})}
    order='fast_first' if seed%2 else 'slow_first'
    params.update(params.get('by_order',{}).get(order,{}))
    distance=float(length if length is not None else (0 if mode=='stand' else 10.))
    terrain=mode!='stand'
    settle=float(params.get('settle_s',1.0))
    count=int(params.get('ball_count',1))
    ball.set_count(count)
    m=copy.copy(template(terrain,float(params['mass_g']),count,params.get('ball_diameter_mm')));d=mujoco.MjData(m)
    cap=float(params['motor_cap_nm'])
    m.actuator_forcelimited[:]=1
    m.actuator_forcerange[:,0]=np.maximum(m.actuator_forcerange[:,0],-cap)
    m.actuator_forcerange[:,1]=np.minimum(m.actuator_forcerange[:,1],cap)
    walk=loc.Locomotion(m);walk.reset(d,int(seed));walk.route_params.update(params.get('route_params',{}))
    bc=ball.BallController(m,d,params['ball'])
    # Begin with the robot on the floor carrying the paddle. Only initial placement is outside the scored clock.
    bc.park()
    mujoco.mj_forward(m,d)
    switch = None
    if params.get("stand_pose") is not None:
        from stance_transition import StanceTransition
        switch = StanceTransition(params)
    catch = None
    if params.get("pitch_catch") is not None:
        from stance_transition import PitchCatch
        catch=PitchCatch(params["pitch_catch"])
    launch=None;launch_catch=None
    if params.get("launch_gait") is not None:
        from stance_transition import LaunchGait,PitchCatch
        launch=LaunchGait(params)
        if launch.start.get("pitch_catch") is not None: launch_catch=PitchCatch(launch.start["pitch_catch"])
    def drive(speed):
        profile=params if launch is None else launch.profile
        if launch is not None:
            switch.stand=profile["stand_pose"];switch.low=profile["switch_speed"];switch.duration=profile["switch_duration"]
        walk.control(d,speed)
        if switch is not None: raw = d.ctrl[walk.acts].copy()
        a=walk.acts[[5,7]]
        h=loc.HOME_POSE[[5,7]]
        d.ctrl[a]=h+profile['neck_mix']*(d.ctrl[a]-h)
        hip=profile.get('hip_trim',0.);ankle=profile.get('ankle_trim',0.)
        d.ctrl[walk.acts[2]]+=hip; d.ctrl[walk.acts[11]]-=hip
        d.ctrl[walk.acts[4]]+=ankle; d.ctrl[walk.acts[13]]-=ankle
        d.ctrl[walk.acts[5]]+=profile.get('neck_trim',0.)
        if 'leg_scale' in profile:
            ids=walk.acts[[0,1,2,3,4,9,10,11,12,13]]
            h=loc.HOME_POSE[[0,1,2,3,4,9,10,11,12,13]]
            d.ctrl[ids]=h+profile['leg_scale']*(d.ctrl[ids]-h)
            knee=profile['knee_trim']
            d.ctrl[walk.acts[3]]+=knee;d.ctrl[walk.acts[12]]-=knee
            pitch=-float(d.xmat[walk.trunk,6])
            gyro=d.sensordata[walk.gyro+1]
            corr=profile.get('pitch_feedback',0.)*pitch+profile.get('pitch_rate',0.)*gyro
            d.ctrl[walk.acts[2]]+=corr;d.ctrl[walk.acts[11]]-=corr
            roll=float(d.xmat[walk.trunk,7]);rate=d.sensordata[walk.gyro]
            lr=profile.get('roll_feedback',0.)*roll+profile.get('roll_rate',0.)*rate
            d.ctrl[walk.acts[1]]+=lr;d.ctrl[walk.acts[10]]+=lr
        if switch is not None: switch.apply(d,walk,speed,raw)
        correct(d,walk,params)
        joint_impedance(d,walk,params)
        velocity_catch(d,walk,params)
        if catch is not None: catch.apply(d,walk)
        if launch_catch is not None and launch.weight>0: launch_catch.apply(d,walk,launch.weight)
    bc.prepare(seed,float(params.get('difficulty',1.)))
    for _ in range(round(settle/DT)):
        drive(0.);bc.level_empty()
        mujoco.mj_step(m,d,nstep=10)
    mujoco.mj_forward(m,d)
    start=d.qpos[walk.root:walk.root+3].copy()
    bc.reset(seed,difficulty=float(params.get('difficulty',1.)))
    for choice in params.get('latency_profiles',[]):
        if choice.get('order',order)==order and 20*bc.act_lag>=choice.get('min_act_ms',0) and 20*bc.obs_lag>=choice.get('min_obs_ms',0):
            params.update(choice['overrides'])
            walk.route_params.update(params.get('route_params',{}))
            break
    shoot=None
    if count==2 and params.get('pair_shoot'):
        from dual_shoot import PairShooting
        if params['pair_shoot'].get('trajectory'):
            from pair_trajectory import PairTrajectory
            shoot=PairTrajectory(m,d,bc,params,terrain)
        else:
            shoot=PairShooting(m,d,bc,params,terrain)
    learned=None
    if count==2 and params.get('pair_feedback'):
        from pair_feedback import PairFeedback
        learned=PairFeedback(m,d,bc,params['pair_feedback'])
    pair_rock=None
    if count==2 and params.get('pair_rock'):
        from pair_spin import PairRock
        pair_rock=PairRock(m,d,bc,params['pair_rock'])
    pair_spin=None
    if count==2 and params.get('pair_spin'):
        from pair_spin import PairSpin
        pair_spin=PairSpin(m,d,bc,params['pair_spin'])
    identifier=None;skills=None
    if params.get('observer_id'):
        from observer_id import ObserverID
        identifier=ObserverID(params)
    if params.get('skill_planner'):
        from skill_planner import SkillPlanner
        skills=SkillPlanner(params)
    planner=None
    if params.get('mpc'):
        from hazard_mpc import HazardMPC
        planner=HazardMPC(params)
    observer = None
    if params.get('ball_observer') is not None:
        from predict_ball import PredictBall
        observer = PredictBall(d,bc,params['ball_observer'])
    gaze = None
    if params.get('gaze') is not None:
        from gaze import Gaze
        gaze = Gaze(m,d,bc,params['gaze'])
    audit=MotorAudit(m,d)
    pace=Pace(seed);commands=[]
    origin_s=path.project(*start[:2])[0];progress=cross=0.;max_cross=0.;pit_before=pit_after=False
    pit_foot_steps=0;max_yaw=-180.;heading0=loc.yaw_from_quat(d.qpos[walk.root+3:walk.root+7]);longitudinal_pace=Pace(seed)
    max_sep=0.;min_sep=float('inf');separation_at_loss=None
    prev=start.copy();maxmove=maxy=arclength=0.;hold=0;holding=False;anchor=None
    end_s=10. if mode=='stand' else (float(timeout) if timeout is not None else 240.)
    reason='timeout';success=False;max_tilt=0.; min_h=10.;rows=[]
    other_ground=False
    gate_start=None
    launch_release=None
    stop_start=None;stop_duration=float(params.get("stop_ramp_s",0.))
    footids=set(map(int,walk.feet));floor=walk.floor
    def record(t,r,on):
        if trace is not None:
            rows.append((float(t),d.qpos.copy(),float(progress),float(r),bool(on),d.qpos[walk.root:walk.root+2].copy(),np.asarray(bc.last_radii).copy(),np.asarray(bc.last_contacts).copy()))
    record(0.,np.linalg.norm(bc.state()[0][:2]),False)
    for step in range(1,round(end_s/DT)+1):
        t=(step-1)*DT
        prog=progress
        if branch is not None and prog>=branch.at:
            params.update(branch.choose());walk.route_params.update(params.get("route_params",{}));branch=None
        if skills is not None:
            patch=skills.choose(walk,d,bc,pace,t,origin_s,identifier)
            if patch:
                params.update(patch);walk.route_params.update(params.get('route_params',{}))
        speed=0.
        if terrain and not holding:
            cmd=params if launch is None else launch.update(prog)
            accel_t=t
            if 'launch_gate' in params:
                gate=params['launch_gate']
                if launch_release is None and t>=cmd['wait_s'] and (bc.stop_ready(gate['radius'],gate['velocity']) or t>=cmd['wait_s']+gate['max_wait']):
                    launch_release=t
                accel_t=cmd['wait_s'] if launch_release is None else t-launch_release+cmd['wait_s']
            speed=cmd['speed']*np.clip((accel_t-cmd['wait_s'])/max(.001,cmd['ramp_s']),0.,1.)
            if 'speed_profile' in params:
                ramp=max(0.,min(1.,(accel_t-cmd['wait_s'])/max(.001,cmd['ramp_s'])))
                speed=pace.command(params['speed_profile'],prog,t,ramp)
            if 'cruise_speed' in params:
                begin=params.get('cruise_start_m',.6);span=params.get('cruise_ramp_m',.45)
                blend=np.clip(min((prog-begin)/span,(distance-prog)/span),0.,1.)
                if params.get('cruise_flat_only',False):
                    flat_margin=min(abs(prog-center)-width for center,width,_ in loc.CRESTS)
                    blend*=np.clip((flat_margin-.15)/.30,0.,1.)
                speed+=float(blend)*(params['cruise_speed']-params['speed'])
            lateral_ready=True
            if distance==10. and params.get('dock_steer'):
                dock=params['dock_steer'];dy=float(prev[1]-start[1]-2.)
                if prog>dock.get('start_s',9.30):
                    margin=dock.get('margin',.050)
                    extra=math.copysign(max(0.,abs(dy)-margin),dy)
                    factor=max(0.,min(1.,(prog-dock.get('start_s',9.30))/.30))
                    walk.route_params['cross_target']=-factor*max(-.10,min(.10,dock.get('gain',1.6)*extra))
                lateral_ready=abs(dy)<=dock.get('gate',.081) or prog>=distance+.24
            if stop_start is None and prog>=distance+params['finish_buffer'] and lateral_ready:
                gate=params.get('stop_gate')
                if gate is None:
                    stop_start=t
                else:
                    if gate_start is None: gate_start=t
                    stable=bc.stop_ready(gate['radius'],gate['velocity'])
                    if stable or t-gate_start>=gate['max_wait_s']: stop_start=t
            if stop_start is not None:
                remaining=0. if stop_duration<=0 else max(0.,1.-(t-stop_start)/stop_duration)
                speed*=remaining
                if remaining==0.:
                    holding=True;speed=0.;anchor=prev[:2].copy()
        if terrain and not holding and 'pit_speed' in params:
            gate=params['pit_speed'];x=float(prev[0])
            blend=max(0.,min(1.,(x-gate['start'])/gate.get('ramp',.15),(gate['end']-x)/gate.get('ramp',.15)))
            pit_cmd=gate['cmd']
            if 'exit_cmd' in gate:
                start_boost=gate.get('switch_x',7.89)
                u=max(0.,min(1.,(x-start_boost)/.06,(gate.get('boost_end',8.12)-x)/.09))
                pit_cmd+=u*(gate['exit_cmd']-pit_cmd)
            speed=speed*(1-blend)+pit_cmd*blend
        if planner is not None:planner.update(walk,d,bc,float(speed))
        drive(float(speed))
        if planner is not None:planner.apply(d,walk)
        if observer is not None:observer.update()
        if learned is not None:learned.apply(d,bc)
        if shoot is not None:shoot.update(walk,d,bc,float(speed))
        if pair_rock is not None:pair_rock.update(d)
        if pair_spin is not None:pair_spin.update(d)
        bc.control()
        if gaze is not None:gaze.control()
        if identifier is not None:identifier.observe_before(walk,d,bc)
        audit.step();mujoco.mj_forward(m,d)
        ballfail,r,on=bc.observe()
        # Duration is a property of the uninterrupted 2 ms contact sequence.
        # Intermittent contacts between 50 Hz camera frames reset the physical clock.
        if ballfail.startswith('ball_air'):
            ballfail=''
        for index,stats in enumerate(audit.ball_stats):
            suffix='_b' if index else ''
            if stats[3]*m.opt.timestep>.180000001:ballfail='ball_air'+suffix;break
            if stats[0]>0:ballfail='ball_other_contact'+suffix;break
            if stats[5]>0:ballfail='ball_edge'+suffix;break
            if stats[6]>0:ballfail='ball_below'+suffix;break
        if count==2:
            i,j=[ch.adr for ch in bc.channels]
            sep=float(np.linalg.norm(d.qpos[i:i+3]-d.qpos[j:j+3]))
            max_sep=max(max_sep,sep);min_sep=min(min_sep,sep)
            if ballfail:separation_at_loss=sep
        pos=d.qpos[walk.root:walk.root+3].copy()
        route_s,cross=path.project(*pos[:2]);progress=float(route_s-origin_s)
        max_cross=max(max_cross,abs(cross))
        yaw=loc.yaw_from_quat(d.qpos[walk.root+3:walk.root+7])-heading0
        if 2.5<route_s<7.5:max_yaw=max(max_yaw,math.degrees(math.atan2(math.sin(yaw),math.cos(yaw))))
        if abs(cross)<=.55 and path.PIT_X-.30<=pos[0]<=path.PIT_X-path.PIT_WIDTH/2:pit_before=True
        if pit_before and abs(cross)<=.55 and pos[0]>=path.PIT_X+path.PIT_WIDTH/2:pit_after=True
        if abs(pos[0]-path.PIT_X)<.35:
            pit_foot_steps+=int(any(c.dist<=0 and floor in (c.geom1,c.geom2) and (c.geom2 if c.geom1==floor else c.geom1) in footids and abs(c.pos[0]-path.PIT_X)<path.PIT_WIDTH/2 for c in d.contact))
        arclength+=np.linalg.norm(pos[:2]-prev[:2]);prev=pos
        maxmove=max(maxmove,float(np.linalg.norm(pos[:2]-start[:2])))
        maxy=max(maxy,abs(pos[1]-start[1]))
        tilt=math.degrees(math.acos(float(np.clip(d.xmat[walk.trunk,8],-1,1))))
        max_tilt=max(max_tilt,tilt);min_h=min(min_h,float(pos[2]-(loc.ground_height(pos[0]) if terrain else 0)))
        other_ground=any(c.dist<=0 and floor in (c.geom1,c.geom2) and (c.geom2 if c.geom1==floor else c.geom1) not in footids|set(bc.ball_geoms) for c in d.contact)
        fail=ballfail or walk.failure(d,terrain) or ('nonfoot_ground' if other_ground else '')
        if not fail and mode=='stand' and maxmove>.15:fail='station_drift'
        if not fail and terrain and max_cross>.55:fail='lane_exit'
        pace.observe(step*DT,progress)
        longitudinal_pace.observe(step*DT,float(pos[0]-start[0]))
        if trace is not None:commands.append(float(speed))
        record(step*DT,r,on)
        if fail:reason=fail;break
        if mode=='stand' and step*DT>=end_s:
            success=bool(on);reason='completed' if on else 'end_air';break
        if terrain and holding:
            if progress<distance:
                holding=False;hold=0;anchor=None;stop_start=None;gate_start=None
            elif np.linalg.norm(pos[:2]-anchor)>.08:
                hold=0;anchor=pos[:2].copy()
            else:
                hold+=1
                if hold>=50 and on:
                    success=True;reason='completed';break
    out=dict(mass_g=params["mass_g"],motor_cap_nm=cap,mode=mode,seed=int(seed),success=bool(success),reason=reason,seconds=step*DT,
             distance_m=float(progress),longitudinal_m=float(prev[0]-start[0]),lateral_m=float(prev[1]-start[1]),max_cross_m=max_cross,turn_yaw_deg=max_yaw if max_yaw>-180 else None,pit_crossed=pit_after,pit_foot_steps=pit_foot_steps,initial_x_m=float(start[0]),final_x_m=float(prev[0]),
             target_m=distance,path_length_m=float(arclength),max_xy_displacement_m=maxmove,
             max_lateral_m=float(maxy),max_tilt_deg=max_tilt,min_height_m=min_h,
             radius_p95_mm=float(np.percentile(bc.radii,95)*1000),radius_max_mm=float(max(bc.radii)*1000),
             terminal_radius_mm=bc.radii[-1]*1000,last_face_contact=bool(on),no_contact_max_ms=1000.*float(max(audit.ball_stats[:,3]))*m.opt.timestep,sampled_no_contact_max_ms=bc.max_air*20,
             pushes=bc.push_count,observation_delay_ms=20*bc.obs_lag,command_delay_ms=20*bc.act_lag,
             foot_friction=walk.friction,leg_gain_scale=walk.gain_scale,stable_finish_s=hold*.02)
    if shoot is not None:out['pulse_decisions']=shoot.logs
    if pair_spin is not None:out['pair_spin']=pair_spin.report()
    if planner is not None:out['mpc']=planner.report()
    if skills is not None:out['skill_decisions']=skills.decisions
    if identifier is not None:out['online_identification']=identifier.get_estimates()
    out['motor']=audit.report()
    out['contact_audit_500hz']=audit.contact_report()
    if out['success']:
        fine=out['contact_audit_500hz']
        violations=((fine['ball_edge_steps']>0,'ball_edge_500hz'),(fine['ball_below_steps']>0,'ball_below_500hz'),(fine['ball_other_contact_steps']>0,'ball_other_contact_500hz'),
                    (fine['nonfoot_ground_contact_steps']>0,'nonfoot_ground_500hz'),
                    (fine['longest_no_face_contact_s']>.180000001,'ball_air_500hz'))
        for violated,reason in violations:
            if violated:
                out.update(success=False,reason=reason)
                break
    out.update(pace.report())
    if count==2:
        out.update(max_separation_m=max_sep,min_separation_m=min_sep,separation_at_loss_m=separation_at_loss,
                   observation_delays_ms=[20*ch.obs_lag for ch in bc.channels],push_counts=[ch.push_count for ch in bc.channels])
    out['ball_count']=count;out['ball_diameter_mm']=bc.radius_m*2000;out['ball_mass_g']=bc.mass_kg*1000
    out['terminal_radii_mm']=(np.asarray(bc.last_radii)*1000).tolist();out['terminal_contacts']=list(map(bool,bc.last_contacts))
    out['world_x_windows_mps']=longitudinal_pace.report()['segment_mps']
    if terrain and distance==10. and out['success']:
        for cond,why in [(abs(out['lateral_m']-2.)<=.10,'lateral_endpoint'),(pit_after,'pit_gate'),(max_yaw>=15.,'turn_gate')]:
            if not cond:out.update(success=False,reason=why);break
    out['course_completed']=out['success']
    out['on_time']=bool(out['course_completed'] and out['seconds']<=DEADLINE)
    if terrain and distance==10. and out['course_completed']:
        out['success']=bool(out['on_time'] and out['pace_ok'])
        if not out['success']:
            out['reason']='pace_and_deadline' if not out['on_time'] and not out['pace_ok'] else ('deadline' if not out['on_time'] else 'pace')
    if trace is not None:
        p=Path(trace);p.parent.mkdir(parents=True,exist_ok=True)
        t,q,x,r,c,xy,rad,con=map(np.asarray,zip(*rows))
        np.savez_compressed(p,t=t,qpos=q,progress_m=x,radial_m=r,on_face=c,root_xy=xy,ball_radii=rad,ball_contacts=con,cmd=np.r_[0.,commands])
        save(p.with_suffix('.json'),{**out,'params':params,'terrain':terrain,'physics_dt':.002,'control_dt':DT})
    return out

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('mode',choices=['stand','route']);p.add_argument('seed',type=int)
    p.add_argument('--config',type=Path);p.add_argument('--length',type=float);p.add_argument('--trace',type=Path)
    args=p.parse_args()
    print(json.dumps(run(args.mode,args.seed,json.loads(args.config.read_text()) if args.config else None,args.length,args.trace),indent=2))
