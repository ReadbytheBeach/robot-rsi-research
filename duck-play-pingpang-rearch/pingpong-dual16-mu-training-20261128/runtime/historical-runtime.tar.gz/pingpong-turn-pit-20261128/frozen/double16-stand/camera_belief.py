"""Causal initialization of rolling-ball state using time-stamped paddle kinematics."""
from collections import deque

import numpy as np


class CameraBelief:
    """Transform the latest delivered exposure out of its historical camera frame."""
    def __init__(self):
        self.history=deque(maxlen=6)

    def observe(self,d,channel):
        time=float(d.time)
        if self.history and abs(self.history[-1][0]-time)<1.e-8:return
        self.history.append((time,d.site_xpos[channel.site].copy(),
                             d.site_xmat[channel.site].reshape(3,3).copy(),channel.spatial.copy()))

    def estimate(self,channel,gamma=.4,steps=None):
        z=channel.measurements[0];lag=int(channel.obs_lag)
        steps=lag if steps is None else int(steps)
        if not 0<=steps<=lag:raise ValueError('Requested time outside observation history')
        if steps==0 or len(self.history)<=lag:return z.copy()
        t,c,R,v=self.history[-lag-1+steps];t0,c0,R0,v0=self.history[-lag-1]
        tau=t-t0
        if abs(tau-.02*steps)>.002:return z.copy()
        arm0=R0@np.r_[z[:2],channel.radius_m]
        # Inertial ball velocity is recovered from the exposure-time encoder frame.
        site_v0=v0[3:]+np.cross(v0[:3],arm0)
        vel0=site_v0+R0[:,:2]@z[2:]
        arm=c0+arm0+tau*vel0-c
        g0=np.array([0.,0.,-9.81])+9.81*R0[2,2]*R0[:,2]
        g1=np.array([0.,0.,-9.81])+9.81*R[2,2]*R[:,2]
        gravity=.5*(1.-gamma)*(g0+g1)
        # A thin homogeneous spherical shell on a translating surface has
        # a_plate coefficient I/(I+mr²)=0.4 in no-slip rolling.
        omega_drift=(R@R0.T-np.eye(3))@arm0
        contact_displacement=c-c0+omega_drift
        arm+=.5*tau*tau*gravity+gamma*(contact_displacement-tau*site_v0)
        site_v=v[3:]+np.cross(v[:3],arm)
        vel=vel0+tau*gravity+gamma*(site_v-site_v0)
        return np.r_[R[:,:2].T@arm,R[:,:2].T@(vel-site_v)]
