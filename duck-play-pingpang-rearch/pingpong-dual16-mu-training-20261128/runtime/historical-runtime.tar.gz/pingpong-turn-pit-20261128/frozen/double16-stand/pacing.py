"""Route-speed schedule and independent timing of first forward trunk crossings."""
from collections import deque
import math

BOUNDS={'slow':(.055,.085),'fast':(.095,.145)}
TARGET={'slow':.070,'fast':.116}
DEADLINE=150.
GATES=sorted({0.,10.,*[2.5*i for i in range(5)],*[2.5*i+u for i in range(4) for u in (.55,2.15)]})

class Pace:
    def __init__(self,seed):
        self.levels=(['slow','fast'] if seed%2==0 else ['fast','slow'])*2
        self.times={0.:0.}
        self.next_gate=1
        self.last_t=self.last_x=0.
        self.history=deque([(0.,0.)],maxlen=76)
        self.integral=0.; self.last_zone=0

    def observe(self,t,x):
        while self.next_gate<len(GATES) and x>=GATES[self.next_gate]:
            g=GATES[self.next_gate]
            self.times[g]=self.last_t+(t-self.last_t)*(g-self.last_x)/(x-self.last_x)
            self.next_gate+=1
        self.last_t=t;self.last_x=x;self.history.append((t,x))

    def command(self,profile,x,t,ramp):
        zone=max(0,min(3,int(x/2.5)))
        base=profile
        zones=base.get('zones',{})
        if zones:profile={**base,**zones.get(str(zone),{})}
        level=self.levels[zone];new=profile[level];goal=profile.get(level+'_target',TARGET[level])
        if zone and profile.get('transition_m',.30)>0:
            part=max(0.,min(1.,(x-2.5*zone)/profile.get('transition_m',.30)))
            old=self.levels[zone-1]
            prior={**base,**zones.get(str(zone-1),{})} if zones else profile
            new=part*new+(1-part)*prior[old]
            goal=part*goal+(1-part)*prior.get(old+'_target',TARGET[old])
        if profile.get('kp',0.) or profile.get('ki',0.):
            if zone!=self.last_zone:self.integral*=profile.get('integral_carry',.4)
            dt=t-self.history[0][0]
            if dt>.5 and x>profile.get('correct_after_m',.40):
                measured=(x-self.history[0][1])/dt
                err=goal-measured
                self.integral=max(-.06,min(.06,self.integral+.02*err*profile.get('ki',0.)))
                new+=max(-.075,min(.075,profile.get('kp',0.)*err+self.integral))
        self.last_zone=zone
        if 'launch_command' in profile:
            mix=max(0.,min(1.,(x-profile.get('launch_until_m',.20))/profile.get('launch_blend_m',.28)))
            new=profile['launch_command']*(1-mix)+new*mix
        correction=profile.get('window_clock')
        if correction and zone==3 and 8.05 in self.times and correction.get('begin',8.65)<x<9.65:
            prior=self.report()['segment_mps'][:3]
            if all(v is not None for v in prior):
                fast_prior=sum(v for v,k in zip(prior,self.levels) if k=='fast')
                slow_prior=sum(v for v,k in zip(prior,self.levels) if k=='slow')
                if level=='fast':
                    limit=max(.095,1.30*slow_prior-fast_prior)
                    wanted=min(.134,limit+correction.get('margin',.004))
                else:
                    limit=min(.085,fast_prior/1.30-slow_prior)
                    wanted=max(.061,min(.078,limit-correction.get('margin',.004)))
                time_left=1.60/wanted-(t-self.times[8.05])
                needed=(9.65-x)/max(.10,time_left)
                _,oldx=self.history[0];duration=t-self.history[0][0]
                v_now=(x-oldx)/max(.02,duration)
                dx=needed-v_now
                delta=max(-correction.get('max_down',.08),min(correction.get('max_up',.055),correction.get('gain',1.45)*dx))
                if level=='fast':delta=max(0.,delta)
                else:delta=min(0.,delta)
                u=max(0.,min(1.,(x-correction.get('begin',8.65))/.22))
                new+=u*delta
        if 'approach_command' in profile and x>9.65:
            blend=min(1.,(x-9.65)/profile.get('approach_span_m',.32))
            new=new*(1.-blend)+profile['approach_command']*blend
        if zone==3 and level=='fast' and 'exit_cruise' in profile:
            u=max(0.,min(1.,(x-profile.get('exit_at',8.48))/.20,(10.-x)/.25))
            new=new*(1-u)+u*profile['exit_cruise']
        if zone==3 and level=='fast' and 'after_pit' in profile:
            u=max(0.,min(1.,(x-profile.get('after_pit_s',8.47))/.19))
            new+=u*profile['after_pit']
        if zone==2 and level=='fast' and 'climb_feed' in profile:
            u=max(0.,min(1.,(x-6.18)/.3,(7.24-x)/.22))
            new+=u*profile['climb_feed']
        recovery=profile.get('recovery')
        if recovery and level=='fast':
            u=max(0.,min(1.,(x-recovery['start'])/.06,(recovery['end']-x)/.12))
            new=new*(1-u)+min(new,recovery['cap'])*u
        return min(.75,max(.05,new))*ramp

    def report(self):
        def mean(a,b):
            return (b-a)/(self.times[b]-self.times[a]) if a in self.times and b in self.times else None
        speeds=[mean(2.5*i+.55,2.5*i+2.15) for i in range(4)]
        full=[mean(2.5*i,2.5*i+2.5) for i in range(4)]
        ok=[v is not None and BOUNDS[k][0]<=v<=BOUNDS[k][1] for k,v in zip(self.levels,speeds)]
        ratio=None
        if all(v is not None for v in speeds):
            ratio=sum(v for v,k in zip(speeds,self.levels) if k=='fast')/sum(v for v,k in zip(speeds,self.levels) if k=='slow')
        return dict(levels=self.levels,segment_mps=speeds,full_segment_mps=full,segment_ok=ok,fast_slow_ratio=ratio,
                    pace_ok=bool(all(ok) and ratio>=1.30),first_10m_s=self.times.get(10.),deadline_s=DEADLINE,
                    crossing_times_s={str(k):v for k,v in self.times.items()})
