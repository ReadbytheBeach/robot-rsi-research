"""Select short terrain skills by simulating a separate sensor-initialized nominal robot."""
import copy,math,time
import mujoco
import numpy as np
from hazard_mpc import HazardMPC
from path_geom import ground_height,project
from predict_ball import PredictBall

def pit_command(speed,x,gate):
    if not gate:return speed
    blend=max(0.,min(1.,(x-gate['start'])/gate.get('ramp',.15),(gate['end']-x)/gate.get('ramp',.15)))
    target=gate['cmd']
    if 'exit_cmd' in gate:
        u=max(0.,min(1.,(x-gate.get('switch_x',7.89))/.06,(gate.get('boost_end',8.12)-x)/.09))
        target+=u*(gate['exit_cmd']-target)
    return speed*(1-blend)+target*blend

class SkillPlanner(HazardMPC):
    def __init__(self,params):
        self.base=dict(params);self.pcfg=self.base['skill_planner']
        super().__init__({**self.base,'hazard_mpc':{}})
        self.next=0;self.current={};self.decisions=[]
        self.stall_checks=0;self.last_stall_check=-math.inf
    def predict(self,w,d,seen,pace,t,s_offset,patch,cfg,estimates):
        self.params={**self.base,**self.current,**patch}
        self.initialize(w,d,seen)
        m,dp,wp,bp=self.forecast
        dp.time=d.time
        wp.cruise_last_t=getattr(w,'cruise_last_t',-10.)
        wp.cruise_v=getattr(w,'cruise_v',float(d.qvel[0]))
        wp.route_params={**w.route_params,**patch.get('route_params',{})}
        if estimates:
            m.geom_friction[np.r_[wp.floor,wp.feet],0]=estimates['friction']
            g=estimates['leg_gain_scale']
            m.actuator_gainprm[wp.acts,0]=wp.kp*g;m.actuator_biasprm[wp.acts,1]=wp.bias*g
            ch=bp.channels[0];k=ch.p['actuator_gain']*np.asarray(estimates.get('head_gain_scale',1.))
            m.actuator_gainprm[ch.acts,0]=k;m.actuator_biasprm[ch.acts,1]=-k
            m.actuator_biasprm[ch.acts,2]=-ch.p['actuator_damping']*np.asarray(estimates.get('head_damping_scale',1.));ch.gain=np.broadcast_to(k,(2,)).copy()
        # Forecast noise and exogenous pushes are neutral. Future true sensor and process RNG are inaccessible.
        obs=PredictBall(dp,bp,self.params['ball_observer']) if 'ball_observer' in self.params else None
        plan_pace=copy.deepcopy(pace)
        startx=float(dp.qpos[0]);worst=0.;av=0.;rmax=0.;tiltmax=0.
        n=round(cfg.get('horizon_s',2.4)/.02)
        for i in range(n):
            x,y=dp.qpos[:2];s=project(x,y)[0]-s_offset
            cmd=plan_pace.command(self.params['speed_profile'],s,t+i*.02,1.)
            cmd=pit_command(cmd,x,self.params.get('pit_speed'))
            self.drive_forecast(cmd)
            if obs:obs.update()
            bp.control();mujoco.mj_step(m,dp,nstep=10);mujoco.mj_forward(m,dp)
            fail,r,_=bp.observe()
            s=project(*dp.qpos[:2])[0]-s_offset;plan_pace.observe(t+(i+1)*.02,s)
            pitch=-float(dp.xmat[wp.trunk,6]);roll=float(dp.xmat[wp.trunk,7]);tilt=math.hypot(pitch,roll)
            h=dp.qpos[2]-ground_height(dp.qpos[0])
            cost=max(0.,tilt-.125)*2.4+max(0.,pitch-.14)*2.6+max(0.,.116-h)*6+max(0.,r-.030)*10
            worst=max(worst,cost);av+=cost;tiltmax=max(tiltmax,tilt);rmax=max(rmax,r)
            if h<.075 or dp.xmat[wp.trunk,8]<.67 or fail:
                return 5.+(n-i)/n+min(1.,cost),float(dp.qpos[0]-startx),tiltmax,rmax
        dist=float(dp.qpos[0]-startx);v=dist/(n*.02)
        score=worst+.30*av/n+cfg.get('speed_cost',2.)*max(0.,cfg.get('min_v',.095)-v)
        if cfg.get('schedule_cost') and plan_pace.levels[3]=='fast' and 8.05 in plan_pace.times:
            window_target=cfg.get('schedule_target',.0955)
            if 9.65 in plan_pace.times:
                final=1.6/(plan_pace.times[9.65]-plan_pace.times[8.05])
                score+=cfg['schedule_cost']*max(0.,window_target-final)*16.
            elif s<9.65:
                left=1.6/window_target-(t+n*.02-plan_pace.times[8.05])
                required=(9.65-s)/max(.1,left)
                achievable=cfg.get('catchup_limit',.14)
                score+=cfg['schedule_cost']*min(1.,max(0.,required-achievable))*2.
                if cfg.get('projected_finish_cost'):
                    over=(9.65-s)/achievable-left
                    score+=cfg['projected_finish_cost']*max(0.,over)
        return score,dist,tiltmax,rmax
    def choose(self,w,d,bc,pace,t,s_offset,estimator):
        if self.pcfg.get('camera_belief'):self.observe_camera(d,bc)
        x=float(d.qpos[0])
        gates=self.pcfg['gates']
        trigger='station'
        if self.next<len(gates) and x>=gates[self.next]['x']:
            cfg=gates[self.next]
            self.next+=1
        else:
            cfg=self.pcfg.get('stall_recheck')
            if not cfg or not cfg['start']<=x<=cfg['end'] or self.stall_checks>=cfg['max_checks']:
                return None
            if t-self.last_stall_check<cfg['interval_s'] or len(pace.history)<cfg['samples']:
                return None
            t0,s0=pace.history[-cfg['samples']];t1,s1=pace.history[-1]
            if (s1-s0)/max(.02,t1-t0)>=cfg['speed_below']:
                return None
            self.last_stall_check=t
            self.stall_checks+=1
            trigger='low_progress'
        begin=time.monotonic()
        if self.forecast is None:self.create_forecast(bc.n_balls)
        estimates=estimator.get_estimates() if estimator is not None else None
        results=[self.predict(w,d,bc,pace,t,s_offset,{},cfg,estimates)]
        if results[0][0]>cfg.get('safe_cost',.32):
            for idx in cfg['choices']:results.append(self.predict(w,d,bc,pace,t,s_offset,self.pcfg['skills'][idx],cfg,estimates))
        best=int(np.argmin([a[0] for a in results]))
        if results[0][0]-results[best][0]<cfg.get('min_gain',.045):best=0
        choice=cfg['choices'][best-1] if best else 'keep'
        patch=self.pcfg['skills'][choice] if best else {}
        self.current.update(patch)
        self.decisions.append(dict(t=t,x=float(d.qpos[0]),chosen=choice,trigger=trigger,forecasts=results,wall_s=time.monotonic()-begin))
        return patch
