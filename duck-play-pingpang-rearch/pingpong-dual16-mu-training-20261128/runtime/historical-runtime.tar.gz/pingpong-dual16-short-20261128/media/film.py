"""Render the measured poses on the same physical floor as their evaluation."""
from pathlib import Path
import argparse
import hashlib
import json
import math
import subprocess
import sys

import mujoco
import numpy as np
from PIL import Image,ImageDraw,ImageFont

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
sys.path.insert(0,str(ROOT))
import short_track as st
sys.path.insert(0,str(ROOT.parent/'pingpong-speed-small-20261127'))
import movies as mv
TEXT='#f0f5f4';GRAY='#aec5bf';MINT='#76e5bd';AMBER='#ffc078';BG='#152b31'

def encode(trace, dest, title, fixed_grid=False, rate=12.5):
    meta=json.loads(trace.with_suffix('.json').read_text())
    track=meta['track']
    fixed=fixed_grid or trace.stem in ('static-fixture','fixed-development','fixed-paced')
    if fixed and track!='combined':
        raise ValueError('The fixed floor grid belongs to the combined course')
    if fixed:
        sys.path.insert(0,str(ROOT/'replay'))
        from fixed_ground import render_model
        m=render_model()
    else:m=st.render_model(track,meta['track_origin_x_m'])
    assert m.geom_size[m.geom('paddle_face').id,0]==.055 and abs(m.body('paddle').mass.item()-.04)<1e-9
    mv.compact_visual_meshes(m,1.0);m.vis.quality.offsamples=1
    m.vis.global_.offwidth=max(568,m.vis.global_.offwidth);m.vis.global_.offheight=max(328,m.vis.global_.offheight)
    d=mujoco.MjData(m);site=m.site('paddle_center').id;body=m.body('trunk_base').id
    c1=mv.camera([0,0,.13],.55,140,-17);c2=mv.camera([0,0,.18],.196,100,-68)
    opt=mujoco.MjvOption();opt.geomgroup[3:]=0;opt.sitegroup[:]=0
    with np.load(trace) as z:
        t=z['t'];q=z['qpos'];s=z['progress_m'];r=z['ball_radii']*1000;on=z['ball_contacts']
    assert abs(t[-1]-meta['seconds'])<1e-7
    duration=float(t[-1])
    if rate not in (12.5,25.,50.):
        raise ValueError('Choose a divisor of the 50 Hz recorded samples')
    nn=math.ceil(duration*rate-1e-8)+1
    w,h=960,556
    proc=subprocess.Popen(['ffmpeg','-nostdin','-loglevel','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s',f'{w}x{h}',
           '-r',str(rate),'-i','pipe:0','-an','-c:v','libx264','-preset','veryfast','-threads','2','-crf','21','-pix_fmt','yuv420p','-movflags','+faststart',str(dest)],stdin=subprocess.PIPE)
    fonts={n:ImageFont.truetype(mv.REGULAR,n) for n in (15,16,17,18,19,21,24,28)}
    def text(draw,xy,message,size,color,**options):
        draw.text(xy,message,font=fonts[size],fill=color,**options)
    stage={'flat':'独立平地','incline':'独立 1° 上坡','combined':'平地 → 1° 上坡 → 平台'}[track]
    if fixed:stage+=' · 固定地面网格'
    limit=2.5 if track=='combined' else max(1.1,math.ceil(10*s.max())/10.)
    with mujoco.Renderer(m,284,520) as r1,mujoco.Renderer(m,284,396) as r2:
        for j in range(nn):
            i=int(np.argmin(np.abs(t-min(duration,j/rate))))
            d.qpos[:]=q[i];mujoco.mj_kinematics(m,d);mujoco.mj_camlight(m,d)
            root=d.xpos[body];face=d.site_xpos[site]
            c1.lookat[:]=.66*root+.34*face;c2.lookat[:]=face+[0,0,.007]
            im=Image.new('RGB',(w,h),BG);draw=ImageDraw.Draw(im)
            text(draw,(17,5),title,24,TEXT);text(draw,(18,42),stage,17,GRAY)
            text(draw,(941,43),'原速回放  ·  两颗 16 mm 自由球',16,GRAY,anchor='ra')
            im.paste(mv.adjust_renderer(r1,d,c1,opt),(16,71));im.paste(mv.adjust_renderer(r2,d,c2,opt),(548,71))
            text(draw,(18,367),f'{s[i]:.3f} m',28,MINT);text(draw,(206,373),f'{t[i]:.2f} 秒',21,TEXT)
            for k in range(2):
                mark='触拍' if on[i,k] else '未触拍'
                text(draw,(405+260*k,374),f'球 {k+1}  {r[i,k]:.1f} mm  {mark}',19,[AMBER,MINT][k])
            left,right=28,930;bottom=468
            xx=np.linspace(0,limit,201)
            if track=='flat':hh=xx*0
            elif track=='incline':hh=st.GRADIENT*xx
            else:hh=st.GRADIENT*np.clip(xx-(1.02-meta['initial_x_m'] if fixed else 1),0,1.)
            pts=[(round(left+x/limit*(right-left)),round(bottom-hgt*1750)) for x,hgt in zip(xx,hh)]
            draw.line(pts,fill=GRAY,width=3)
            px=round(left+np.clip(s[i]/limit,0,1)*(right-left));py=round(bottom-np.interp(s[i],xx,hh)*1750)
            draw.ellipse((px-6,py-6,px+6,py+6),fill=MINT)
            for g in ([0,1,2,2.5] if track=='combined' else [0,1]):
                x=round(left+g/limit*(right-left));text(draw,(x,477),f'{g:g} m',15,GRAY,anchor='ma')
            marks=[('flat_1m','平地 1 m'),('slope_1m','小坡 1 m'),('cross_2p5','越过 2.5 m')]
            achieved=[label for k,label in marks if k in meta['gates'] and meta['gates'][k]['t']<=t[i]+1e-8]
            line='已通过  '+'、'.join(achieved) if achieved else '尚未通过一米门槛'
            if i==len(t)-1:line+='   |   '+('停车完成' if meta['success'] else mv.reason_zh(meta['reason']))
            text(draw,(18,514),line,18,TEXT);text(draw,(941,516),'纵向高差已放大',15,GRAY,anchor='ra')
            proc.stdin.write(im.tobytes())
    proc.stdin.close()
    if proc.wait(): raise RuntimeError('Video encoder failed')
    dest.with_suffix('.json').write_text(json.dumps(dict(trace=str(trace.relative_to(ROOT)),sha256=hashlib.sha256(trace.read_bytes()).hexdigest(),
            original_time_s=duration,frames=nn,rate=rate,track=track,fixed_grid=fixed,gates=meta['gates'],reason=meta['reason']),indent=2))

if __name__=='__main__':
    cli=argparse.ArgumentParser();cli.add_argument('trace',type=Path);cli.add_argument('dest',type=Path);cli.add_argument('title')
    cli.add_argument('--fixed-grid',action='store_true',help='Use the physical fixture whose slope begins at world x=1.02 m')
    cli.add_argument('--fps',type=float,choices=(12.5,25.,50.),default=12.5)
    args=cli.parse_args()
    encode(args.trace.resolve(),args.dest.resolve(),args.title,args.fixed_grid,args.fps)
