"""Bounded search for support posture and launch timing on an opened incline start."""
from concurrent.futures import ProcessPoolExecutor
import argparse, json
from pathlib import Path
import numpy as np
import start_modes as sm
D=Path(__file__).resolve().parent
SCALES=np.array([.24,.13,.11,.014,.010,.025,.065])
LO=np.array([.40,0.,.055,-.14,-.035,.14,.30]);HI=np.array([2.1,1.05,.85,-.025,.065,.31,.72])

def prepare(name,values):
    p=sm.parameters(name);settle,wait,ramp,hip,ankle,neck,command=values
    p.update(settle_s=round(settle*50)/50,wait_s=wait,ramp_s=ramp)
    p['stand_pose'].update(hip_trim=hip,ankle_trim=ankle,neck_trim=neck)
    p['speed_profile']['launch_command']=command
    for v in p.get('latency_profiles',[]):
        if 'speed_profile' in v['overrides']:v['overrides']['speed_profile']['launch_command']=command
    return p

def trial(job):
    name,seed,values=job;p=prepare(name,values)
    r=sm.st.run('incline',seed,p);return {'mode':name,'seed':seed,'values':list(values),'gate':r['slope_1m'],'peak':r['both_peak_m'],'seconds':r['seconds'],'tilt':r['max_tilt_deg'],'reason':r['reason']}

def start(name):
    p=sm.parameters(name);q=p['stand_pose'];return np.array([p.get('settle_s',1.),p['wait_s'],p['ramp_s'],q['hip_trim'],q['ankle_trim'],q['neck_trim'],p['speed_profile']['launch_command']])

def main():
    parser=argparse.ArgumentParser();parser.add_argument('rank',type=int);args=parser.parse_args();sm.collision_actor.install(sm.spec['settings'])
    mine=json.loads((D/'mine.json').read_text())['rows'];origin=sorted(mine,key=lambda r:r['peak'] if r['tilt']<30 else 0.,reverse=True)[args.rank]
    name,seed=origin['mode'],origin['seed']; folder=D/f'prep-fit-{args.rank}-{seed}';folder.mkdir(exist_ok=True);rng=np.random.default_rng(145924+args.rank);vals=start(name)
    best=trial((name,seed,vals));poolrows=[best];rows=[];bad=0;ranks=lambda r:(r['gate'],r['peak'] if r['tilt']<30 else 0.,r['seconds'])
    print('base',best,flush=True)
    with ProcessPoolExecutor(6) as pool:
        for layer in range(12):
            options=[poolrows[i%len(poolrows)] for i in range(36)];jobs=[]
            for i,root in enumerate(options):
                x=np.array(root['values']);sigma=(1. if i%4==0 else .08 if i%4==1 else .013 if i%4==2 else .002)
                if layer>3:sigma*=.65
                v=np.clip(x+rng.normal(size=len(x))*SCALES*sigma,LO,HI);v[0]=round(v[0]*50)/50
                jobs.append((name,seed,v.tolist()))
            result=list(pool.map(trial,jobs,chunksize=2));rows+=result
            previous=best;ranked=sorted(poolrows+result,key=ranks,reverse=True);best=ranked[0];poolrows=[];peaks=set()
            for r in ranked:
                k=round(r['peak'],3)
                if k not in peaks:poolrows.append(r);peaks.add(k)
                if len(poolrows)==3:break
            bad=bad+1 if best['peak']<=previous['peak']+.002 else 0
            (folder/'interim.json').write_text(json.dumps(dict(best=best,layer=layer,branches=len(rows)),indent=2));print(layer,best['peak'],best['gate'],flush=True)
            if best['gate'] or bad>=4:break
    (folder/'fit.json').write_text(json.dumps(dict(base=origin,best=best,trials=rows),indent=2));r=sm.st.run('incline',seed,prepare(name,best['values']),trace=folder/'best.npz');assert r['both_peak_m']==best['peak']

if __name__=='__main__':main()
