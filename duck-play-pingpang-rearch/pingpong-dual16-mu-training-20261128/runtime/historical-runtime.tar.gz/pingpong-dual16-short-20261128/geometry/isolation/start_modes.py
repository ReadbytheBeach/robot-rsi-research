"""Compare whole-robot preparation and launch modes on the 1° incline, unchanged ball release."""
import argparse, collections, copy, json, sys
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
import numpy as np
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parents[1]))
import short_track as st
sys.path.insert(0,str(st.PREVIOUS/'sealed/extension'))
import collision_actor
spec=json.loads((st.PREVIOUS/'sealed/extension/candidate.json').read_text())
MODES={
    'original': {},
    'settle_short': {'settle_s':.54},
    'settle_long': {'settle_s':1.76},
    'quiet_then_walk': {'settle_s':1.42,'wait_s':.74,'ramp_s':.43},
    'immediate': {'settle_s':.86,'wait_s':0.,'ramp_s':.12,'cmd':.57},
    'steady_then_fast': {'settle_s':1.6,'wait_s':.16,'ramp_s':.25,'cmd':.56},
    'risk_launch': {'settle_s':1.22,'wait_s':.12,'ramp_s':.30,'cmd':.53,'gate':{'radius':.026,'velocity':.096,'max_wait':.42}},
    'lower_neck': {'settle_s':1.4,'wait_s':.05,'ramp_s':.28,'cmd':.5,'pose':{'neck_trim':.17,'hip_trim':-.055}},
    'forward_bias': {'settle_s':1.24,'wait_s':.08,'ramp_s':.25,'cmd':.56,'pose':{'hip_trim':-.105,'ankle_trim':.03,'neck_trim':.194}},
}

def parameters(name):
    p=copy.deepcopy(spec['params']);cfg=MODES[name]
    for k in ('settle_s','wait_s','ramp_s'):
        if k in cfg:p[k]=cfg[k]
    if 'gate' in cfg:p['launch_gate']=cfg['gate']
    if 'pose' in cfg:p['stand_pose'].update(cfg['pose'])
    if 'cmd' in cfg:
        def set_cmd(q):
            if 'speed_profile' in q:q['speed_profile'].update(launch_command=cfg['cmd'],launch_until_m=.67,launch_blend_m=.22)
        set_cmd(p)
        for val in p.get('by_order',{}).values():set_cmd(val)
        for val in p.get('latency_profiles',[]):set_cmd(val['overrides'])
    return p

def trial(payload):
    name,seed=payload
    r=st.run('incline',seed,parameters(name));return dict(mode=name,seed=seed,peak=r['both_peak_m'],end=r['last_both_m'],gate=r['slope_1m'],seconds=r['seconds'],reason=r['reason'],tilt=r['max_tilt_deg'],finish=r['success'])

def stats(rows):
    out={}
    for mode in sorted({r['mode'] for r in rows}):
        group=[r for r in rows if r['mode']==mode];d=np.array([r['peak'] for r in group]);out[mode]=dict(n=len(group),complete=sum(r['gate'] for r in group),half=int(sum(d>=.5)),quarter=int(sum(d>=.25)),p90=float(np.quantile(d,.9)),mean=float(np.mean(d)),best=max(group,key=lambda r:r['peak']))
    return out

def batch(filename,jobs):
    with ProcessPoolExecutor(8) as pool: rows=list(pool.map(trial,jobs,chunksize=8))
    out=dict(rows=rows,summary=stats(rows));(HERE/filename).write_text(json.dumps(out,indent=2)); print(filename,[(k,v['complete'],v['half'],round(v['best']['peak'],3)) for k,v in out['summary'].items()],flush=True);return out

def run():
    collision_actor.install(spec['settings'])
    dev=batch('screen.json',[(m,s) for s in range(14400000,14400040) for m in MODES])
    def rating(k):
        r=dev['summary'][k];return (r['complete'],r['half'],r['quarter'],r['p90'],r['mean'])
    selected=sorted(MODES,key=rating,reverse=True)[:3]
    modes=list(dict.fromkeys(['original',*selected]));(HERE/'selection.json').write_text(json.dumps(dict(modes=modes,configs={k:MODES[k] for k in modes}),indent=2))
    batch('mine.json',[(modes[((s-14401000)//2)%len(modes)],s) for s in range(14401000,14403400)])
    batch('uniform.json',[(m,s) for s in range(14404000,14404256) for m in ['original', selected[0]] if m!='original' or selected[0]!='original'] if selected[0]!='original' else [('original',s) for s in range(14404000,14404256)])

if __name__=='__main__':run()
