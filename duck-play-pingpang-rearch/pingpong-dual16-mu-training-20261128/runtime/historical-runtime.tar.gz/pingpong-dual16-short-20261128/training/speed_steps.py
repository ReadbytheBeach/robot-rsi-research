"""Separate fixed-speed calibration and pulse/odometry control studies."""
from concurrent.futures import ProcessPoolExecutor
from contextlib import contextmanager
from copy import deepcopy
from pathlib import Path
from unittest.mock import patch
import csv, hashlib, json, os, sys

import numpy as np

import actors
import study
from study import HERE, ROOT, TRACKS, BASE, save
import ball
import locomotion


def fixed(speed):
    return dict(mode="fixed",cruise=speed,wait=.18,ramp=.44)


def bank():
    out={f"input-{v:.2f}":fixed(v) for v in (.26,.32,.36,.40,.44,.50,.56,.64,.70)}
    for speed,nom in ((.05,.37),(.09,.44),(.13,.59)):
        out[f"target-{speed:.2f}"]={**fixed(nom),"variant":"odometry","target":speed}
    for kind in ("pulse","catch"):
        for nominal in (.40,.52,.65):
            for strength in (0.55,1.0):
                name=f"{kind}-{nominal:.2f}-{strength:.2f}"
                out[name]={**fixed(nominal),"variant":kind,"strength":strength}
    return out


@contextmanager
def vary(p):
    original=locomotion.Locomotion.control
    reset_original=ball.BallController.reset
    active = {"bc": None, "command":0., "vx":0., "offset":0., "x":None}
    def reset(bc,*args,**kwargs):
        ret=reset_original(bc,*args,**kwargs)
        if active["bc"] is None:
            active["bc"]=bc
        return ret
    def drive(w,d,speed):
        bc=active["bc"]
        if bc is None or d is not bc.d or speed<=0. or not p.get("variant"):
            return original(w,d,speed)
        a,b=bc.channels;t=a.tick*.02
        x=float(d.qpos[w.root])
        if active["x"] is None:active["x"]=x
        active["vx"]+=.12*((x-active["x"])/.02-active["vx"])
        active["x"]=x
        blend=min(1.,speed/p['cruise'])
        variant=p["variant"]
        additional=0.
        if variant=="odometry":
            if t>.40:
                err=p["target"]-active["vx"]
                active["offset"]=np.clip(active["offset"]+.065*err,-.17,.19)
                additional=np.clip(1.35*err+active["offset"],-.17,.19)
        else:
            z=.5*(a.measurements[0]+b.measurements[0])
            if variant=="pulse":
                # Submit the higher forward input only in one support phase, and
                # soften the other while the measured pair centre moves outwards.
                ydiff=(d.geom_xpos[w.feet[0],2]-d.geom_xpos[w.feet[1],2])
                danger=np.clip((np.linalg.norm(z[:2]+.15*z[2:])-.012)/.035,0.,1.)
                additional=.19*p["strength"]*np.tanh(ydiff/.007)*(1.-.5*danger)
            else:
                frame=d.site_xmat[a.site].reshape(3,3)
                lead_local=np.r_[z[:2]+.18*z[2:],0.]
                lead_world=frame@lead_local
                additional=float(np.clip(4.*p["strength"]*lead_world[0],-.19,.19))
        active["command"]+=float(np.clip(additional-active["command"],-.028,.028))
        return original(w,d,float(np.clip(speed+blend*active["command"],.015,.75)))
    with patch.object(ball.BallController,"reset",reset),patch.object(locomotion.Locomotion,"control",drive):
        yield


def run(j):
    n,p,t,s=j
    with vary(p):return study.episode((n,p,t,s,None,None))


def table(stage, recipes, ids, pool):
    jobs=[(n,p,terrain,seed) for seed in ids for n,p in recipes.items() for terrain in TRACKS]
    rows=list(pool.map(run,jobs,chunksize=6))
    with (HERE/("speed-"+stage+".csv")).open("w") as f:
        writer=csv.DictWriter(f,fieldnames=rows[0].keys());writer.writeheader();writer.writerows(rows)
    scores={name:{t:study.summary([r for r in rows if r["track"]==t and r["name"]==name]) for t in TRACKS} for name in recipes}
    save("speed-"+stage+".json",scores)
    return sorted(scores,key=lambda n:study.rank(scores[n]),reverse=True)


def main():
    rp=bank()
    save("speed-protocol.json",dict(calibrate=[14603500,14603563],verify=[14703500,14703755],
                                    choices=rp,selection="Keep all nine fixed input levels, three target-odometry levels and highest developmental pulse/catch. No new studies use reserved 14703500 range."))
    with ProcessPoolExecutor(int(os.getenv("SPEED_WORKERS",5))) as pool:
        ranked=table("train",rp,range(14603500,14603564),pool)
        selected={n:p for n,p in rp.items() if n.startswith(("input","target"))}
        winner=next(n for n in ranked if n.startswith(("pulse","catch")))
        selected[winner]=rp[winner]
        save("speed-frozen.json",dict(selected=selected,source=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
        print("ranked",ranked[:6],"selected",winner,flush=True)
        table("validation",selected,range(14703500,14703756),pool)


if __name__=="__main__":main()
