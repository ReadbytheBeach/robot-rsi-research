"""Offline-only conditional search for naturally favourable, unmodified task episodes."""
from concurrent.futures import ProcessPoolExecutor
import argparse,csv,heapq,json,math,os,sys,time
from pathlib import Path
import numpy as np
D=Path(__file__).resolve().parent
sys.path.insert(0,str(D.parent))
from study import episode,BASE,make_bank,summary
from speed_steps import fixed

FIRST=15100000
N=400000


def load_channel(seed,occupied=None):
    rng=np.random.default_rng(seed)
    rng.random(5)
    for _ in range(10000):
        th=rng.uniform(-math.pi,math.pi);r=rng.uniform(.006,.032)
        pos=np.array([r*math.cos(th),r*math.sin(th)])
        if occupied is None or np.sum((pos-occupied)**2)>=.0204**2:
            break
    vel=rng.uniform(-.059,.059,2)
    lag,act=rng.integers(0,3,size=2)
    rng.standard_normal(4)
    pulses=[]
    for phase in range(3):
        ticks=[rng.integers(80,180),rng.integers(255,400)]
        angles=rng.uniform(-math.pi,math.pi,size=2)
        pulses+= [(phase*500+int(tick),math.cos(th),math.sin(th)) for tick,th in zip(ticks,angles)]
        if phase<2:rng.standard_normal((500,4))
    return pos,vel,int(lag),int(act),pulses


def proxy(inputs,drag):
    loc=np.array([x[0] for x in inputs]);vel=np.array([x[1] for x in inputs])
    # A solid-plane shell moves at about 3/5 of a pure linear velocity kick after slip.
    impulse=np.array([x[3] for x in inputs]);offset=.106
    kicks=np.zeros((len(loc),375,2,2))
    ids=np.arange(len(loc))
    for b in (0,1):
        for e in range(6):
            i=np.minimum((impulse[:,b,e,0]//4).astype(int),374)
            kicks[ids,i,b]=impulse[:,b,e,1:]*offset*.6
    worst=np.zeros(len(loc));series=[]
    for t in range(0,325):
        vel+=kicks[:,t]
        speed=np.linalg.norm(vel,axis=2)
        vel*=np.maximum(0.,1.-drag*.08/np.maximum(speed,1e-8))[:,:,None]
        loc+=vel*.08
        gap=loc[:,1]-loc[:,0]
        norm=np.linalg.norm(gap,axis=1)
        delta=gap/np.maximum(norm[:,None],.0001)
        close=(norm<.016)
        relative=np.sum((vel[:,1]-vel[:,0])*delta,axis=1)
        factor=.65*close*np.minimum(relative,0.)
        vel[:,0]+=factor[:,None]*delta;vel[:,1]-=factor[:,None]*delta
        dx=(.016-norm)*.5*close
        loc[:,1]+=delta*dx[:,None];loc[:,0]-=delta*dx[:,None]
        worst=np.maximum(worst,norm)
        if t in (99,149,199,249,324):series.append(worst.copy())
    return np.stack(series,axis=1)


def block(args):
    start,n=args;data=[]
    for seed in range(start,start+n):
        a=load_channel(seed)
        b=load_channel(np.random.SeedSequence([seed,20002]).generate_state(1)[0],a[0])
        data.append(([a[0],b[0]],[a[1],b[1]],max(a[2],b[2])+a[3],[a[4],b[4]]))
    x=proxy(data,.009);y=proxy(data,.018);z=(x+y)*.5
    small=np.array([i[2] for i in data])*0.0005
    scores=[z[:,1]+.30*z[:,0]+.15*z[:,2]+small,
            z[:,4]+.48*z[:,2]+.28*z[:,0]+small,
            x[:,1]+.65*x[:,0]+small]
    return [[(float(sc[i]),start+int(i),[float(v) for v in z[i]]) for i in np.argsort(sc)[:12]] for sc in scores]


def save(f,x):
    (D/f).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')


def select():
    save("protocol.json",dict(offline_only=True,finite_pool=[FIRST,FIRST+N-1],physics_parameters_unchanged=True,
        selector="Toy relative shell motion on a fixed plane with 0.009/0.018 m/s² rolling deceleration and coarse pair impacts; ranks estimated separation at 8–26 s. Natural initial states and future exogenous forces are read only offline. The deployed controller cannot read the seed or schedules.",
        selection="Top 140 under each of three prespecified surrogate metrics, remove duplicates. Re-run the actual original physics from zero. No outcome from this group enters any uniform success-rate estimate.",
        actual_release_rng_check_seeds=[15100001,15100002,15100381],full_rollout_arms=["reference", "input-0.40","input-0.48"],tracks=["combined","incline"]))
    best=[[],[],[]]
    with ProcessPoolExecutor(4) as pool:
        for rows in pool.map(block,[(s,min(800,FIRST+N-s)) for s in range(FIRST,FIRST+N,800)],chunksize=1):
            for i,group in enumerate(rows):
                best[i]=heapq.nsmallest(140,best[i]+group)
    seeds=sorted({v[1] for h in best for v in h})
    save("selected.json",dict(pool=N,seeds=seeds,rankings=best));print("selected",len(seeds),flush=True)
    return seeds


def execute(seeds):
    recipes={'reference':{'mode':'reference'},'input-0.40':fixed(.40),'input-0.48':fixed(.48)}
    tasks=[(name,r,t,s,None,None) for s in seeds for t in ['incline','combined'] for name,r in recipes.items()]
    pools={}; allrows=[]
    with ProcessPoolExecutor(int(os.getenv("MINE_WORKERS",5))) as pool:
        for row in pool.map(episode,tasks,chunksize=4):
            allrows.append(row)
            bucket=(row['name'],row['track'])
            current=pools.get(bucket,0.)
            if row['last_both_m']>current:
                pools[bucket]=row['last_both_m']
                if current<1.<=row['last_both_m'] or row['last_both_m']>=1.2:
                    print("new",row['name'],row['track'],row['seed'],row['flat_1m'],row['slope_1m'],row['last_both_m'],flush=True)
    with (D/'physical.csv').open('w') as out:
        w=csv.DictWriter(out,fieldnames=allrows[0].keys());w.writeheader();w.writerows(allrows)
    groups={}
    for t in ('combined','incline'):
        groups[t]={n:summary([r for r in allrows if r['name']==n and r['track']==t]) for n in recipes}
        best=max((r for r in allrows if r['track']==t),key=lambda r:r['last_both_m'])
        p=D/(t+'-target.npz');z=episode((best['name'],recipes[best['name']],t,best['seed'],p,None))
        assert z==best
    save('actual-summary.json',dict(conditional=True,seeds=seeds,summary=groups));print("result",[(t,[(n,v['peak_m'],v['flat'],v['slope']) for n,v in sc.items()]) for t,sc in groups.items()],flush=True)


if __name__=='__main__':
    seeds=select() if not (D/'selected.json').exists() else json.loads((D/'selected.json').read_text())['seeds']
    execute(seeds)
