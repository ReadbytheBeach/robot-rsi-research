"""A gait command can react to delayed, delivered ball measurements only."""
from contextlib import contextmanager
from copy import deepcopy
from pathlib import Path
from unittest.mock import patch
import sys

import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
PREV = ROOT.parent / "pingpong-dual16-antigravity-20261128"
FROZEN = ROOT.parent / "pingpong-turn-pit-20261128" / "frozen" / "double16-stand"
sys.path.insert(0, str(FROZEN))
sys.path.insert(0, str(PREV / "sealed" / "extension"))
import ball
import collision_actor
import locomotion


def configured(params, recipe):
    p = deepcopy(params)
    if recipe.get("mode") == "reference":
        return p
    velocity = recipe["cruise"]
    profile = {"slow": velocity, "fast": velocity, "kp": 0., "ki": 0.}
    p.update(speed=velocity, speed_profile=profile, wait_s=recipe["wait"], ramp_s=recipe["ramp"])
    for setting in p.get("latency_profiles", []):
        overrides = setting["overrides"]
        if "speed_profile" in overrides:
            overrides["speed_profile"] = profile
    for setting in p["by_order"].values():
        if "speed_profile" in setting:
            setting["speed_profile"] = profile
    # The original 10 m skills use the first crest at 1.63 m and can override
    # speed profiles. The new track has a different survey and requires fixed speed.
    for group in [p,*p["by_order"].values(),*(row["overrides"] for row in p["latency_profiles"])]:
        for key in ("skill_planner","observer_id","pit_speed","dock_steer"):
            group.pop(key,None)
    return p


@contextmanager
def controller(recipe, aim):
    collision_actor.install(aim)
    reset_original = ball.BallController.reset
    drive_original = locomotion.Locomotion.control
    head_original = ball.BallChannel.control
    monitor = {"live": None, "samples": [], "scale": 1., "origin": None}
    live = monitor

    def reset(bc, *args, **kwargs):
        result = reset_original(bc,*args,**kwargs)
        if live["live"] is None:
            live["live"] = bc
            live["origin"] = float(bc.d.qpos[0])
        return result

    def drive(walk, data, speed):
        bc = live["live"]
        if bc is None or data is not bc.d:
            return drive_original(walk,data,speed)
        a,b = bc.channels
        is_feedback = recipe["mode"] == "risk"
        if is_feedback:
            za,zb = a.measurements[0], b.measurements[0]
            h = recipe.get("lookahead", .18)
            radius = max(np.linalg.norm(za[:2]+h*za[2:]), np.linalg.norm(zb[:2]+h*zb[2:]))
            span = np.linalg.norm(za[:2]+h*za[2:]-zb[:2]-h*zb[2:])
            risk = float(np.clip((max(radius,.5*span)-recipe["threshold"])/.022,0.,1.))
            target = (1.-risk)*recipe.get("safe",1.) +risk*recipe["danger"]
            live["scale"] += np.clip(target-live["scale"], -.12, .12)
            speed = float(np.clip(speed*live["scale"],0.,.75))
        result = drive_original(walk,data,speed)
        if speed and recipe.get("hip",0.):
            factor = min(1., a.tick * .02 / .4)
            for j, sign in ((2,1.),(11,-1.)):
                data.ctrl[walk.acts[j]] += sign*factor*recipe["hip"]
        actual_cmd = float(walk.obs[0,48])
        live["samples"].append((a.tick*.02,float(data.qpos[walk.root])-live["origin"],actual_cmd))
        return result

    def tilts(ch, estimate=None):
        bc = live["live"]
        if bc is not None and ch is bc.channels[0] and recipe.get("centroid",0.):
            both = .5 * (ch.measurements[0] + bc.channels[1].measurements[0])
            shift = np.clip(-recipe["centroid"]*(both[2:]+2.*both[:2]),-.15,.15)
            ch.plate_bias = ch.plate_bias + shift
        return head_original(ch,estimate)

    with patch.object(ball.BallController,"reset",reset), patch.object(locomotion.Locomotion,"control",drive), patch.object(ball.BallChannel,"control",tilts):
        try:
            yield monitor
        finally:
            collision_actor.install(None)


def speed_summary(samples, result):
    d=np.asarray(samples)
    sec=result["seconds"]
    net=result["distance_m"]
    if not len(d):raise ValueError("missing real gait samples")
    x = np.r_[d[:,1],net]
    counts = d[:,2]>.05
    select=np.flatnonzero(counts)
    forward_times = .02*len(select)
    delta=np.diff(x)
    crossings=[]
    for g in (.10,.30):
        where=np.flatnonzero(x>=g)
        if len(where) and where[0]>0:
            i=where[0];crossings.append(.02*(i-1+(g-x[i-1])/max(1e-10,x[i]-x[i-1])))
    return dict(net_mps=net/sec, command_avg=float(d[:,2].mean()),
                command_active_max=float(d[:,2].max()), moving_x_m=float(delta[counts].sum()),
                commanded_motion_s=forward_times, v_10_30=(.20/(crossings[1]-crossings[0]) if len(crossings)==2 else None))
