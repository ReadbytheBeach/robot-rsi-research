"""Train on two fixed short-course geometries and score a disjoint paired cohort."""
from concurrent.futures import ProcessPoolExecutor
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import sys
import time

import numpy as np

from actors import HERE, ROOT, PREV, configured, controller, speed_summary
sys.path.insert(0, str(ROOT))
BASE = json.loads((PREV/"sealed/extension/candidate.json").read_text())
P = json.loads((HERE/"protocol.json").read_text())
TRACKS = P["tracks"]


def save(name, obj):
    dest=HERE/name;tmp=dest.with_suffix(".tmp")
    tmp.write_text(json.dumps(obj, indent=2, ensure_ascii=False)+"\n")
    tmp.replace(dest)


def make_bank():
    rng=np.random.default_rng(284432)
    d={"reference":dict(mode="reference")}
    for name,cruise in P["fixed_inputs"].items():
        d[name]=dict(mode="fixed",cruise=cruise,ramp=.44,wait=.18)
    for i in range(56):
        risk=(i%4!=0)
        r=dict(mode="risk" if risk else "fixed",cruise=float(rng.uniform(.22,.72)),
               wait=float(rng.choice([0.,.04,.08,.16,.28,.55])),ramp=float(rng.choice([.12,.22,.36,.55,.68,.95])),
               centroid=float(rng.choice([0.,0.,.15,.39,.75,-.20,-.40])),
               hip=float(rng.choice([0.,0.,.020,-.025,.055,-.06])))
        if risk:
            r.update(lookahead=float(rng.uniform(.09,.32)),threshold=float(rng.uniform(.019,.039)),
                     safe=float(rng.uniform(.85,1.26)),danger=float(rng.choice([.25,.45,.62,.80,1.14,1.28,1.46])))
        d[f'search-{i:02}']=r
    return d


def episode(job):
    import short_track
    name, recipe, track, seed, trace, hook = job
    params=configured(BASE["params"],recipe)
    with controller(recipe, BASE["settings"]) as m:
        result=short_track.run(track,seed,params,trace=trace,timeout=45.,model_hook=hook)
    stats={k:result[k] for k in ("flat_1m","slope_1m","finish_2p5","valid_peak_m","last_both_m","reason","seconds","distance_m")}
    stats.update(speed_summary(m["samples"],result))
    stats.update(name=name,track=track,seed=int(seed),max_nm=float(max(result["motor"]["peak_nm"])),tilt_deg=float(result["max_tilt_deg"]))
    if trace:
        files=Path(trace)
        np.savez_compressed(files.with_suffix(".speed.npz"),samples=np.array(m["samples"]))
    return stats


def summary(rows):
    n=len(rows)
    valid=np.array([r["valid_peak_m"] for r in rows]);both=np.array([r["last_both_m"] for r in rows])
    crossed=[r["v_10_30"] for r in rows if r["v_10_30"] is not None]
    movement=sum(r["commanded_motion_s"] for r in rows)
    return dict(n=n,flat=sum(bool(r["flat_1m"]) for r in rows),slope=sum(bool(r["slope_1m"]) for r in rows),
                finish=sum(bool(r["finish_2p5"]) for r in rows),half=int(np.count_nonzero(valid>=.50)),
                quarter=int(np.count_nonzero(valid>=.25)),mean=float(valid.mean()),p90=float(np.percentile(valid,90)),
                peak_m=float(valid.max()),best_seed=rows[int(np.argmax(valid))]["seed"],
                max_last_both=float(both.max()),mean_duration=float(np.mean([r["seconds"] for r in rows])),
                mean_net_mps=float(np.mean([r["net_mps"] for r in rows])),
                pooled_moving_mps=sum(r["moving_x_m"] for r in rows)/movement if movement else None,
                v_10_30_n=len(crossed),v_10_30_median=float(np.median(crossed)) if crossed else None,
                max_nm=max(r["max_nm"] for r in rows))


def rank(t):
    c,i=[t[k] for k in TRACKS]
    return (c["finish"],c["slope"],c["flat"]+i["slope"],c["half"]+i["half"],min(c["p90"],i["p90"]),c["mean"]+i["mean"])


def batch(stage, bank, pool):
    cfg=P[stage]
    jobs=[(name,r,track,s,None,None) for s in range(cfg["seed"],cfg["seed"]+cfg["n"]) for track in TRACKS for name,r in bank.items()]
    rows=list(pool.map(episode,jobs,chunksize=8))
    sums={name:{track:summary([v for v in rows if v['name']==name and v['track']==track]) for track in TRACKS} for name in bank}
    assert all(s['max_nm']<=.200001 and s['n']==cfg['n'] for t in sums.values() for s in t.values())
    with (HERE/(stage+".csv")).open("w") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    ordered=sorted(bank,key=lambda x:rank(sums[x]),reverse=True)
    save(stage+".json",dict(scores=sums,order=ordered))
    print(stage,[(n,[(t,sums[n][t]['half'],round(sums[n][t]['peak_m'],3)) for t in TRACKS]) for n in ordered[:4]],flush=True)
    return ordered


def selection():
    bank=make_bank()
    save("recipes.json",bank)
    with ProcessPoolExecutor(int(os.environ.get("SHORT_WORKERS",10))) as pool:
        ranks=batch("exploratory_screen",bank,pool)
        shortlist={n:bank[n] for n in ["reference",*P["fixed_inputs"],*[r for r in ranks if r.startswith("search")][:9]]}
        second=batch("selection",shortlist,pool)
    chosen=[k for k in second if k.startswith("search")][:2]
    if not any(bank[n]["mode"]=="risk" for n in chosen):
        chosen[-1]=next(k for k in second if bank[k]["mode"]=="risk")
    hold={n:bank[n] for n in ["reference",*P["fixed_inputs"],*chosen]}
    hashes={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in
            [HERE/"actors.py",HERE/"study.py",HERE/"protocol.json",ROOT/"short_track.py"]}
    save("frozen.json",dict(time=time.strftime("%Y-%m-%d %H:%M:%S %z"),seeds=P["fresh"],recipes=hold,hashes=hashes,
                            base_sha256=hashlib.sha256((PREV/"sealed/extension/candidate.json").read_bytes()).hexdigest()))
    return hold


def evaluate():
    frozen=json.loads((HERE/"frozen.json").read_text())
    for f,h in frozen['hashes'].items():assert hashlib.sha256((ROOT/f).read_bytes()).hexdigest()==h,(f,h)
    with ProcessPoolExecutor(int(os.environ.get("SHORT_WORKERS",10))) as pool:
        batch("fresh",frozen["recipes"],pool)


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("mode",choices=["prepare","fit","test","all","trace"])
    parser.add_argument("--name")
    parser.add_argument("--seed",type=int)
    parser.add_argument("--track",default="combined")
    a=parser.parse_args()
    if a.mode=="prepare":save("recipes.json",make_bank())
    if a.mode in ("fit","all"):selection()
    if a.mode in ("test","all"):evaluate()
    if a.mode=="trace":
        chosen=json.loads((HERE/"recipes.json").read_text())
        path=HERE/f'{a.track}-{a.seed}-{a.name}.npz'
        result=episode((a.name,chosen[a.name],a.track,a.seed,path,None))
        print(result);save(path.stem+"-score.json",result)
