"""Alternate measured fixture: keep the original floor grid underfoot throughout release."""
from contextlib import contextmanager
from functools import lru_cache
import copy
import json
from unittest.mock import patch

import mujoco
import numpy as np
import transfer as e
st=e.short_track
START=1.02
END=2.02

def elevation(x):
    return st.GRADIENT*np.clip(np.asarray(x)-START,0.,END-START)

@lru_cache(maxsize=4)
def template(track,terrain,mass,count,diameter):
    m=st.write_profile(copy.copy(st.course.template(terrain,mass,count,diameter)), 'combined')
    f=m.geom('floor').id;h=int(m.geom_dataid[f]);n=int(m.hfield_ncol[h])
    r=m.hfield_size[h,0]; xx=np.linspace(m.geom_pos[f,0]-r,m.geom_pos[f,0]+r,n)
    vals=(elevation(xx)-m.geom_pos[f,2])/m.hfield_size[h,2]
    m.hfield_data.reshape(-1,n)[:]=vals
    return m

class Meter(st.Meter):
    def release(self,m,d,start):
        self.origin=float(start[0]);self.start_y=float(start[1])
        if self.origin>START-1.+1e-9:
            raise RuntimeError('Insufficient true flat before the first metre')
        # Floor and robot are stationary in model coordinates. No re-forward or translation here.
    def ground(self,x,y=None):
        return float(elevation(x))
    def observe(self,t,distance,fail,on_face,audit,controller):
        super().observe(t,distance,fail,on_face,audit,controller)
        if self.valid and on_face:
            self.slope_m=max(0.,min(1.,self.both_peak+self.origin-START))
        if distance+self.origin<END and not getattr(self,'slope_done',False):
            self.gates.pop('slope_1m',None)
        self.slope_done='slope_1m' in self.gates

@contextmanager
def fixed():
    with patch.object(st,'_template',template),patch.object(st,'Meter',Meter):
        yield

def render_model():
    return copy.copy(template('combined',True,40.,2,16.))

def main():
    with fixed():
        r=e.run('combined',e.SEED,actions=e.TEACHER,trace=e.HERE/'static-fixture.npz')
    m=render_model();d=mujoco.MjData(m);mujoco.mj_forward(m,d);g=m.geom('floor').id
    def ray(x):
        a=mujoco.mj_rayHfield(m,d,g,np.array([x,.117,.3]),np.array([0.,0.,-1.]))
        return float(.3-a)
    x0=e.previous.read(e.HERE/'static-fixture.json')['initial_x_m']
    probes=[.20,x0+1,START+.001,1.52,END-.001,2.4]
    assert x0+1<=START
    heights={str(x):ray(x) for x in probes}
    assert max(abs(ray(x)-elevation(x)) for x in probes)<1e-7
    rows=[r]
    with fixed():
        for speed in [.70,.85,1.15,1.30]:
            rows.append(e.run('combined',e.SEED,scale=speed,actions=e.TEACHER))
    e.save('static-fixture-audit.json',dict(start_x=x0,slope_start_world=START,slope_end_world=END,flat_to_slope_m=START-x0,ray_heights=heights,rows=rows))
    print(rows,flush=True)

if __name__=='__main__':main()
