"""Transfer the archived feedback pulses to the new physical course without editing the archive."""
from concurrent.futures import ProcessPoolExecutor
from functools import partial
from pathlib import Path
import argparse
import ast
import inspect
import json
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
OLD = ROOT.parent / 'pingpong-dual16-antigravity-20261128'
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(OLD/'evidence/opened-route'))
import short_track
import search_opened as previous
from friction.contact_surface import configure_surface

TEACHER = previous.read(previous.HERE/'farthest-actions.json')['actions']
SEED = 12600381
BASE = previous.spec['params']
ACTIVE = {}
SCORES = ('flat_1m','slope_1m','finish_2p5','valid_peak_m','last_both_m','seconds','reason','max_tilt_deg','distance_m','success','gates','stable_finish_s')

def dispatch(seed, params, trace):
    if ACTIVE['track']=='fixed':
        from fixed_ground import fixed
        with fixed():
            row=short_track.run('combined',seed,params,trace=trace,timeout=45.,model_hook=partial(configure_surface,mode=ACTIVE['material']))
        return row
    return short_track.run(ACTIVE['track'], seed, params, trace=trace, timeout=45.,
                           model_hook=partial(configure_surface, mode=ACTIVE['material']))

def score_row(result, fingerprint, actions):
    row = {k:result[k] for k in SCORES if k in result}
    row.update(seed=ACTIVE['seed'], track=ACTIVE['track'], material=ACTIVE['material'],
               scale=ACTIVE['scale'], fork_sha=fingerprint, torque_nm=max(result['motor']['peak_nm']))
    return row

def archive_adapter():
    # Retain the original sensor feedback, actuator writes, tick semantics, and fork state.
    tree=ast.parse(inspect.getsource(previous.simulate))
    replacements={'r':"r = dispatch(SEED, spec['params'], savepath)",
                  'result':'result = score_row(r, state, active_schedule)'}
    used=set()
    for block in ast.walk(tree):
        if not isinstance(block, ast.Try):
            continue
        for i,node in enumerate(block.body):
            if isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name):
                var=node.targets[0].id
                if var in replacements:
                    block.body[i]=ast.parse(replacements[var]).body[0]
                    used.add(var)
    assert used==set(replacements)
    ns=dict(vars(previous),dispatch=dispatch,score_row=score_row)
    exec(compile(ast.fix_missing_locations(tree),str(previous.HERE/'search_opened.py'),'exec'),ns)
    return ns,ns['simulate']

NS, SIMULATE = archive_adapter()

def run(track,seed,scale=1.,material='original',actions=(),trace=None,fork=None):
    ACTIVE.update(track=track,seed=seed,scale=scale,material=material)
    NS['SEED']=seed
    original=previous.base_walk
    NS['base_walk']=(original if scale==1 else lambda walk,d,speed:original(walk,d,speed*scale))
    try:return SIMULATE(actions, fork=fork, savepath=trace)
    finally:previous.course.loc.Locomotion.control=original

def task(args):
    return run(*args)

def save(name, data):
    previous.save(HERE/name,data)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('mode',choices=('transfer','mine','replay'))
    ap.add_argument('--count',type=int,default=1536);ap.add_argument('--start',type=int,default=14550000)
    ap.add_argument('--workers',type=int,default=7);ap.add_argument('--track',default='incline')
    a=ap.parse_args()
    if a.mode=='transfer':
        tasks=[(track,SEED,scale,mat,TEACHER if use else []) for track in ('flat','combined','incline')
               for mat in ('original','mild_soft') for use in (False,True) for scale in (.70,.85,1.,1.15,1.30)]
    elif a.mode=='mine':
        tasks=[(a.track,s,1.,'original',[]) for s in range(a.start,a.start+a.count)]
    else:
        record=previous.read(HERE/(a.track+'-selected.json'))
        res=run(a.track,record['seed'],record['scale'],record['material'],record['actions'],trace=HERE/(a.track+'-development.npz'))
        print(res);return
    with ProcessPoolExecutor(a.workers) as pool:
        rows=list(pool.map(task,tasks,chunksize=4))
    for i,r in enumerate(rows):r['teacher']=bool(tasks[i][-1])
    name='historic-transfer.json' if a.mode=='transfer' else f'{a.track}-mine-{a.start}.json'
    save(name,rows)
    for track in sorted({r['track'] for r in rows}):
        sub=sorted((r for r in rows if r['track']==track),key=lambda r:r['last_both_m'],reverse=True)
        print(track,len(sub),[(r['seed'],r['material'],r['teacher'],r['scale'],r['last_both_m'],r['reason']) for r in sub[:4]],flush=True)

if __name__=='__main__':main()
