"""Local normal compliance sensitivity for a geometrically flat MuJoCo paddle."""
import numpy as np

MODES = ('original', 'mild_soft')


def configure_surface(model, mode='original'):
    """Call on a private compiled model before running its first physical step.

    Sphere–face solref contact time is 6 ms or 7 ms. The default dynamic
    collision mixes the two geometries equally. Ball–ball contacts keep 6 ms.
    Sphere–face friction continues to come from the scored randomization.
    """
    if mode not in MODES:
        raise ValueError(f'Unknown flat surface {mode!r}')
    face = model.geom('paddle_face').id
    balls = [model.geom(name).id for name in ('ball_geom', 'ball_geom_b')]
    for ball in balls:
        assert model.geom_priority[face] == model.geom_priority[ball]
        assert model.geom_solmix[face] == model.geom_solmix[ball] > 0
        assert np.allclose(model.geom_solref[ball], [.006, .68])
    assert model.geom_solref[face, 1] == .68
    model.geom_solref[face, 0] = .006 if mode == 'original' else .008
