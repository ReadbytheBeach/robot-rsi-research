"""Diverse receding-horizon shooting on the physical 2.5 m connected course."""
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
from unittest.mock import patch
import argparse
import json
import multiprocessing as mp
import sys

import numpy as np

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'replay'))
import transfer as engine
import fixed_ground

SEED=12600381

def dump(p, x):
    p=Path(p);tmp=p.with_suffix('.pending');tmp.write_text(json.dumps(x,indent=2)+'\n');tmp.replace(p)


def read(p):return json.loads(Path(p).read_text())


def simulate(actions, fork=None, trace=None):
    probes={}; last={}
    original=fixed_ground.Meter.observe
    scorer=engine.score_row
    def observe(meter,t,distance,fail,on,audit,bc):
        original(meter,t,distance,fail,on,audit,bc)
        if not (meter.valid and on):return
        tix=round(50*t)
        last.update(t=t,progress_m=distance,world_x_m=meter.origin+distance,
                    safe_slope_m=float(np.clip(meter.origin+distance-fixed_ground.START,0,1)),
                    radii_mm=(1000*np.asarray(bc.last_radii)).tolist(),both_face=bool(on))
        if tix%5 or t<3.:return
        a,b=bc.channels; m,d=a.m,a.d
        R=d.site_xmat[a.site].reshape(3,3)
        p=np.array([R.T@(d.qpos[c.adr:c.adr+3]-d.site_xpos[a.site]) for c in (a,b)])[:,:2]
        omega=a.spatial[:3]; vv=[]
        for ch in (a,b):
            live_arm=d.qpos[ch.adr:ch.adr+3]-d.site_xpos[a.site]
            vv.append((R.T@(d.qvel[ch.dof:ch.dof+3]-a.spatial[3:]-np.cross(omega,live_arm)))[:2])
        v=np.array(vv);sep=p[1]-p[0];gap=np.linalg.norm(sep);delta=v[1]-v[0]
        probes[str(tix)]=[round(float(x),6) for x in (distance,np.linalg.norm(p,axis=1).max(),gap,sep@delta/max(.001,gap),
                              np.linalg.norm(p.mean(0)),np.linalg.norm(v.mean(0)),np.linalg.norm(p+.23*v,axis=1).max(),
                              np.degrees(np.arccos(np.clip(d.xmat[a.rootbody,8],-1.,1.))),*sep, *delta)]
    def decorated(r,s,a):return dict(scorer(r,s,a),probes=probes,last=last)
    with patch.object(fixed_ground.Meter,'observe',observe),patch.dict(engine.NS,{'score_row':decorated}):
        return engine.run('fixed',SEED,1.,'original',actions,trace=trace,fork=fork)


def work(payload):
    schedule,req=payload
    return simulate(schedule,req)


def sample_bank(layer, slot, restart=0):
    rng=np.random.default_rng(134724+layer*917+slot*139+restart*104449)
    template=dict(pitch=0.,roll=0.,neck=0.,hip=0.,lateral=0.,yaw=0.,damp=0.,span=0.,speed=0.,duration=.32)
    actions=[None]
    for i in range(13 if restart==2 else 19):
        a=template.copy();fine=float(rng.choice([.30,.55,1.]))
        a['duration']=float(rng.choice([.14,.24,.38,.54,.72,1.02,1.36]))
        if i<4:
            a['speed']=(-1)**i*float(rng.uniform(.05,.30));a['damp']=float(rng.uniform(-.22,.45));a['neck']=float(rng.uniform(-.045,.045))
        elif i<10:
            a.update(style='opening' if i%2 else 'intercept',direction=float(rng.uniform(-.18,.18)),tangent=float(rng.uniform(-.14,.14)),relative=float(rng.uniform(-.9,1.)),memory=float(rng.uniform(-.6,.9)),yawphase=float(rng.uniform(-.15,.15)),neckphase=float(rng.uniform(-.07,.07)),frequency=0. if i%3 else 2.)
        elif i<15:
            for key,mag in [('pitch',.12),('roll',.12),('yaw',.16),('speed',.31),('span',.14),('hip',.045)]:a[key]=float(rng.uniform(-mag,mag))
        else:
            a['span']=float(rng.uniform(-.24,.24));a['yaw']=float(rng.uniform(-.21,.21));a['damp']=float(rng.uniform(-.32,.90));a['roll']=float(rng.uniform(-.06,.06))
        for key in ['pitch','roll','yaw','speed','span','hip','neck']:a[key]*=fine
        if restart==2:
            # A sustained change in head yaw is one physical way to reorient the plate.
            # The simulator's random impulse sequence is never read or altered by the controller.
            if i < 14:
                a['yaw']=float(rng.choice([-1,1])*rng.uniform(.16,.72))
                a['duration']=float(rng.choice([.42,.72,1.05,1.40,1.75]))
                a['damp']=float(rng.uniform(.05,1.10));a['span']=float(rng.uniform(-.12,.12))
                a['neck']=float(rng.uniform(-.065,.065));a['hip']*=.35
            else:
                a['yaw']=float(rng.uniform(-.14,.14));a['damp']=float(rng.uniform(.2,1.3))
        actions.append(a)
    return actions


def quality(row, at, kind):
    # Predetermined offline physical probes. Values never enter the controller.
    f=row['probes'].get(str(at))
    if f is None:return -1e4+row['seconds']
    x,r,gap,radial,center,drift,projected,tilt=f[:8]
    if kind=='collision':
        return -abs(gap-.024)-.42*max(0.,radial+.015)-.33*r-.23*abs(f[10])-.001*max(0.,tilt-13)
    if kind=='separation':return -gap-.60*max(-.02,radial)-.35*projected-.001*max(0.,tilt-15)
    if kind=='center':return -.65*r-.43*projected-.3*center-.08*drift-.003*max(0.,tilt-12)
    if kind=='interior':return -.75*r-.65*max(0.,radial)-.3*gap+.15*min(.22,x)-.0008*tilt
    raise ValueError(kind)


def select(records, at):
    eligible=[r for r in records if r['max_tilt_deg']<29 and str(at) in r['probes']]
    if not eligible:return []
    final_key=lambda r:(r['finish_2p5'],r['slope_1m'],r['last_both_m'])
    keep=[max(eligible,key=final_key)]
    def signature(r):
        p=np.array(r['probes'][str(at)])
        return np.array([p[1]/.006,p[2]/.009,p[3]/.025,p[4]/.009,p[6]/.012,p[8]/.012,p[9]/.012])
    for kind in ('collision','center','separation','interior'):
        ordered=sorted(eligible,key=lambda r:quality(r,at,kind),reverse=True)
        distinct=[r for r in ordered if min(np.linalg.norm(signature(r)-signature(a)) for a in keep)>.65]
        if distinct:keep.append(distinct[0])
        else:
            pick=next((r for r in ordered if all(not(np.allclose(signature(r),signature(a),atol=.02)) for a in keep)),None)
            if pick:keep.append(pick)
    return keep


def summary(row):return {k:v for k,v in row.items() if k!='probes'}

def train(variant):
    output=HERE/variant;output.mkdir(exist_ok=True)
    best_path=HERE.parent/'replay/fixed-selected.json'
    if variant=='yaw_approach' and (HERE/'uphill/selected.json').exists():
        best_path=HERE/'uphill/selected.json'
    initial=read(best_path)['actions'] if best_path.exists() else engine.TEACHER
    if (output/'starting-actions.json').exists():initial=read(output/'starting-actions.json')
    else:dump(output/'starting-actions.json',initial)
    base=simulate(initial);base['actions']=initial; best=base
    # Two independent paths approach the two previous high-risk contact windows.
    settings={'uphill':(330,32,0), 'intersect':(175,39,1), 'yaw_approach':(426,48,2)}
    first,spacing,restart=settings[variant];progress=[];beam=[base]*5
    level=0; misses=0; best_gate=0; candidate_count=0
    with ProcessPoolExecutor(5,mp_context=mp.get_context('fork')) as pool:
        while level<30:
            at0=first+spacing*level
            if at0>round(50*best['seconds'])-4:break
            folder=output/f'{level:02d}';folder.mkdir(exist_ok=True)
            sub=[];series=[]
            for slot,b in enumerate(beam):
                if level==0:
                    at=at0+[-26,-10,0,12,20][slot]
                else:
                    at=max(10,at0+[-12,-5,0,5,8][slot])
                at=min(at,round(b['seconds']*50)-5)
                if at<=2:continue
                # Feedback segments from the previous seed remain available as an expert prior.
                # Split alternate hypotheses in the last stages between retaining and dropping future expert pulses.
                schedule=list(b['actions'])
                if level>2 and slot==4:
                    schedule=[a for a in schedule if a['tick']<=at]
                bank=sample_bank(level,slot,restart);series.append((schedule,bank,at,slot))
                for i in range(2):
                    sub.append((schedule,dict(tick=at,slot=slot,folder=folder,members=[(j,v) for j,v in enumerate(bank) if j%2==i])))
            list(pool.map(work,sub));candidates=[*beam,best]
            for sched,bank,at,slot in series:
                rows=[]
                for i,action in enumerate(bank):
                    r=read(folder/f'{slot}-{i:02d}.json');r['actions']=sched+([dict(tick=at,**action)] if action else []);rows.append(r)
                assert len({r['fork_sha'] for r in rows})==1
                candidates.extend(rows)
            candidate_count+=sum(len(a) for _,a,_,_ in series)
            key=lambda r:(r['finish_2p5'],r['slope_1m'],r['last_both_m'] if r['max_tilt_deg']<29 else 0.)
            best=max(candidates,key=key)
            attempt=5*round((at0+spacing+5)/5)
            beam=select(candidates,attempt)
            if not beam:
                # A later probe cannot be populated yet. Use latest common valid probe at a preceding time.
                latest=max((int(k) for r in candidates for k in r['probes']),default=0)
                attempt=5*int(min(attempt,latest)/5);beam=select(candidates,attempt)
            if not beam:break
            progress.append(dict(layer=level,probe_s=attempt/50,different_prefixes=len(beam),selected_m=[round(v['last_both_m'],5) for v in beam],best_m=best['last_both_m'],best_s=best['seconds'],trials=candidate_count))
            dump(output/'progress.json',progress);dump(output/'selected.json',summary(best));print(variant,progress[-1],flush=True)
            if best['finish_2p5']:break
            level+=1
    final=simulate(best['actions'],trace=output/'best.npz')
    assert final['last_both_m']==best['last_both_m'] and final['reason']==best['reason']
    dump(output/'result.json',dict(seed=SEED,source='one opened development release; fixed unshifted floor',initial=summary(base),final=summary(final),actions=best['actions'],layers=progress,candidates=candidate_count))


if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('variant',choices=('uphill','intersect','yaw_approach'));train(a.parse_args().variant)
