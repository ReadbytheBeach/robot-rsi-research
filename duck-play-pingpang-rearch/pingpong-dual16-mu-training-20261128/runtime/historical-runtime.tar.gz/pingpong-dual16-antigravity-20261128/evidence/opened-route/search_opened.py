"""Beam-search local actions on one previously opened full-route start; unchanged scorer and physics."""
import argparse,csv,hashlib,json,multiprocessing,os,sys
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
import numpy as np
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT))
import trials16
from extend_route import check
F=trials16.FROZEN
sys.path.insert(0,str(F))
import ball,course
from trials16 import read,save
SEED=12600381
spec=read(ROOT/'sealed/extension/candidate.json')
mod=trials16.load_source(ROOT/spec['source']);mod.install(spec['settings'])
base_control=ball.BallChannel.control
base_walk=course.loc.Locomotion.control
DT=.02
JOINTS=('left_hip_pitch','right_hip_pitch','left_ankle','right_ankle','neck_pitch','head_yaw','left_hip_roll','right_hip_roll')
def digest(data):
    h=hashlib.sha256()
    for z in [data.qpos,data.qvel,data.ctrl,data.qacc_warmstart]:h.update(z.tobytes())
    return h.hexdigest()
def make_bank(layer,slot):
    rng=np.random.default_rng(298369+layer*989+slot*17)
    out=[]
    for i in range(16):
        # pitch, roll, common camera damping, cautious speed multiplier, neck, symmetric hip, lateral hip, yaw, and differential directed tilt
        if i==0:
            out.append(None);continue
        v=np.zeros(10)
        v[-1]=rng.choice([.10,.22,.34,.52,.80,1.1])
        if i<5:
            v[(i-1)//2]=(-1 if i%2 else 1)*rng.uniform(.035,.15)
            v[2]=rng.uniform(-.2,.6);v[3]=rng.uniform(-.14,.16)
        elif i<8:
            v[2]=rng.uniform(-.40,1.10);v[3]=rng.uniform(-.45,.28)
            v[4]=rng.uniform(-.075,.075);v[5]=rng.uniform(-.07,.07)
        elif i<11:
            v[8]=rng.uniform(-.22,.22);v[7]=rng.uniform(-.27,.27);v[4]=rng.uniform(-.12,.12);v[3]=rng.uniform(-.20,.22)
        else:
            v[:9]=rng.uniform(-1,1,9)*[.12,.13,.8,.34,.13,.095,.09,.18,.12]
        out.append({k:round(float(z),6) for k,z in zip(['pitch','roll','damp','speed','neck','hip','lateral','yaw','span','duration'],v)})
    return out
def simulate(schedule,fork=None,savepath=None):
    active_schedule=list(schedule);current=[0];joint_ids=None
    selected=[None];max_station=[0.];first_meter=[None]
    earliest_after=None
    original_pace=course.Pace.observe;original_init=course.Pace.__init__;meters=[]
    state=None;current_channel=[None];upright=[True,0.,0.]
    from collections import deque
    observations=deque(maxlen=12);peer=[None]
    original_reset=ball.BallController.reset
    def reset_pair(self,*args,**kwargs):
        r=original_reset(self,*args,**kwargs);peer[0]=self.channels[1];return r
    def init_meter(self,*args,**kwargs):
        original_init(self,*args,**kwargs);meters.append(self)
    def observe(self,t,p):
        if self is meters[0]:
            max_station[0]=max(max_station[0],p)
            ch=current_channel[0]
            if ch is not None and ch.d.xmat[ch.rootbody,8]<.906307787:upright[0]=False
            if upright[0]:upright[1]=max(upright[1],p);upright[2]=t
            if p>=1. and first_meter[0] is None:first_meter[0]=t
        return original_pace(self,t,p)
    def multiplier(t):
        factor=1.
        for a in active_schedule:
            elapsed=(t-a['tick'])*DT
            if 0<elapsed<a['duration']:
                factor+=a.get('speed',0.)*min(1.,(elapsed+.02)/.06,(a['duration']-elapsed+.02)/.06)
        return min(1.50,max(.45,factor))
    def walk(self,d,speed):
        return base_walk(self,d,speed*multiplier(current[0]+1))
    def correction(ch,estimate=None):
        nonlocal joint_ids,state
        if not ch.actor:return base_control(ch,estimate)
        t=ch.tick;current[0]=t;current_channel[0]=ch
        if fork and t==fork['tick'] and selected[0] is None:
            state=digest(ch.d)
            for idx,action in fork['members']:
                child=os.fork()
                if child==0:
                    selected[0]=idx
                    if action is not None:active_schedule.append({'tick':t,**action})
                    break
                _,status=os.waitpid(child,0)
                if status:raise RuntimeError((idx,status))
            if selected[0] is None:raise BranchComplete()
        if joint_ids is None:joint_ids=np.array([ch.m.actuator(n).id for n in JOINTS])
        z=ch.measurements[0]
        other=peer[0].measurements[0];both=.5*(z+other);observations.append(both.copy())
        bias=np.zeros(2);j=np.zeros(8)
        for a in active_schedule:
            elapsed=(t-a['tick'])*DT
            if not (0<=elapsed<a['duration']):continue
            smooth=min(1.,(elapsed+.02)/.06,(a['duration']-elapsed+.02)/.06)
            # estimate is the delivered, filtered average sent by the original dual controller.
            mm=z[:2] if estimate is None else estimate[:2]
            vv=z[2:] if estimate is None else estimate[2:]
            axis=z[:2]-mm;axis=axis/max(.008,np.linalg.norm(axis))
            b=np.array([a['pitch'],a['roll']])-a['damp']*(vv+2.7*mm)+a['span']*axis
            if a.get('style'):
                sep=other[:2]-z[:2];dv=other[2:]-z[2:];sep_norm=max(.008,np.linalg.norm(sep))
                er=sep/sep_norm;et=np.array([-er[1],er[0]])
                rv=dv@er;tv=dv@et
                meanv=np.mean(np.array(observations)[:,2:],axis=0)
                direction=a['direction']*er+a['tangent']*et
                phase=2*np.pi*a.get('frequency',0.)*elapsed
                wave=np.cos(phase) if a.get('frequency',0.) else 1.
                envelope=1.
                if a['style']=='opening':envelope=float(np.clip(.45+rv/.07,0.,1.))
                if a['style']=='intercept':envelope=float(np.clip(.50-rv/.07,0.,1.))
                if a['style']=='gait':
                    m,d=ch.m,ch.d
                    l=d.geom_xpos[m.geom('left_foot_collision').id,2];r=d.geom_xpos[m.geom('right_foot_collision').id,2]
                    wave*=np.tanh((l-r)/.006)
                b+=envelope*(wave*direction-a['memory']*meanv-a['relative']*tv*et)
                j[5]+=smooth*envelope*wave*a['yawphase']
                j[4]+=smooth*envelope*wave*a['neckphase']
            bias+=smooth*b
            j+=smooth*np.array([a['hip'],-a['hip'],.52*a['hip'],-.52*a['hip'],a['neck'],a['yaw'],a['lateral'],a['lateral']])
        if np.any(bias):ch.plate_bias=np.clip(ch.plate_bias+bias,-.28,.28)
        if np.any(j):
            ids=ch.m.actuator_trnid[joint_ids,0]
            ch.d.ctrl[joint_ids]=np.clip(ch.d.ctrl[joint_ids]+j,ch.m.jnt_range[ids,0],ch.m.jnt_range[ids,1])
        return base_control(ch,estimate)
    course.Pace.observe=observe;course.Pace.__init__=init_meter;ball.BallController.reset=reset_pair;ball.BallChannel.control=correction;course.loc.Locomotion.control=walk
    try:
        r=course.run('route',SEED,spec['params'],trace=savepath,timeout=150.)
        result=dict(seed=SEED,schedule=active_schedule,seconds=r['seconds'],peak=float(max_station[0]),distance=r['distance_m'],success=r['success'],reason=r['reason'],first_meter_s=first_meter[0],torque_nm=max(r['motor']['peak_nm']),fork_sha=state,contacts=r['terminal_contacts'],upright_station=float(upright[1]),upright_s=float(upright[2]),separation_at_loss_m=r['separation_at_loss_m'],max_tilt_deg=r['max_tilt_deg'])
    except BranchComplete:return
    finally:
        course.Pace.observe=original_pace;course.Pace.__init__=original_init;ball.BallController.reset=original_reset;ball.BallChannel.control=base_control;course.loc.Locomotion.control=base_walk
    if fork:
        if selected[0] is None:raise RuntimeError(f'fork missed: {fork["tick"]}, {r["seconds"]}')
        save(fork['folder']/f'{fork["slot"]}-{selected[0]:02}.json',result)
        os._exit(0)
    return result
class BranchComplete(Exception):pass
def worker(args):
    schedule,fork=args
    simulate(schedule,fork)
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--levels',type=int,default=30);a=ap.parse_args()
    check(); (HERE/'layers').mkdir(exist_ok=True)
    ref=simulate([]);assert ref['seconds']==7.70 and abs(ref['peak']-.7320514891708858)<1e-13
    pool_item=[ref]*3;best=ref;nogain=0;hist=[]
    for layer in range(a.levels):
        stage=HERE/'layers'/f'{layer:02}';stage.mkdir(exist_ok=True)
        jobs=[]
        for slot,prefix in enumerate(pool_item):
            if layer==0:fork_s=(2.16,4.42,6.74)[slot]
            else:
                last=prefix['schedule'][-1]['tick']*DT if prefix['schedule'] else 0.
                back=([.25,1.05,2.80] if nogain==0 else [.57,1.66,4.15])[slot]
                fork_s=max(last+.08,prefix['seconds']-back)
                fork_s=np.clip(fork_s,.08,prefix['seconds']-.08)
            at=round(fork_s/DT);bank=make_bank(layer,slot)
            for k in range(4):
                jobs.append((prefix['schedule'],{'tick':at,'slot':slot,'folder':stage,'members':[(i,v) for i,v in enumerate(bank) if i%4==k]}))
        with ProcessPoolExecutor(9,mp_context=multiprocessing.get_context('fork')) as pool:list(pool.map(worker,jobs))
        vals=[read(p) for p in sorted(stage.glob('*.json'))]
        assert len(vals)==48
        for slot,old in enumerate(pool_item):
            controls=read(stage/f'{slot}-00.json')
            assert abs(controls['peak']-old['peak'])<1e-10
            assert len({read(p)['fork_sha'] for p in stage.glob(f'{slot}-*.json')})==1
        ranked=sorted([best,*vals],key=lambda x:(x['success'],x['peak'],x['seconds']),reverse=True)
        prev=best;best=ranked[0];gain=best['peak']-prev['peak'];nogain=0 if gain>.001 else nogain+1
        pool_item=[];keys=set()
        for cand in ranked:
            key=(round(cand['peak'],4),round(cand['seconds'],2))
            if key in keys:continue
            pool_item.append(cand);keys.add(key)
            if len(pool_item)==3:break
        assert len(pool_item)==3
        hist.append(dict(layer=layer,n=48,gain=gain,best_m=best['peak'],best_s=best['seconds'],passed_1m=best['first_meter_s'],top_m=[v['peak'] for v in pool_item]))
        save(HERE/'interim.json',dict(baseline=ref,best=best,history=hist))
        print(hist[-1],flush=True)
        if best['success'] or nogain>=2:break
    save(HERE/'selected-actions.json',dict(seed=SEED,source='sealed/extension/candidate.json',frozen_spec_sha256=trials16.hash_file(ROOT/'sealed/extension/candidate.json'),actions=best['schedule']))
    replay=simulate(best['schedule'],savepath=HERE/'best.npz')
    assert replay['seconds']==best['seconds'] and replay['peak']==best['peak'] and replay['reason']==best['reason']
    save(HERE/'result.json',dict(baseline=ref,best=replay,history=hist,branches=48*len(hist),stop='complete' if best['success'] else ('two_layers_under_1mm' if nogain>=2 else 'budget')))
if __name__=='__main__':main()
