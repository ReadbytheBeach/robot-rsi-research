"""Run the upstream pure paired-scorecard code on MicroDuck episode records."""
import ast
from collections.abc import Sequence
import csv,dataclasses,hashlib,math,sys,types
from pathlib import Path
from scipy.stats import beta,binomtest
from trials16 import ROOT,ORIG,read,save

UP=ROOT/'upstream/robosim_gauntlet'
BLOBS={'scorecard.py':'f8398d40a8dbe08b9d6f709b21b6a5aea092f817','grade.py':'68975bc0821085a70ae1360eea90af5b815bc8f3'}
def upstream_tree(name):
    data=(UP/name).read_bytes()
    assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==BLOBS[name]
    return ast.parse(data)

def load_comparator():
    # Use precisely the original executable syntax trees. The hardware/REAF
    # runner dependencies are unnecessary for these pure offline scorecard functions.
    grade=next(n for n in upstream_tree('grade.py').body
               if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='CATASTROPHIC')
    nodes=[grade]+[n for n in upstream_tree('scorecard.py').body if getattr(n,'name',None) in ('Comparison','_tail','compare')]
    ns={'dataclasses':dataclasses,'math':math,'Sequence':Sequence,'episode':types.SimpleNamespace(EpisodeResult=object),'__name__':__name__}
    exec(compile(ast.Module(body=nodes,type_ignores=[]),str(UP/'scorecard.py'),'exec'),ns)
    ns['grade_lib']=types.SimpleNamespace(CATASTROPHIC=ns['CATASTROPHIC'])
    return ns['compare']
def data(p):
    with Path(p).open() as f:return list(csv.DictReader(f))
def make_result(r,scene,mode):
    ok=r['success']=='True'
    why=r['reason']
    violations=() if ok else (('dropped',) if why.startswith(('ball_edge','ball_below','ball_air')) else (why,))
    grade=types.SimpleNamespace(safe_pass=ok,violations=violations)
    return types.SimpleNamespace(key=('microduck_'+mode,'original',int(r['seed']),int(r['seed'])),scene_sha256=scene,grade=grade)
def interval(k,n):
    return [float(beta.ppf(.025,k,n-k+1)) if k else 0.,float(beta.ppf(.975,k+1,n-k)) if k<n else 1.]
def comparison(a_path,b_path,mode):
    a=data(a_path);b=data(b_path)
    assert len(a)==len(b) and [r['seed'] for r in a]==[r['seed'] for r in b]
    ref=read(ORIG/'frozen'/('double16-'+mode)/'manifest.json')
    import json
    # Robot and contact model, original course geometry, motor cap and payload settings.
    scene=hashlib.sha256(json.dumps({'external':ref['external'],'ball':ref['files']['ball.py'],
       'terrain':ref['files']['path_geom.py'],'course':ref['files']['course.py'],'mode':mode,'mm':16,'count':2,'paddle_g':40},sort_keys=True).encode()).hexdigest()
    compare=load_comparator()
    raw=compare([make_result(r,scene,mode) for r in a],[make_result(r,scene,mode) for r in b])
    ka=sum(r['success']=='True' for r in a);kb=sum(r['success']=='True' for r in b)
    res=dict(gauntlet=dataclasses.asdict(raw),baseline=ka,candidate=kb,n=len(a),
        baseline_exact95=interval(ka,len(a)),candidate_exact95=interval(kb,len(b)),scene_sha256=scene,
        paired_two_sided_p=float(binomtest(raw.b_only,raw.a_only+raw.b_only,.5).pvalue) if raw.a_only+raw.b_only else 1.,
        gained=[int(y['seed']) for x,y in zip(a,b) if x['success']=='False' and y['success']=='True'],
        lost=[int(y['seed']) for x,y in zip(a,b) if x['success']=='True' and y['success']=='False'])
    return res
if __name__=='__main__':
    import argparse
    cli=argparse.ArgumentParser();cli.add_argument('mode');cli.add_argument('baseline',type=Path);cli.add_argument('candidate',type=Path);cli.add_argument('output',type=Path)
    args=cli.parse_args()
    save(args.output,comparison(args.baseline,args.candidate,args.mode))
