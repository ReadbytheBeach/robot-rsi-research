"""Verify reference plant and controller snapshots and freeze this experiment's independent evaluations."""
import json,sys,shutil
from pathlib import Path
from trials16 import ROOT,ORIG,FROZEN,read,save,hash_file


def audit_reference():
    record=read(FROZEN/'manifest.json')
    for name,h in record['external'].items():
        if hash_file(name)!=h:raise ValueError(name)
    for name,h in record['files'].items():
        if hash_file(FROZEN/name)!=h:raise ValueError(name)
    return dict(original_frozen=hash_file(FROZEN/'manifest.json'),original_route_frozen=hash_file(ORIG/'frozen/double16-route/manifest.json'),external_files=len(record['external']),implementation_files=len(record['files']))


def lock(mode,chosen):
    from datetime import datetime
    from zoneinfo import ZoneInfo
    folder=ROOT/'sealed'/mode
    if folder.exists():raise FileExistsError(folder)
    folder.mkdir(parents=True)
    spec=read(chosen)
    copied={}
    if 'source' in spec:
        source=ROOT/spec['source']
        # A controller may import siblings. Ship its controller modules, preserving source hashes.
        for s in sorted(source.parent.glob('*.py')):
            shutil.copyfile(s,folder/s.name)
            copied[s.name]=hash_file(s)
        spec['source']=str((folder/source.name).relative_to(ROOT))
    save(folder/'candidate.json',spec)
    save(folder/'baseline.json',{})
    info=audit_reference()
    info.update(time=datetime.now(ZoneInfo('Asia/Singapore')).isoformat(),mode=mode,selected_from=str(chosen),controller_hashes=copied,
                scorer=hash_file(ROOT/'gauntlet_result.py'),evaluator=hash_file(ROOT/'trials16.py'),
                protocol=hash_file(ROOT/'protocol.json'),selected_spec=hash_file(folder/'candidate.json'),
                seeds=read(ROOT/'protocol.json')['holdout'][mode])
    save(folder/'manifest.json',info)
    return info


def verify(mode):
    folder=ROOT/'sealed'/mode;v=read(folder/'manifest.json')
    for key,h in [('evaluator',ROOT/'trials16.py'),('scorer',ROOT/'gauntlet_result.py'),('protocol',ROOT/'protocol.json'),('selected_spec',folder/'candidate.json')]:
        assert v[key]==hash_file(h),h
    for name,h in v['controller_hashes'].items():assert hash_file(folder/name)==h,name
    assert all(v[k]==x for k,x in audit_reference().items())
    return v

if __name__=='__main__':
    if sys.argv[1]=='lock':print(lock(sys.argv[2],sys.argv[3]))
    elif sys.argv[1]=='verify':print(verify(sys.argv[2]))
    else:print(audit_reference())
