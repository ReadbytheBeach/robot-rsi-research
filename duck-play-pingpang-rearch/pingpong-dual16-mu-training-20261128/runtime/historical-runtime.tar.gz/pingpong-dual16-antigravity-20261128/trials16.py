"""One reusable evaluator for independent arms with identical seeds and physics."""
import argparse,csv,hashlib,importlib.util,json,os,sys
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
import numpy as np

ROOT=Path(__file__).resolve().parent
ORIG=ROOT.parent/'pingpong-turn-pit-20261128'
FROZEN=ORIG/'frozen'/'double16-stand'
FIELDS='seed success seconds reason distance_m max_separation_m separation_at_loss_m radius_max_mm max_tilt_deg observation_delay_ms command_delay_ms pushes peak_station_m max_xy_displacement_m pit_crossed pace_ok stable_finish_s peak_motor_nm'.split()
def read(p):return json.loads(Path(p).read_text())
def save(p,v):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n');tmp.replace(p)
def hash_file(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load_source(source):
    spec=importlib.util.spec_from_file_location('active_controller',source)
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    return mod
def init(spec,mode):
    global _params,_run,_mode
    sys.path.insert(0,str(FROZEN))
    from course import run, Pace
    global _progress_record, _pace_count
    _progress_record=[0.];_pace_count=[0]
    pace_init, pace_update=Pace.__init__,Pace.observe
    def initialize_meter(pace,*args,**kwargs):
        pace_init(pace,*args,**kwargs)
        pace._route_station_meter=_pace_count[0]==0
        _pace_count[0]+=1
    def measure(pace,t,progress):
        if pace._route_station_meter:_progress_record[0]=max(_progress_record[0],float(progress))
        return pace_update(pace,t,progress)
    Pace.__init__,Pace.observe=initialize_meter,measure
    _run=run;_mode=mode
    source=spec.get('source')
    _params=read(ORIG/'frozen'/('double16-'+mode)/'selected.json')
    if 'params' in spec:
        _params=spec['params']
    if source:
        mod=load_source(ROOT/source)
        mod.install(spec.get('settings',{}))
def run_job(seed):
    _pace_count[0]=0;_progress_record[0]=0.
    r=_run(_mode,seed,_params,timeout=150.)
    r['peak_station_m']=_progress_record[0];r['peak_motor_nm']=max(r['motor']['peak_nm'])
    return {k:r.get(k) for k in FIELDS}
def evaluate(spec,mode,seeds,workers=8):
    with ProcessPoolExecutor(workers,initializer=init,initargs=(spec,mode)) as pool:
        return list(pool.map(run_job,seeds,chunksize=5))
def write_rows(p,rows):
    p=Path(p);p.parent.mkdir(exist_ok=True,parents=True)
    with p.open('w') as f:
        w=csv.DictWriter(f,fieldnames=FIELDS);w.writeheader();w.writerows(rows)
def stats(rows):
    t=np.array([r['seconds'] for r in rows]);k=sum(r['success'] for r in rows)
    return dict(n=len(rows),complete=int(k),mean_s=float(t.mean()),median_s=float(np.median(t)),p95_s=float(np.percentile(t,95)),max_s=float(t.max()),max_m=max(r['distance_m'] for r in rows),at_least_5s=sum(t>=5).item(),at_least_8s=sum(t>=8).item())
if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('mode');a.add_argument('start',type=int);a.add_argument('n',type=int);a.add_argument('out',type=Path);a.add_argument('--workers',type=int,default=8);a.add_argument('--spec',type=Path)
    a=a.parse_args();r=evaluate(read(a.spec) if a.spec else {},a.mode,range(a.start,a.start+a.n),a.workers)
    write_rows(a.out.with_suffix('.csv'),r);save(a.out.with_suffix('.json'),stats(r));print(stats(r))
