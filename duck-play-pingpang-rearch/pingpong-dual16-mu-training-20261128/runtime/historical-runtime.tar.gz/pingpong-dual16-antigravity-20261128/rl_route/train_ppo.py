"""PPO with a tanh-Gaussian actor, learned critic and generalized advantage estimates."""
from concurrent.futures import ProcessPoolExecutor
import json,time,sys
import numpy as np
from runner import HERE,BASE,save,simulation,evaluate_group,brief_stats,actor
import torch
from torch import nn
torch.set_num_threads(1);torch.set_num_interop_threads(1)
N=64;UPDATES=28;H=24;GAMMA=.985;LAMBDA=.94;EPS=.18
def to_numpy(net,logstd):
    return dict(w1=net[0].weight.detach().numpy().copy(),b1=net[0].bias.detach().numpy().copy(),
                w2=net[2].weight.detach().numpy().copy(),b2=net[2].bias.detach().numpy().copy(),logstd=logstd.detach().numpy().copy())
def save_net(w,idx):
    np.savez_compressed(HERE/f'actor-{idx:02d}.npz',**w)
def batch_adv(episodes,vnet):
    X=np.concatenate([z[1][0] for z in episodes])
    with torch.no_grad():values=vnet(torch.tensor(X)).numpy()[:,0]
    indices=0;advantages=[];returns=[]
    for _,(obs,actions,lp,rewards) in episodes:
        v=values[indices:indices+len(obs)];indices+=len(obs)
        adv=np.empty_like(v);carry=0.;following=0.
        for i in range(len(v)-1,-1,-1):
            carry=rewards[i]+GAMMA*following-v[i]+GAMMA*LAMBDA*carry
            adv[i]=carry;following=v[i]
        returns.append(adv+v);advantages.append(adv)
    adv=np.concatenate(advantages);adv=(adv-adv.mean())/(adv.std()+1e-6)
    return tuple(torch.tensor(x,dtype=torch.float32) for x in (X,np.concatenate([z[1][1] for z in episodes]),np.concatenate([z[1][2] for z in episodes]),adv,np.concatenate(returns)))
def choose_key(stats):return (stats['completed'],stats['m1'],stats['p90_m'],stats['mean_m'])
def main():
    torch.manual_seed(60612);gen=np.random.default_rng(77128)
    pi=nn.Sequential(nn.Linear(actor.OBS,H),nn.Tanh(),nn.Linear(H,actor.ACT))
    vf=nn.Sequential(nn.Linear(actor.OBS,32),nn.Tanh(),nn.Linear(32,1))
    with torch.no_grad():pi[2].weight.zero_();pi[2].bias.zero_()
    ls=nn.Parameter(torch.full((actor.ACT,),-.49))
    optim=torch.optim.Adam([{'params':list(pi.parameters())+[ls],'lr':.0007},{'params':vf.parameters(),'lr':.0016}])
    history=[];all_training=[];saveds={}
    w=to_numpy(pi,ls);save_net(w,0);saveds[0]=w
    with ProcessPoolExecutor(7) as pool:
        for it in range(UPDATES):
            jobs=[(w,12700000+it*N+i,876031492+it*101+i,None) for i in range(N)]
            episodes=list(pool.map(simulation,jobs,chunksize=3));scores=[r for r,_ in episodes];all_training.extend(scores)
            X,A,old,adv,targets=batch_adv(episodes,vf)
            clipcounts=[];kls=[];losses=[]
            for epoch in range(4):
                perm=gen.permutation(len(X))
                for start in range(0,len(X),128):
                    j=perm[start:start+128];dist=torch.distributions.Normal(pi(X[j]),ls.exp())
                    logp=dist.log_prob(A[j]).sum(1);ratio=(logp-old[j]).exp()
                    gain=torch.min(ratio*adv[j],ratio.clamp(1-EPS,1+EPS)*adv[j]).mean()
                    value=nn.functional.smooth_l1_loss(vf(X[j])[:,0],targets[j])
                    loss=-gain+.5*value-.002*dist.entropy().sum(1).mean()
                    optim.zero_grad();loss.backward()
                    nn.utils.clip_grad_norm_([*pi.parameters(),*vf.parameters(),ls],.65)
                    optim.step()
                    with torch.no_grad():
                        ls.clamp_(-1.3,-.25);clipcounts.append((abs(ratio-1)>EPS).float().mean().item())
                        kls.append(((ratio-1)-(logp-old[j])).mean().item());losses.append(float(value))
                if np.mean(kls[-(1+len(X)//128):])>.025:break
            w=to_numpy(pi,ls);i=it+1
            v=brief_stats(scores);v.update(iteration=i,decisions=len(X),reward_mean=float(np.mean([s['reward'] for s in scores])),
                kl=float(np.mean(kls)),clip_fraction=float(np.mean(clipcounts)),critic_loss=float(np.mean(losses)))
            history.append(v);save(HERE/'training-curve.json',history)
            if i in (4,8,14,21,28):save_net(w,i);saveds[i]=w
            print(i,'frames',v['steps'],'total',sum(q['steps'] for q in history),'peak',round(v['max_m'],3),'return',round(v['reward_mean'],3),flush=True)
        save(HERE/'training-episodes.json',all_training)
        results={}
        for i,wt in saveds.items():
            rr=evaluate_group(pool,wt,range(12714000,12714128));v=brief_stats(rr)
            results[str(i)]=dict(stats=v,rows=rr)
            print('selection',i,v['p90_m'],v['mean_m'],v['max_m'],flush=True)
        save(HERE/'checkpoint-selection.json',results)
        idx=max([k for k in saveds if k],key=lambda k:choose_key(results[str(k)]['stats']))
        trained=saveds[idx];save(HERE/'selected.json',dict(source='rl_route/rl_actor.py',settings=dict(base=BASE['settings'],weights={k:v.tolist() for k,v in trained.items()}),params=BASE['params']))
        for name,wt in [('baseline',saveds[0]),('ppo',trained)]:
            rr=evaluate_group(pool,wt,range(12712000,12712512));v=brief_stats(rr)
            save(HERE/f'independent-{name}.json',dict(checkpoint=(idx if name=='ppo' else 0),stats=v,rows=rr))
            print('independent',name,v,flush=True)
    torch.save({'actor':pi.state_dict(),'value':vf.state_dict(),'logstd':ls.detach(),'optimizer':optim.state_dict(),'generation':UPDATES},HERE/'training-state.pt')
if __name__=='__main__':main()
