"""Paddle yaw and tilt actions gated by a predicted approach of two observed balls."""
from collections import deque
from contextlib import contextmanager
import math
import ball
import numpy as np

class Aim:
    def __init__(self,bc,p):
        self.p=p;self.steps=0;self.gated=0;self.was=False
        a=bc.channels[0];self.j=a.m.joint('head_yaw').id
        self.q=a.m.jnt_qposadr[self.j];self.dof=a.m.jnt_dofadr[self.j];self.act=a.m.actuator('head_yaw').id
        self.angle=float(a.d.qpos[self.q]);self.rate=0.;self.neck=a.m.actuator('neck_pitch').id
        self.delay=deque([(self.angle,0.)]*(1+a.act_lag),maxlen=1+a.act_lag)
    def update(self,bc):
        a,b=bc.channels;p=self.p
        za=a.measurements[0];zb=b.measurements[0]
        r=zb[:2]-za[:2];v=zb[2:]-za[2:]
        n=max(.007,np.linalg.norm(r));er=r/n;et=np.array([-er[1],er[0]])
        horizon=-float(r@v)/max(.00015,float(v@v))
        impact=np.linalg.norm(r+horizon*v)
        inbound=float(er@v)<-.003
        selected=inbound and 0.<horizon<p['time'] and impact<p['miss'] and n>p['near']
        R=a.d.site_xmat[a.site].reshape(3,3)
        omega=float(R[:,2]@a.spatial[:3])
        # Aim along the predicted line of impact. Correct the exposure's relative
        # tangential velocity for paddle rotation; the shell's rolling ratio is 0.4.
        miss_v=float(et@v)+omega*n
        speed=-p['yaw']*miss_v/(.4*n) if selected else -p['recover']*self.angle
        speed=float(np.clip(speed,-p['rate'],p['rate']))
        self.rate+=np.clip(speed-self.rate,-p['alpha']*.02,p['alpha']*.02)
        self.angle=np.clip(self.angle+.02*self.rate,-p['angle'],p['angle'])
        tangent=-math.copysign(1.,miss_v)*et
        if selected:
            self.gated+=1
            scale=min(1.,n/.05)
            a.plate_bias=scale*(p['across']*tangent+p['along']*er)
            neck=p['neck']*(.5 if horizon<.15 else -1.)
        else:a.plate_bias=np.zeros(2);neck=0.
        if p.get('keep_yaw',True):
            self.delay.append((self.angle,neck))
            a.d.ctrl[self.act]=self.delay[0][0];a.d.ctrl[self.neck]+=self.delay[0][1]
        self.steps+=1

_ORIG=ball.BallController.control
def install(settings):
    ball.BallController.control=_ORIG
    if settings:
        def apply(bc):
            if bc.n_balls==2:
                if 'collision_aim' not in bc.__dict__:bc.collision_aim=Aim(bc,settings)
                bc.collision_aim.update(bc)
            _ORIG(bc)
        ball.BallController.control=apply
