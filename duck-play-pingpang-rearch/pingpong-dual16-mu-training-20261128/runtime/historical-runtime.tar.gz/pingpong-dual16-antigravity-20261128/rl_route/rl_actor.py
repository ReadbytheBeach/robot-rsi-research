"""Deploy a causal 23-to-4 residual policy atop the frozen two-ball controller."""
from collections import deque
from pathlib import Path
import importlib.util
import numpy as np
import ball
from path_geom import project

base_spec=importlib.util.spec_from_file_location('local_collision_controller',Path(__file__).with_name('base_collision.py'))
base=importlib.util.module_from_spec(base_spec);base_spec.loader.exec_module(base)
Original=ball.BallController
OBS=23
ACT=4
STRIDE=3
ACTION_SCALE=np.array([.095,.105,.10,.085])

def arrays(p):return {k:np.asarray(v,dtype=float) for k,v in p.items()}

def distribution(obs,weights):
    hidden=np.tanh(weights['w1']@obs+weights['b1'])
    return weights['w2']@hidden+weights['b2']


class Rollout:
    """Training-only access to the sampled action and extrinsic trajectory rewards."""
    def __init__(self,weights,settings,rng=None):
        self.weights=weights;self.settings=settings;self.rng=rng;self.current=None
        self.obs=[];self.raw=[];self.lp=[];self.pay=[];self.peak=0.;self.frames=0;self.last_station=0.;self.max_bin=0
    def decide(self,controller,obs):
        mu=distribution(obs,self.weights);sd=np.exp(self.weights['logstd'])
        raw=mu if self.rng is None else mu+sd*self.rng.normal(size=ACT)
        if self.rng is not None:
            self.obs.append(obs.copy());self.raw.append(raw.copy());self.pay.append(0.)
            self.lp.append(float(-.5*np.sum(((raw-mu)/sd)**2+2*self.weights['logstd']+np.log(2*np.pi))))
        return np.tanh(raw)
    def after_step(self,c,radius):
        x,y=c.d.qpos[:2]
        station=project(x,y)[0]-c.start_s;self.peak=max(self.peak,station);self.frames+=1
        if self.rng is not None and self.pay:
            progress=np.clip(station-self.last_station,-.025,.025)
            edge=np.clip((radius-.036)/.021,0.,1.4)
            bin_now=int(max(0.,station)/.25)
            passed=max(0,bin_now-self.max_bin);self.max_bin=max(self.max_bin,bin_now)
            self.pay[-1]+=20*progress+.009-.027*edge*edge-.001*float(c.held@c.held)+.40*passed
        self.last_station=station


def make_controller(rollout):
    class Residual(Original):
        def reset(self,*args,**kwargs):
            super().reset(*args,**kwargs)
            a=self.channels[0];m=self.m;d=self.d
            self.aimer=base.Aim(self,rollout.settings)
            self.start_s=project(*d.qpos[:2])[0]
            self.held=np.zeros(ACT)
            self.command_history=deque([np.zeros(2)]*(1+a.act_lag),maxlen=1+a.act_lag)
            self.yaw=m.actuator('head_yaw').id
            self.neck=m.actuator('neck_pitch').id
            self.extjoint=m.actuator_trnid[[self.neck,self.yaw],0]
        def sense(self):
            a,b=self.channels;za=a.measurements[0];zb=b.measurements[0]
            ctr=(za+zb)*.5
            outer,inner=(za,zb) if np.linalg.norm(za[:2])>=np.linalg.norm(zb[:2]) else (zb,za)
            diff=outer-inner;R=self.d.site_xmat[a.site].reshape(3,3)
            velocity=R.T@a.spatial[3:];omega=R.T@a.spatial[:3]
            # All ball values delivered by the delayed noisy camera interface. Body
            # sensors, paddle motion, gait progression and prior actions are causal.
            return np.clip(np.r_[ctr[:2]/.045,ctr[2:]/.18,diff[:2]/.07,diff[2:]/.15,
                    R[2,:2]/.27,velocity[:2]/.24,omega[:2]/3.,
                    a.obs_lag/2,b.obs_lag/2,a.act_lag/2,min(1.,a.tick*.02/3.),
                    np.clip(self.d.qpos[0],0.,1.),self.held],-4.,4.)
        def control(self):
            a=self.channels[0]
            if rollout.current is None:rollout.current=self
            if a.tick%STRIDE==0:
                obs=self.sense()
                self.held=(rollout.decide(self,obs) if self is rollout.current else np.tanh(distribution(obs,rollout.weights)))
            self.aimer.update(self)
            scaled=self.held*ACTION_SCALE
            a.plate_bias+=scaled[:2]
            self.command_history.append(scaled[2:].copy())
            ids=[self.neck,self.yaw];self.d.ctrl[ids]=np.clip(self.d.ctrl[ids]+self.command_history[0],
                      self.m.jnt_range[self.extjoint,0],self.m.jnt_range[self.extjoint,1])
            super().control()
        def observe(self):
            status=super().observe()
            if self is rollout.current:rollout.after_step(self,status[1])
            return status
    return Residual

def install(settings):
    """Install deterministic deployment without simulator seed inputs to the policy."""
    weights=arrays(settings['weights']);r=Rollout(weights,settings['base']);ball.BallController=make_controller(r)
