"""One real complete route simulation per sample; no change to the task evaluator."""
from pathlib import Path
import sys,json,os
import numpy as np
HERE=Path(__file__).resolve().parent
OLD=HERE.parents[1]/'pingpong-turn-pit-20261128'
sys.path.insert(0,str(OLD/'frozen/double16-stand'))
import course,ball
import rl_actor as actor
BASE=json.loads((HERE/'base.json').read_text())
def save(path,data):
    tmp=Path(str(path)+'.tmp');tmp.write_text(json.dumps(data,indent=2,ensure_ascii=False,allow_nan=False)+'\n');tmp.replace(path)
def simulation(job):
    w,seed,sampler,trace=job
    rng=None if sampler is None else np.random.default_rng(sampler)
    r=actor.Rollout(w,BASE['settings'],rng)
    orig=ball.BallController;ball.BallController=actor.make_controller(r)
    try:result=course.run('route',int(seed),BASE['params'],timeout=150.,trace=trace)
    finally:ball.BallController=orig
    brief=dict(seed=seed,success=result['success'],seconds=result['seconds'],s=result['distance_m'],peak=r.peak,
               steps=r.frames,reason=result['reason'],max_nm=max(result['motor']['peak_nm']),pushed=result.get('push_counts'))
    if rng is None:return brief
    r.pay[-1]+=16. if result['success'] else -1.5
    brief['reward']=sum(r.pay)
    return brief,(np.asarray(r.obs,dtype=np.float32),np.asarray(r.raw,dtype=np.float32),np.asarray(r.lp,dtype=np.float32),np.asarray(r.pay,dtype=np.float32))
def evaluate_group(pool,weights,seeds):
    return list(pool.map(simulation,[(weights,s,None,None) for s in seeds],chunksize=4))
def brief_stats(rr):
    d=np.array([v['peak'] for v in rr]);t=np.array([v['seconds'] for v in rr])
    return dict(n=len(d),completed=sum(v['success'] for v in rr),m1=int(sum(d>=1.)),m05=int(sum(d>=.5)),
                mean_m=float(d.mean()),median_m=float(np.median(d)),p90_m=float(np.percentile(d,90)),max_m=float(d.max()),
                mean_s=float(t.mean()),max_s=float(t.max()),steps=sum(v['steps'] for v in rr),max_torque=max(v['max_nm'] for v in rr))
