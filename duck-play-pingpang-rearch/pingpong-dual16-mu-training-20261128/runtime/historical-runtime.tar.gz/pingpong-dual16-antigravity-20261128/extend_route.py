"""Seal and evaluate the second controller pair on a distinct, larger set of full routes."""
import csv,json,shutil,sys,subprocess
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from zoneinfo import ZoneInfo
import numpy as np
from trials16 import ROOT,read,save,hash_file
from gauntlet_result import comparison
from attest import audit_reference,verify
D=ROOT/'holdout/extension'
def seal(chosen):
    root=ROOT/'sealed'/'extension';root.mkdir(parents=True,exist_ok=False)
    spec=read(chosen);src=ROOT/spec['source']
    files=[src]
    if src.name in ('after_launch.py','yaw_stabilizer.py'):files+=[src.with_name('transfer.py')]
    for f in files:shutil.copyfile(f,root/f.name)
    spec['source']=str((root/src.name).relative_to(ROOT));save(root/'candidate.json',spec)
    save(root/'manifest.json',dict(chosen=chosen,time=datetime.now(ZoneInfo('Asia/Singapore')).isoformat(),upstream=audit_reference(),evaluator=hash_file(ROOT/'trials16.py'),
       original_pair=hash_file(ROOT/'sealed/route/manifest.json'),protocol=hash_file(ROOT/'extension-protocol.json'),
       files={p.name:hash_file(p) for p in root.iterdir() if p.is_file()}))
def check():
    verify('route')
    root=ROOT/'sealed/extension';man=read(root/'manifest.json')
    assert audit_reference()==man['upstream'] and hash_file(ROOT/'trials16.py')==man['evaluator']
    assert hash_file(ROOT/'extension-protocol.json')==man['protocol']
    for name,h in man['files'].items():assert hash_file(root/name)==h
def main():
    D.mkdir(parents=True,exist_ok=True)
    check()
    s,n=read(ROOT/'extension-protocol.json')['fresh_route_seeds'];n=n-s+1
    def run(item):
        label,source=item
        subprocess.run([str(ROOT.parent/'pingpong-turn-pit-20261128/run-local'),str(ROOT/'trials16.py'),'route',str(s),str(n),str(D/label),'--spec',str(source),'--workers','8'],check=True)
    with ThreadPoolExecutor(2) as pool:list(pool.map(run,[('reference',ROOT/'sealed/route/candidate.json'),('candidate',ROOT/'sealed/extension/candidate.json')]))
    check();res=comparison(D/'reference.csv',D/'candidate.csv','route')
    for arm in ['reference','candidate']:
        rr=list(csv.DictReader((D/(arm+'.csv')).open()));s=np.array([float(r['peak_station_m']) for r in rr])
        res[arm+'_detail']=dict(**read(D/(arm+'.json')),reached={str(a):int((s>=a).sum()) for a in (.25,.5,1,2.5,5,10)},p90_m=float(np.percentile(s,90)),peak_m=float(s.max()),furthest_seed=int(rr[s.argmax()]['seed']),max_torque=max(float(r['peak_motor_nm']) for r in rr))
    save(D/'summary.json',res)
if __name__=='__main__':
    if len(sys.argv)>1:seal(sys.argv[1])
    main()
