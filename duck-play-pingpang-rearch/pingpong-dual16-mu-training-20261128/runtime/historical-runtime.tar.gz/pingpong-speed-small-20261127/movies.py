"""Render fixed-timestep MuJoCo poses at original speed, with tightly framed ball/paddle detail."""
import argparse
from fractions import Fraction
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

os.environ.setdefault('MUJOCO_GL', 'egl')
os.environ.setdefault('EGL_PLATFORM', 'surfaceless')
os.environ.setdefault('LP_NUM_THREADS', '3')
import mujoco
import numpy as np
from PIL import Image, ImageDraw, ImageFont

D = Path(__file__).resolve().parent
RATE = Fraction(25, 2)
W, H = 960, 620
LEFT = (16, 76, 544, 396)
RIGHT = (556, 76, 944, 396)
BG, PANEL, TEXT = '#162731', '#213946', '#f0f6f7'
TEAL, MUTED, ORANGE = '#87e2d0', '#acbfc8', '#ffae68'
REGULAR = '/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
BOLD = '/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc'
FONTS = {n:ImageFont.truetype(file,n) for n,file in [(15,REGULAR),(17,REGULAR),(18,BOLD),(22,BOLD),(27,BOLD)]}


def sha(file):
    with Path(file).open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()


RENDERER_DIGEST = sha(Path(__file__))


def camera(at, distance, azimuth, elevation):
    c = mujoco.MjvCamera()
    mujoco.mjv_defaultCamera(c)
    c.lookat[:] = at
    c.distance, c.azimuth, c.elevation = distance, azimuth, elevation
    return c


def put(draw, xy, text, font=17, color=TEXT, **kwargs):
    draw.text(xy, text, font=FONTS[font], fill=color, **kwargs)


def label_reason(key):
    return {'ball_lost':'球已离拍','ball':'球已离拍','fall':'机身跌倒','fell':'机身跌倒','timeout':'超过时限',
            'ball_edge':'球滚出拍缘','ball_other_contact':'球碰到拍面以外的物体','ball_below':'球跌至拍面下方','ball_air':'球离拍过久','fall_tilt':'机身倾倒','fall_height':'机身过低','nonfoot':'非足部触地','nonfoot_ground':'非足部触地','lane_exit':'离开通道','height':'机身过低','tilt':'机身倾倒','nonfinite':'数值异常','station_drift':'原地位移超限','off_route':'离开通道','complete':'完成','success':'完成','ok':'完成'}.get(key, str(key))


def adjust_renderer(renderer, data, cam, opt):
    renderer.update_scene(data, camera=cam, scene_option=opt)
    for flag in (mujoco.mjtRndFlag.mjRND_SHADOW,mujoco.mjtRndFlag.mjRND_REFLECTION,mujoco.mjtRndFlag.mjRND_SKYBOX):
        renderer.scene.flags[flag] = 0
    return Image.fromarray(renderer.render())


def compact_visual_meshes(model, voxel_mm):
    """Make a display-only level of detail. Ball, paddle, terrain and all recorded poses stay exact."""
    original = int(model.nmeshface)
    retained = original
    if not voxel_mm:
        return original, retained
    if not 0 < voxel_mm <= 1.0:
        raise ValueError('Display mesh grouping supports up to 1 mm voxels')
    for i in range(model.nmesh):
        va, nv = int(model.mesh_vertadr[i]), int(model.mesh_vertnum[i])
        fa, nf = int(model.mesh_faceadr[i]), int(model.mesh_facenum[i])
        vert = model.mesh_vert[va:va+nv]
        cells = np.floor((vert-vert.min(axis=0)) / (voxel_mm/1000)).astype(np.int32)
        _, representatives, groups = np.unique(cells,axis=0,return_index=True,return_inverse=True)
        faces = representatives[groups][model.mesh_face[fa:fa+nf]]
        keep = (faces[:,0]!=faces[:,1]) & (faces[:,1]!=faces[:,2]) & (faces[:,0]!=faces[:,2])
        count = int(keep.sum())
        if count == 0:
            continue
        model.mesh_face[fa:fa+count] = faces[keep]
        for attributes in (model.mesh_facenormal,model.mesh_facetexcoord):
            attributes[fa:fa+count] = attributes[fa:fa+nf][keep]
        model.mesh_facenum[i] = count
        retained -= nf-count
    return original, retained


def renderer_model(meta):
    root=D
    if meta.get('freeze_sha256'):
        manifests=[p for p in (D/'frozen').rglob('*.json') if sha(p)==meta['freeze_sha256']]
        if len(manifests)!=1:
            raise ValueError('Missing matching frozen snapshot')
        root=manifests[0].parent
        desc=json.loads(manifests[0].read_text())
        for name in ('locomotion.py','ball.py','pacing.py','protocol.json'):
            if sha(root/name)!=desc['files'][name]:
                raise ValueError(f'Frozen geometry source mismatch: {name}')
    sys.path.insert(0,str(root))
    import locomotion
    model=locomotion.build_model(terrain=True,payload=True,mass_g=40.)
    if abs(model.body('paddle').mass.item()-.040)>1e-8 or abs(model.geom('ball_geom').size[0]-.016)>1e-8:
        raise ValueError('Expected a 40 g paddle and 32 mm physical ball')
    return model, root.relative_to(D),locomotion


def real_speeds(t,x):
    """Causal net forward velocity, calculated from actual positions over up to one second."""
    old=np.maximum(t[0],t-1.)
    denominator=t-old
    return np.divide(x-np.interp(old,t,x),denominator,out=np.zeros_like(x),where=denominator>0)


def first_cross(t,x,position):
    idx=np.flatnonzero(x>=position)
    if not idx.size:
        return np.inf
    j=int(idx[0])
    if not j:
        return float(t[0])
    return float(t[j-1]+(t[j]-t[j-1])*(position-x[j-1])/(x[j]-x[j-1]))


def reason_zh(key):
    extra={'pace':'实测分档速度未达标','deadline':'超过完赛时限','pace_and_deadline':'速度与时限均未达标','nonfoot_ground_500hz':'非足部触地','ball_other_contact_500hz':'球触及拍外部件','ball_air_500hz':'离拍持续超过 180 ms'}
    return extra.get(key,label_reason(key))


def get_rules(meta,protocol):
    cfg=json.loads(protocol.read_text())
    import pacing
    seq=meta.get('levels',pacing.Pace(int(meta['seed'])).levels)
    expected=pacing.Pace(int(meta['seed'])).levels
    if seq!=expected:raise ValueError('Seed and scheduled pace order do not agree')
    zones=[]
    if cfg['zone_boundaries_m']!=[0,2.5,5,7.5,10] or cfg['steady_window_within_each_zone_m']!=[.55,2.15]:
        raise ValueError('Video timing windows do not match the experiment protocol')
    if float(cfg['timed_finish_max_s'])!=pacing.DEADLINE:
        raise ValueError('Pacing clock does not match the registered deadline')
    for i,k in enumerate(seq):
        lo,hi=cfg[k+'_range_mps']
        if (lo,hi)!=pacing.BOUNDS[k]:raise ValueError('Pace bands differ from the registered protocol')
        zones.append({'start':2.5*i,'end':2.5*(i+1),'key':k,'label':f"第 {i+1} 段 · "+('慢档' if k=='slow' else '快档'),'target':f'目标 {lo:.3f}–{hi:.3f} m/s'})
    return zones,float(meta.get('deadline_s',pacing.DEADLINE))


def movie(trace,output,title,protocol,lod=.8,start_s=0.,end_s=None):
    meta=json.loads(trace.with_suffix('.json').read_text())
    model,model_path,loc=renderer_model(meta)
    if meta.get('freeze_sha256') and sha(protocol)!=sha(D/model_path/'protocol.json'):
        raise ValueError('Explicit pace protocol does not match the frozen snapshot')
    with np.load(trace,allow_pickle=False) as z:
        t=np.asarray(z['t']); x=np.asarray(z['progress_m'])
        poses=np.asarray(z['qpos']); radial=np.asarray(z['radial_m']); contact=np.asarray(z['on_face'])
    if meta.get('trace_sha256') and sha(trace)!=meta['trace_sha256']:
        raise ValueError('Input trace checksum differs from the scored episode')
    if poses.shape!=(len(t),model.nq) or not np.isfinite(poses).all() or not (np.diff(t)>0).all():
        raise ValueError('Invalid trace timeline or pose dimensions')
    zones,deadline=get_rules(meta,protocol)
    speed=real_speeds(t,x)
    cross=np.array([first_cross(t,x,z['start']) for z in zones]+[first_cross(t,x,zones[-1]['end'])])
    windows=[(first_cross(t,x,z['start']+.55),first_cross(t,x,z['start']+2.15)) for z in zones]
    for saved,(a,b) in zip(meta.get('segment_mps',[]),windows):
        if saved is not None and (not np.isfinite(b) or abs(saved-1.6/(b-a))>1e-7):
            raise ValueError('Measured segment speed and scored result differ')
    terrain_x=np.linspace(0.,10.,450)
    z0=float(meta.get('initial_x_m',0.))
    terrain_pixels=[(round(18+v*51),round(583-h*1275)) for v,h in zip(terrain_x,loc.ground_height(z0+terrain_x))]
    data=mujoco.MjData(model)
    root=model.body('trunk_base').id
    center=model.site('paddle_center').id
    meshes=compact_visual_meshes(model,lod)
    model.vis.quality.offsamples=1
    model.vis.global_.offwidth=max(model.vis.global_.offwidth,LEFT[2]-LEFT[0])
    model.vis.global_.offheight=max(model.vis.global_.offheight,LEFT[3]-LEFT[1])
    model.vis.map.znear=min(float(model.vis.map.znear),.0004)
    opt=mujoco.MjvOption();opt.geomgroup[3:]=0;opt.sitegroup[:]=0
    leftcam=camera([0,0,.13],.48,145,-17);rightcam=camera([0,0,.18],.216,108,-55)
    clip_start=float(t[0])+start_s
    clip_end=float(t[-1]) if end_s is None else min(float(t[-1]),float(t[0])+end_s)
    if not t[0]<=clip_start<clip_end:raise ValueError('Invalid excerpt interval')
    terminal=clip_end>=t[-1]
    rate_label='原速节选' if start_s or not terminal else '原速'
    base=Image.new('RGB',(W,H),BG);dr=ImageDraw.Draw(base)
    put(dr,(16,4),title,27);put(dr,(944,15),f"40 g 拍  |  32 mm 球  |  {rate_label}  |  种子 {meta['seed']}",17,TEAL,anchor='ra')
    put(dr,(16,45),'跟随机位 · 全身与足部',17,MUTED);put(dr,(556,45),'拍面近景 · 同一物理时刻',17,MUTED)
    for p,txt in [(18,'净前进'),(226,'近 1 s 实测'),(475,'本段测速窗均速'),(735,'剩余时间')]:
        put(dr,(p,404),txt,15,MUTED)
    for left in (205,451,706): dr.line((left,406,left,464),fill=PANEL,width=2)
    put(dr,(18,534),'路面剖面 · 四个坡顶，竖向放大',15,MUTED)
    dr.polygon([(18,590),*terrain_pixels,(528,590)],fill=PANEL)
    dr.line(terrain_pixels,fill=MUTED,width=2)
    for z in zones:
        a=18+z['start']*51;b=18+z['end']*51
        dr.line((int(a+.55*51),597,int(a+2.15*51),597),fill=TEAL if z['key']=='slow' else ORANGE,width=3)
        dr.line((int(a),591,int(a),599),fill=MUTED,width=1)
    put(dr,(944,594),'测速窗取各段的 0.55–2.15 m',15,MUTED,anchor='ra')
    total=clip_end-clip_start;n=max(1,round(total*float(RATE)))+1
    uniform=np.linspace(clip_start,clip_end,n)
    right=np.searchsorted(t,uniform).clip(0,len(t)-1);left=np.maximum(0,right-1)
    ii=np.where(np.abs(t[left]-uniform)<np.abs(t[right]-uniform),left,right)
    ok=bool(meta['success']);reason=meta['reason'];held=0 if ok or not terminal else round(float(RATE)*1.2)
    goal=float(meta.get('target_m',10.))
    output.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(dir=output.parent) as scratch:
        tmp=Path(scratch)/output.name
        ff=['ffmpeg','-nostdin','-hide_banner','-loglevel','error','-f','rawvideo','-pixel_format','rgb24','-video_size',f'{W}x{H}','-framerate',str(RATE),'-i','pipe:0','-an','-c:v','libx264','-preset','veryfast','-crf','22','-pix_fmt','yuv420p','-threads','2','-movflags','+faststart','-y',str(tmp)]
        proc=subprocess.Popen(ff,stdin=subprocess.PIPE)
        try:
            with mujoco.Renderer(model,320,528) as body,mujoco.Renderer(model,320,388) as face:
                for j,i in enumerate(ii):
                    data.qpos[:]=poses[i];mujoco.mj_kinematics(model,data);mujoco.mj_camlight(model,data)
                    p=data.xpos[root];c=data.site_xpos[center]
                    leftcam.lookat[:]=[.64*p[0]+.36*c[0],.64*p[1]+.36*c[1],max(.13,.43*p[2]+.45*c[2])]
                    rightcam.lookat[:]=c+[0,0,.009]
                    frame=base.copy();frame.paste(adjust_renderer(body,data,leftcam,opt),LEFT[:2]);frame.paste(adjust_renderer(face,data,rightcam,opt),RIGHT[:2])
                    dr=ImageDraw.Draw(frame);xt=float(x[i]);ts=float(t[i]);elapsed=ts-float(t[0])
                    seg=min(len(zones)-1,max(0,int(np.searchsorted(cross,ts,side='right')-1)))
                    zone=zones[seg];start_t,finish_t=windows[seg]
                    avg=None
                    if ts>start_t:
                        avg=1.6/(finish_t-start_t) if finish_t<=ts else (xt-zone['start']-.55)/(ts-start_t)
                    put(dr,(18,426),f'{xt:.2f} m',27,TEAL)
                    put(dr,(226,426),f'{speed[i]:.3f} m/s',27)
                    put(dr,(475,426),'待入窗' if avg is None else f'{avg:.3f} m/s',27)
                    put(dr,(735,426),f'{max(0.,deadline-elapsed):.2f} s',27,TEAL if elapsed<deadline else ORANGE)
                    dr.line((17,474,943,474),fill=PANEL,width=2)
                    label=zone['label'] if ts<cross[-1] else '终点持稳'
                    put(dr,(18,487),label,22,TEAL)
                    put(dr,(215,487),zone['target'] if ts<cross[-1] else '机身减速并持球停稳',17,MUTED)
                    put(dr,(940,487),f'已用 {elapsed:.2f} / {deadline:g} s',17,anchor='ra')
                    px,py=terrain_pixels[int(np.clip(xt/10,0,1)*(len(terrain_pixels)-1))]
                    dr.ellipse((px-4,py-4,px+4,py+4),fill=TEAL)
                    ct='接触拍面' if contact[i] else '当前采样无接触'
                    put(dr,(550,537),f"球心偏移 {radial[i]*1000:.1f} mm  ·  {ct}",17,ORANGE)
                    status= ('本段开发完成' if goal<10 else '完整任务通过') if ok else '停止 · '+reason_zh(reason)
                    if j<len(ii)-1 or not terminal:status=f'路程目标 {goal:g} m'
                    put(dr,(550,572),status,18,TEAL if ok or j<len(ii)-1 else '#ff9593')
                    proc.stdin.write(frame.tobytes())
                for _ in range(held):
                    proc.stdin.write(frame.tobytes())
            proc.stdin.close()
            if proc.wait():raise RuntimeError('ffmpeg failed')
        finally:
            if proc.poll() is None:proc.kill();proc.wait()
        r=subprocess.run(['ffprobe','-v','error','-select_streams','v:0','-count_frames','-show_entries','stream=width,height,duration,nb_read_frames,avg_frame_rate','-of','json',str(tmp)],capture_output=True,text=True,check=True)
        stream=json.loads(r.stdout)['streams'][0]
        assert int(stream['nb_read_frames'])==n+held
        subprocess.run(['ffmpeg','-nostdin','-v','error','-xerror','-threads','2','-i',str(tmp),'-f','null','-'],check=True)
        os.replace(tmp,output)
    desc={'seed':meta['seed'],'title':title,'success':ok,'reason':reason,'simulated_s':total,'clip_start_s':float(clip_start),'clip_end_s':float(clip_end),'held_terminal_frames':held,'media':stream,'trace':str(trace.resolve().relative_to(D)),'trace_sha256':sha(trace),'score_sha256':sha(trace.with_suffix('.json')),'protocol_sha256':sha(protocol),'renderer_sha256':RENDERER_DIGEST,'freeze_sha256':meta.get('freeze_sha256'),'model_source':str(model_path),'paddle_mass_g':40,'ball_diameter_mm':32,'robot_display_lod_mm':lod,'display_triangles_before_after':meshes,'measured_velocity':'causal forward position difference / up to 1 s','media_sha256':sha(output)}
    output.with_suffix('.json').write_text(json.dumps(desc,indent=2,ensure_ascii=False)+'\n')
    print(output,stream,flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('trace',type=Path);parser.add_argument('output',type=Path);parser.add_argument('--title',required=True)
    parser.add_argument('--protocol',type=Path,default=D/'protocol.json');parser.add_argument('--lod-mm',type=float,default=.8)
    parser.add_argument('--start',type=float,default=0.,help='Excerpt start on the original physical clock.')
    parser.add_argument('--end',type=float,help='Excerpt end on the original physical clock.')
    arg=parser.parse_args()
    movie(arg.trace.resolve(),arg.output.resolve(),arg.title,arg.protocol.resolve(),arg.lod_mm,arg.start,arg.end)
